export interface Maravillas {
    id_maravilla:number;
    maravilla:string;
    pais: string;
    zona: number
    puntuacion:number
}

