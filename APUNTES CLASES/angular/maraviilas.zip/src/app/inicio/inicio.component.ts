import { Component,Input, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MaravillasComponent } from '../maravillas/maravillas.component';

@Component({
  selector: 'app-inicio',
  standalone: true,
  imports: [FormsModule, MaravillasComponent],
  templateUrl: './inicio.component.html',
  styleUrl: './inicio.component.css'
})
export class InicioComponent {
email!:string

@Output() activacion = new EventEmitter<any>();

activado(){
     this.activacion.emit(this.email);
}
}
