
import { Routes } from '@angular/router';
import { EncuestaComponent } from './maravillas/encuesta/encuesta.component';
import { MaravillasComponent } from './maravillas/maravillas.component';
import { AnadirComponent } from './anadir/anadir.component';
import { PuntuacionesComponent } from './puntuaciones/puntuaciones.component';

export const routes: Routes = [

  {
    path: 'anadir',
    component: AnadirComponent
  },
  {
    path: 'maravillas/:nombre',
    component: MaravillasComponent,
    children: [{
      path: 'encuesta',
      component: EncuestaComponent
    }]
  },
  {
    path: 'puntuaciones',
    component: PuntuacionesComponent
  },
];


