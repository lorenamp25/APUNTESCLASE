import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MaravillasComponent } from './maravillas.component';

describe('MaravillasComponent', () => {
  let component: MaravillasComponent;
  let fixture: ComponentFixture<MaravillasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MaravillasComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MaravillasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
