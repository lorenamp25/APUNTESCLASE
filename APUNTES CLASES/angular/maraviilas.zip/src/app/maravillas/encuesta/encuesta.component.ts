import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BasedatosService } from '../../basedatos.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { AvisoComponent } from '../../aviso/aviso.component';

@Component({
  selector: 'app-encuesta',
  standalone: true,
  imports: [FormsModule, AvisoComponent],
  templateUrl: './encuesta.component.html',
  styleUrl: './encuesta.component.css'
})
export class EncuestaComponent implements OnInit {
  id_maravilla!: string
  titulo!: string
  email!: string
  puntuacion: number = 5
  datos!: any
  correcto!: string

  constructor(private basedatosServicio: BasedatosService, private rutaActiva: ActivatedRoute) { }
  ngOnInit(): void {
    this.rutaActiva.paramMap.subscribe((parametros: ParamMap) => {
      this.id_maravilla = parametros.get("id_maravilla")!;
      this.titulo = parametros.get("maravilla")!;
      this.email = parametros.get("email")!;
    })
  }

  enviarEncuesta(puntuacion: any) {
    this.datos = {
      id_maravilla: parseInt(this.id_maravilla),
      email: this.email,
      puntuacion: puntuacion
    }
    this.correcto = ""
 
    this.basedatosServicio.enviarPuntuacion(this.datos).subscribe((datos: any) => {
  
      if (datos['resultado'] == 'OK') {
        this.correcto = "ok"
       
      }
    });
  }
}




