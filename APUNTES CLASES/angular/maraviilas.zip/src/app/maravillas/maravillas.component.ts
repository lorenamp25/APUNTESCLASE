import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet,RouterLink, Router } from '@angular/router';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { BasedatosService } from '../basedatos.service';  
import { FormsModule } from '@angular/forms';
import { Maravillas } from '../Maravillas';
import { AvisoComponent } from '../aviso/aviso.component';


@Component({
  selector: 'app-maravillas',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, FormsModule, AvisoComponent],
  templateUrl: './maravillas.component.html',
  styleUrl: './maravillas.component.css'
})
export class MaravillasComponent {
  correcto!:string
  maravillas:Maravillas[] = [];
  email!:string
  maravilla!:Maravillas
  

  constructor(private basedatosServicio: BasedatosService, private ruta: Router, private rutaActiva: ActivatedRoute) {
    this.recuperarMaravillas();
  }

  ngOnInit(): void {
    this.rutaActiva.paramMap.subscribe((parametros: ParamMap) => {
      this.email = parametros.get("nombre")!;
    })
  }
  recuperarMaravillas() {
    this.basedatosServicio.recuperarMaravillas().subscribe((maravillas:Maravillas[]) => this.maravillas = maravillas);
  }

  encuesta(id_maravilla:number,maravilla:string){
    this.ruta.navigate([`/maravillas/${this.email}/encuesta`, { 'id_maravilla':id_maravilla, 'maravilla':maravilla, 'email': this.email }]) 
  }

  enviarPuntuacion(puntuacion:any) {
    console.log(`mi ${puntuacion}`)
    this.basedatosServicio.enviarPuntuacion(puntuacion).subscribe();
  }

}




 