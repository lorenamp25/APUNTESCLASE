import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { InicioComponent } from './inicio/inicio.component';



@Component({
  standalone: true,
  imports: [RouterOutlet, RouterLink, InicioComponent],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  activar: boolean = false
  email!: string

  cambiar(email: string) {
    document.title=email
    this.activar = true
    console.log(email)
    this.email = email
  }
}

