import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BasedatosService } from '../basedatos.service';
import { AbstractControl, FormBuilder, FormGroup, ReactiveFormsModule, Validators, ValidationErrors } from "@angular/forms";
import * as paisesJson from '../../assets/json/paises.json'
import * as zonasJson from '../../assets/json/zonas.json'
import { AvisoComponent } from '../aviso/aviso.component';


@Component({
  selector: 'app-anadir',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, AvisoComponent],
  templateUrl: './anadir.component.html',
  styleUrl: './anadir.component.css'
})

export class AnadirComponent {
  paises = paisesJson
  zonas = zonasJson
  maravilla!:any
  imagen!:string
  formularioMaravillas!: FormGroup;
  submitted = false;
  grupo: any;
  correcto!: string
  mensaje!:string
  constructor(private fb: FormBuilder, private basedatosServicio: BasedatosService) { }

  ngOnInit() {
  
    this.formularioMaravillas = this.fb.group({
      maravilla: ['', [Validators.required, Validators.minLength(3)]],
      pais: ['', [Validators.required]],
      zona: ['', [Validators.required]],
      imagen: []

    })
  }

  repetido(control: AbstractControl): ValidationErrors | null {
    const valor1 = control.value;
    return () => this.basedatosServicio.comprobarMaravilla(valor1)
      .subscribe((datos: any) => {
       
        if (datos.resultado == 'encontrado') {
          return { repetido: true }
        }
        else {
          return null
        }
      })


  }


  submit() {
    this.correcto = ""
    this.submitted = true;
    this.maravilla = this.formularioMaravillas.value.maravilla
    this.basedatosServicio.comprobarMaravilla(this.maravilla)
      .subscribe((datos: any) => {
       
        if (datos.resultado == 'encontrado') {
         
          this.mensaje="Nombre Maravilla ya está utilizado"
          this.correcto = "ok"
          this.submitted = false;
        }
        else {
          //this.imagen=this.formularioMaravillas.value.imagen
          this.basedatosServicio.altaMaravilla(this.formularioMaravillas.value)
            .subscribe((datos: any) => {
              if (datos['resultado'] == 'OK') {
                this.mensaje="Maravilla grabada"
                this.correcto = "ok"
              }
            },
              (error: any) => {
                this.correcto = "error"
              })
        }
      })
  }

  onReset() {
    this.submitted = false;
    this.formularioMaravillas.reset();
  }
}



