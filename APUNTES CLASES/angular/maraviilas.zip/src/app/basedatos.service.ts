import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Maravillas } from './Maravillas';
@Injectable({
  providedIn: 'root'
})
export class BasedatosService {
  data!:any
  url='http://localhost:80/dwec/maravillas/'; // disponer url de su servidor que tiene las páginas PHP

  constructor(private http: HttpClient) { }

  recuperarMaravillas() {
    return this.http.get<Maravillas[]>(`${this.url}recuperarmaravillas.php`);
  }
  altaMaravilla(maravilla:any) {
    this.data=new FormData()
    this.data.append('maravilla',maravilla.maravilla)
    this.data.append('pais',maravilla.pais)
    this.data.append('zona',maravilla.zona)
    return this.http.post(`${this.url}altaMaravilla.php`, this.data);    
  }

  enviarPuntuacion(datos:any) {
    return this.http.post(`${this.url}anadirPuntuacion.php`, JSON.stringify(datos));
  }
  
  comprobarMaravilla(maravilla:string) {
    return this.http.get(`${this.url}comprobarMaravilla.php?maravilla=${maravilla}`);
  }

  puntuaciones(zona:number){
    return this.http.get<Maravillas[]>(`${this.url}puntuacionesMaravilla.php?zona=${zona}`);
  }

}
