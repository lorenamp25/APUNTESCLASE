import { Component } from '@angular/core';
import { Maravillas } from '../Maravillas';
import { SolicitarzonaComponent } from './solicitarzona/solicitarzona.component';

@Component({
  selector: 'app-puntuaciones',
  standalone: true,
  imports: [SolicitarzonaComponent],
  templateUrl: './puntuaciones.component.html',
  styleUrl: './puntuaciones.component.css'
})
export class PuntuacionesComponent {
  maravillas!:Maravillas[]
  puntosMedia!:string
  calcularMedia(maravillas: Maravillas[]) {
    this.maravillas = maravillas
    let media=0
    this.maravillas.forEach(maravilla=>{
      
       media=(media)+parseInt(maravilla.puntuacion.toString());
       
    })
    media=media/maravillas.length
    if(media){
    this.puntosMedia=media.toString()
  } else {
    this.puntosMedia="No hay ninguna maravilla de esta zona"
  }




  }
}
