import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BasedatosService } from '../../basedatos.service';
import { Maravillas } from '../../Maravillas';
import * as zonasJson from '../../../assets/json/zonas.json'

@Component({
  selector: 'app-solicitarzona',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './solicitarzona.component.html',
  styleUrl: './solicitarzona.component.css'
})
export class SolicitarzonaComponent {

  @Output() calcularmedia = new EventEmitter<any>();
  zonas = zonasJson
  media!: number
  zonasel!: number
  maravillas!: Maravillas[]
  constructor(private basedatosServicio: BasedatosService) { }
  elegir() {
    
    console.log(this.zonasel)
    this.basedatosServicio.puntuaciones(this.zonasel).subscribe((maravillas:Maravillas[]) => {
      if (maravillas){
      this.calcularmedia.emit(maravillas)
      }
    });
    ;
  }


};

