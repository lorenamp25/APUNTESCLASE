import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SolicitarzonaComponent } from './solicitarzona.component';

describe('SolicitarzonaComponent', () => {
  let component: SolicitarzonaComponent;
  let fixture: ComponentFixture<SolicitarzonaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SolicitarzonaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SolicitarzonaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
