<?php
function retornarConexion() {
  $con=mysqli_connect("localhost","root","","maravillas");
  return $con;
}
?>