<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
require("conexion.php");
$conexion = retornarConexion();

$sql = "SELECT maravillas.id_maravilla, maravillas.maravilla, puntuaciones.puntuacion FROM maravillas INNER JOIN puntuaciones ON maravillas.id_maravilla = puntuaciones.id_maravilla
        WHERE maravillas.zona=$_GET[zona]";

$resultados = mysqli_query($conexion, $sql) or die(mysqli_error($conexion));


    class Result
{
}

$response = new Result();

if (mysqli_num_rows($resultados) > 0) {
  while ( $fila = mysqli_fetch_array($resultados, MYSQLI_ASSOC))
    {
    $datos[]=$fila;
    }
  
  $response = $datos;
} else {
  
  $response = [];

}
echo json_encode($response);
mysqli_close($conexion);