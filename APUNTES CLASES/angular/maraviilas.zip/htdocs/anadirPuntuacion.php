<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

$json = file_get_contents('php://input');

$params = json_decode($json);

require("conexion.php");
$con = retornarConexion();

// $sql="update Puntuaciones set puntuacion=$params->puntuacion where maravilla='$params->maravilla' AND '$params->email'");

$sql = "INSERT INTO Puntuaciones(id_maravilla, email, puntuacion) VALUES ($params->id_maravilla, '$params->email', $params->puntuacion) ON DUPLICATE KEY UPDATE puntuacion = $params->puntuacion";

mysqli_query($con, $sql);
class Result {}

  $response = new Result();
  $response->resultado = 'OK';
  $response->mensaje = 'datos grabados';

  header('Content-Type: application/json');
  echo json_encode($response); 