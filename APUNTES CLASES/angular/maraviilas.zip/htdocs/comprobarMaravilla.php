<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
require("conexion.php");
$conexion = retornarConexion();

$sql = "SELECT * FROM maravillas WHERE maravillas.maravilla='$_GET[maravilla]'";

$resultados = mysqli_query($conexion, $sql) or die(mysqli_error($conexion));
class Result
{
}

$response = new Result();

if (mysqli_num_rows($resultados) > 0) {
  
  $response->resultado = 'encontrado';
} else {
  
  $response->resultado = 'no_encontrado';

}
;
header('Content-Type: application/json');
echo json_encode($response);

mysqli_close($conexion);
?>