<?php 
  header('Access-Control-Allow-Origin: *'); 
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
  
  require("conexion.php");
  $conexion=retornarConexion();

  $sql="SELECT maravillas.id_maravilla, maravillas.maravilla, paises.pais, zonas.zona FROM maravillas 
  INNER JOIN paises ON maravillas.pais = paises.iso2 
  INNER JOIN zonas ON maravillas.zona = zonas.id_zona";

  $resultados=mysqli_query($conexion,$sql) or die(mysqli_error($conexion));
while ( $fila = mysqli_fetch_array($resultados, MYSQLI_ASSOC))
    {
    $datos[]=$fila;
    }
echo json_encode($datos);
mysqli_close($conexion);
?>

