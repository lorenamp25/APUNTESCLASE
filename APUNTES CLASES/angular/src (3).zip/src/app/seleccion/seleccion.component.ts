import { Component } from '@angular/core';
import { ListaComponent } from "./lista/lista.component";

@Component({
  selector: 'app-seleccion',
  imports: [ListaComponent],
  templateUrl: './seleccion.component.html',
  styleUrl: './seleccion.component.css'
})
export class SeleccionComponent {
  vertiente_sel:string=""
  vertientes = [
    {
      "id_vertiente": "Norte",
      "vertiente": "Cantábrica"
    },
    {
      "id_vertiente": "Oeste",
      "vertiente": "Atlántica"
    },
    {
      "id_vertiente": "Sur y Este",
      "vertiente": "Mediterranea"
    }
  ]
  enviar(vertiente: string) {
    this.vertiente_sel = vertiente
  }
}

