import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-lista',
  imports: [],
  templateUrl: './lista.component.html',
  styleUrl: './lista.component.css'
})
export class ListaComponent {
  @Input() siglo: string=""
  @Output() miSeleccion=new EventEmitter<string>()
  enviarSiglo(){
    this.miSeleccion.emit(this.siglo)
  }
}
