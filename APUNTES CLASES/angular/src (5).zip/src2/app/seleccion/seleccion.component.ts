import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ListaComponent } from "./titulo/lista.component";

@Component({
  selector: 'app-seleccion',
  imports: [ListaComponent, FormsModule],
  templateUrl: './seleccion.component.html',
  styleUrl: './seleccion.component.css'
})
export class SeleccionComponent {
  cuadro!: any
  verCuadros: boolean = false
  autor!: string
  siglo!: string

  cuadros = [
    {
      "id": 1,
      "titulo": "Las Meninas",
      "siglo": "XVII",
      "autor": "Velázquez",
      "localizacion": [
        "óleo", "retrato"]
    },
    {
      "id": 2,
      "titulo": "Guernica",
      "siglo": "XX"
      ,
      "autor": "Velázquez",
      "caracteristicas": [
        "óleo", "simbólico"]
    },
    {
      "id": 3,
      "titulo": "La Joven de la Perla",
      "siglo": "XVII",
      "autor": "Velázquez",
      "caracteristicas": [
        "óleo", "simbólico"]
    },
    {
      "id": 4,
      "titulo": "La Mona Lisa  La Gioconda",
      "siglo": "XVI",
      "autor": "Velázquez",
      "caracteristicas": [
        "óleo", "simbólico"]
    },
    {
      "id": 5,
      "titulo": "La Noche Estrellada",
      "siglo": "XIX"
    },
    {
      "id": 6,
      "titulo": "El Beso",
      "siglo": "XX"
    },
    {
      "id": 7,
      "titulo": "El Nacimiento de Venus",
      "siglo": "XV"
    },
    {
      "id": 8,
      "titulo": "El Grito",
      "siglo": "XIX"
    },
    {
      "id": 9,
      "titulo": "La Creación de Adán",
      "siglo": "XVI"
    },
    {
      "id": 10,
      "titulo": "La Última Cena",
      "siglo": "XV"
    }

  ]
  listaCuadros = JSON.stringify(this.cuadros)

  cuadrosSiglo(e: string) {
    this.cuadro = this.cuadros.find((cuadro) => cuadro.titulo === e)
    this.autor = this.cuadro.autor
    this.siglo = this.cuadro.siglo
    this.verCuadros = true
  }
}


