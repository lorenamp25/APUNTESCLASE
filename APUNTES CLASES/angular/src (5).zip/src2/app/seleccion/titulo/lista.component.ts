import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-lista',
  imports: [FormsModule],
  templateUrl: './lista.component.html',
  styleUrl: './lista.component.css'
})
export class ListaComponent {
  @Input() listaCuadros!: any
  @Output() miSeleccion = new EventEmitter<string>()
  cuadros: any
  ngOnInit() {
    console.log(this.listaCuadros)
    this.cuadros = JSON.parse(this.listaCuadros)
  }
  cuadro!: string
  enviarCuadro(e: any) {
    this.miSeleccion.emit(e)
  }
}
