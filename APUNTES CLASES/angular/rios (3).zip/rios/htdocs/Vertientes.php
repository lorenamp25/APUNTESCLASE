<?php
  header('Access-Control-Allow-Origin: *'); 
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
    $conexion = mysqli_connect("localhost", "root", "", "rios");

    if($conexion->connect_error){
        print "Fallo al conectar con la base de datos. ".$conexion->connect_error;
        echo 0;
    }else{
        
        $sql = "SELECT id_vertiente,vertiente FROM `vertiente`";
        $resultados=mysqli_query($conexion,$sql) or die(mysqli_error());
        $datos=array();
        while ( $fila = mysqli_fetch_array($resultados, MYSQLI_ASSOC))
            {
            $datos[]=$fila;
            }
       
        echo(json_encode($datos));
        
        mysqli_close($conexion);
    }

?>