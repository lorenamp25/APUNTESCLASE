import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-rios',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './rios.component.html',
  styleUrl: './rios.component.css'
})
export class RiosComponent {
  @Input() cuenca: string = '0'
  cuencaSel: number = parseInt(this.cuenca)
  rio: string = ""
  rioAnt: string = ""
 
  Rios = [
    { id_rio: 1, rio: "Río Bidasoa", nacimiento: "Confluencia dos regatos Berdezir e Izpegui", desembocadura: "Mar Cantábrico (ría entre Hondarribia e Hendaia)", longitud: 67, id_cuenca: 1 },
    { id_rio: 2, rio: "Río Nervión", nacimiento: "Peña de Orduña", desembocadura: "Mar Cantábrico (No Ibaizabal en Basauri)", longitud: 69, id_cuenca: 1 },
    { id_rio: 3, rio: "Río Ibaizabal", nacimiento: "Montes Amboto e Udalaitz", desembocadura: "Mar Cantábrico (Portugalete, formando a ría de Bilbao)", longitud: 43, id_cuenca: 1 },
    { id_rio: 4, rio: "Río Asón", nacimiento: "Peña de Azalagua (Soba)", desembocadura: "Mar Cantábrico (ría de Limpias)", longitud: 39, id_cuenca: 2 },
    { id_rio: 5, rio: "Río Miera", nacimiento: "Portillo de Lunada (San Roque de Riomiera e Soba)", desembocadura: "Mar Cantábrico (ría de Cubas)", longitud: 41, id_cuenca: 2 },
    { id_rio: 6, rio: "Río Pas", nacimiento: "Pie de Castro Valnera e Peñas Negras (Vega de Pas)", desembocadura: "Mar Cantábrico (ría de Mogro)", longitud: 57, id_cuenca: 2 },
    { id_rio: 7, rio: "Río Besaya", nacimiento: "Cueto Ropero (Campoo de Enmedio)", desembocadura: "Mar Cantábrico (ría de San Martín de la Arena)", longitud: 58, id_cuenca: 2 },
    { id_rio: 8, rio: "Río Nansa", nacimiento: "Serra de Peña Labra", desembocadura: "Mar Cantábrico (ría de Tina Menor)", longitud: 46, id_cuenca: 2 },
    { id_rio: 9, rio: "Río Deva", nacimiento: "Serra de Peña Labra", desembocadura: "Mar Cantábrico (ría de Tina Mayor)", longitud: 64, id_cuenca: 2 },
    { id_rio: 10, rio: "Río Sella", nacimiento: "Val de Sajambre", desembocadura: "Mar Cantábrico (ría de Ribadesella)", longitud: 56, id_cuenca: 3 },
    { id_rio: 11, rio: "Río Nalón", nacimiento: "Porto de Tarna", desembocadura: "Mar Cantábrico (ría de Pravia)", longitud: 129, id_cuenca: 3 },
    { id_rio: 12, rio: "Río Narcea", nacimiento: "Fuentes del Narcea", desembocadura: "Río Nalón (Forcinas)", longitud: 97, id_cuenca: 3 },
    { id_rio: 13, rio: "Río Navia", nacimiento: "Serra do Rañadorio", desembocadura: "Mar Cantábrico (ría de Navia)", longitud: 159, id_cuenca: 3 },
    { id_rio: 14, rio: "Río Eo", nacimiento: "Montes do Cádabo", desembocadura: "Mar Cantábrico (ría do Eo)", longitud: 79, id_cuenca: 3 },
    { id_rio: 15, rio: "Río Tambre", nacimiento: "Montes de Bocelo", desembocadura: "Océano Atlántico (Ponte Nafonso)", longitud: 134, id_cuenca: 4 },
    { id_rio: 16, rio: "Río Ulla", nacimiento: "Fonte de Ulla", desembocadura: "Océano Atlántico (ría de Arousa)", longitud: 126, id_cuenca: 4 },
    { id_rio: 17, rio: "Río Eume", nacimiento: "Serra do Xistral (Montouto)", desembocadura: "Océano Atlántico (ría de Ares)", longitud: 100, id_cuenca: 4 },
    { id_rio: 18, rio: "Río Lérez", nacimiento: "Monte de San Bieito (Serra do Candán)", desembocadura: "Océano Atlántico (ría de Pontevedra)", longitud: 60, id_cuenca: 4 },
    { id_rio: 19, rio: "Río Miño", nacimiento: "Lagoa de Fonte Miña", desembocadura: "Océano Atlántico (A Guarda-Caminha)", longitud: 310, id_cuenca: 5 },
    { id_rio: 20, rio: "Río Sil", nacimiento: "Coto Albo", desembocadura: "Río Miño (Os Peares)", longitud: 225, id_cuenca: 5 },
    { id_rio: 21, rio: "Río Douro", nacimiento: "Picos de Urbión", desembocadura: "Océano Atlántico (Porto, Portugal)", longitud: 895, id_cuenca: 6 },
    { id_rio: 22, rio: "Río Águeda", nacimiento: "Navasfrías", desembocadura: "Río Douro (Barca de Alba)", longitud: 133, id_cuenca: 6 },
    { id_rio: 23, rio: "Río Zapardiel", nacimiento: "Lagoa de San Martín de las Cabezas (serra de Ávila)", desembocadura: "Río Douro (preto de Tordesillas)", longitud: 103, id_cuenca: 6 },
    { id_rio: 24, rio: "Río Duratón", nacimiento: "Serra de Somosierra", desembocadura: "Río Douro (Peñafiel)", longitud: 106, id_cuenca: 6 },
    { id_rio: 25, rio: "Río Adaja", nacimiento: "Entre a Serrota e S. de Ávila", desembocadura: "Río Douro (Valdestillas)", longitud: 163, id_cuenca: 6 },
    { id_rio: 26, rio: "Río Tormes", nacimiento: "Fonte Tormella, no prado Tormejón", desembocadura: "Río Douro (Villarino de los Aires)", longitud: 247, id_cuenca: 6 },
    { id_rio: 27, rio: "Río Valderaduey", nacimiento: "Monte de Río Camba", desembocadura: "Río Douro (Villagodio)", longitud: 146, id_cuenca: 6 },
    { id_rio: 28, rio: "Río Pisuerga", nacimiento: "Serra Albas, Puntas Luengas e Peña Labra", desembocadura: "Río Douro (preto de Simancas)", longitud: 275, id_cuenca: 6 },
    { id_rio: 29, rio: "Río Carrión", nacimiento: "Fontes Carrionas", desembocadura: "Río Pisuerga (Dueñas)", longitud: 179, id_cuenca: 6 },
    { id_rio: 30, rio: "Río Arlanzón", nacimiento: "Serra da Demanda", desembocadura: "Río Pisuerga", longitud: 115, id_cuenca: 6 },
    { id_rio: 31, rio: "Río Arlanza", nacimiento: "Serra da Demanda", desembocadura: "Río Arlanzón", longitud: 160, id_cuenca: 6 },
    { id_rio: 32, rio: "Río Esgueva", nacimiento: "Peña Cervera (Serra da Demanda)", desembocadura: "Río Pisuerga", longitud: 116, id_cuenca: 6 },
    { id_rio: 33, rio: "Río Esla", nacimiento: "Peña Prieta", desembocadura: "Río Douro (Villalcampo)", longitud: 275, id_cuenca: 6 },
    { id_rio: 34, rio: "Río Cea", nacimiento: "Fonte do Pescado (Prioro)", desembocadura: "Río Esla", longitud: 157, id_cuenca: 6 },
    { id_rio: 35, rio: "Río Cea", nacimiento: "Confluencia do río Luna e o río Omaña", desembocadura: "Río Esla", longitud: 162, id_cuenca: 6 },
    { id_rio: 36, rio: "Río Eria", nacimiento: "Montes do Teleno", desembocadura: "Río Órbigo", longitud: 110, id_cuenca: 6 },
    { id_rio: 37, rio: "Río Tera", nacimiento: "Serra de Vigo", desembocadura: "Río Esla (Bretocino)", longitud: 139, id_cuenca: 6 },
    { id_rio: 38, rio: "Río Huebra", nacimiento: "Pico Cervero (serra das Quilamas)", desembocadura: "Río Douro", longitud: 122, id_cuenca: 6 },
    { id_rio: 39, rio: "Río Yeltes", nacimiento: "Peña de Francia", desembocadura: "Río Huebra", longitud: 116, id_cuenca: 7 },
    { id_rio: 40, rio: "Río Texo", nacimiento: "Serra de Albarracín", desembocadura: "Océano Atlántico (Lisboa)", longitud: 1007, id_cuenca: 7 },
    { id_rio: 41, rio: "Río Guadarrama", nacimiento: "Siete Picos", desembocadura: "Río Texo", longitud: 132, id_cuenca: 7 },
    { id_rio: 42, rio: "Río Jarama", nacimiento: "Serra de Ayllón", desembocadura: "Río Texo (Aranjuez)", longitud: 194, id_cuenca: 7 },
    { id_rio: 43, rio: "Río Tajuña", nacimiento: "Proximidades de Maranchón", desembocadura: "Río Jarama (preto de Titulcia)", longitud: 225, id_cuenca: 7 },
    { id_rio: 44, rio: "Río Henares", nacimiento: "Serra Ministra", desembocadura: "Río Jarama", longitud: 160, id_cuenca: 7 },
    { id_rio: 45, rio: "Río Lozoya", nacimiento: "Macizo de Peñalara", desembocadura: "Río Jarama", longitud: 91, id_cuenca: 7 },
    { id_rio: 46, rio: "Río Manzanares", nacimiento: "Ventisquero de la Condesa", desembocadura: "Río Jarama", longitud: 92, id_cuenca: 7 },
    { id_rio: 47, rio: "Río Alberche", nacimiento: "Fonte do Alberche-Cañada Alta", desembocadura: "Río Texo (Talavera de la Reina)", longitud: 182, id_cuenca: 7 },
    { id_rio: 48, rio: "Río Tiétar", nacimiento: "Porto da Venta del Cojo", desembocadura: "Río Texo (Villarreal de San Carlos)", longitud: 170, id_cuenca: 7 },
    { id_rio: 49, rio: "Río Alagón", nacimiento: "Frades de la Sierra", desembocadura: "Río Texo (Alcántara)", longitud: 201, id_cuenca: 7 },
    { id_rio: 50, rio: "Río Salor", nacimiento: "Serra de Montánchez", desembocadura: "Río Texo", longitud: 120, id_cuenca: 7 },
    { id_rio: 51, rio: "Río Almonte", nacimiento: "Serra de Guadalupe", desembocadura: "Río Texo (preto de Garrovillas)", longitud: 97, id_cuenca: 7 },
    { id_rio: 52, rio: "Río Guadiela", nacimiento: "Serra de Cuenca", desembocadura: "Río Texo (encoro de Bolarque)", longitud: 115, id_cuenca: 7 },
    { id_rio: 53, rio: "Río Guadiana", nacimiento: "Altos de Cabrejas (Sistema Guadiana-Tablas de Daimiel-Cigüela)", desembocadura: "Océano Atlántico (Cabeza Alta, Ayamonte, fronteira con Portugal)", longitud: 967, id_cuenca: 8 },
    { id_rio: 54, rio: "Río Cigüela", nacimiento: "Altos de Cabrejas", desembocadura: "Río Guadiana (Tablas de Daimiel)", longitud: 225, id_cuenca: 8 },
    { id_rio: 55, rio: "Río Záncara", nacimiento: "Abia de la Obispalía", desembocadura: "Río Cigüela (Alcázar de San Juan)", longitud: 168, id_cuenca: 8 },
    { id_rio: 56, rio: "Río Jabalón", nacimiento: "Montiel", desembocadura: "Río Guadiana (cerca de Corral de Calatrava)", longitud: 153, id_cuenca: 8 },
    { id_rio: 57, rio: "Río Guadalupe", nacimiento: "Guadalupe", desembocadura: "Río Guadiana (preto de Peloche)", longitud: 93, id_cuenca: 8 },
    { id_rio: 58, rio: "Río Zújar", nacimiento: "Cerro de la Calaveruela", desembocadura: "Río Guadiana (encoro de La Serena)", longitud: 210, id_cuenca: 8 },
    { id_rio: 59, rio: "Río Matachel", nacimiento: "El Retamar", desembocadura: "Río Guadiana (Don Álvaro)", longitud: 124, id_cuenca: 8 },
    { id_rio: 60, rio: "Río Ardila", nacimiento: "Serra de Tudia", desembocadura: "Río Guadiana (Moura, Portugal)", longitud: 116, id_cuenca: 8 },
    { id_rio: 61, rio: "Río Tinto", nacimiento: "Minas de Riotinto", desembocadura: "Océano Atlántico (Canle de Palos de la Frontera)", longitud: 93, id_cuenca: 8 },
    { id_rio: 62, rio: "Río Odiel", nacimiento: "Serra de Aracena", desembocadura: "Océano Atlántico (ría de Huelva)", longitud: 121, id_cuenca: 8 },
    { id_rio: 63, rio: "Río Guadalquivir", nacimiento: "Serras do Pozo e Cazorla", desembocadura: "Océano Atlántico (Sanlúcar de Barrameda)", longitud: 657, id_cuenca: 9 },
    { id_rio: 64, rio: "Río Guadiana Menor", nacimiento: "Confluencia do río Fardes e o río Guardal", desembocadura: "Río Guadalquivir", longitud: 182, id_cuenca: 9 },
    { id_rio: 65, rio: "Río Guadajoz", nacimiento: "Unión de Castril e do Baza", desembocadura: "Río Guadalquivir (Torreperojil)", longitud: 114, id_cuenca: 9 },
    { id_rio: 66, rio: "Río Genil", nacimiento: "Serras de Priego e Lucena", desembocadura: "Río Guadalquivir (ao sur de Córdoba)", longitud: 337, id_cuenca: 9 },
    { id_rio: 67, rio: "Río Guadaíra", nacimiento: "Pico Veleta-Serra Nevada", desembocadura: "Río Guadalquivir (preto de Alcalá de Guadaíra)", longitud: 89, id_cuenca: 9 },
    { id_rio: 68, rio: "Río Guadalimar", nacimiento: "Serra de Algodonales Cerro Almenara", desembocadura: "Río Guadalquivir (Baeza)", longitud: 167, id_cuenca: 9 },
    { id_rio: 69, rio: "Río Corbones", nacimiento: "Serras de Blanquilla, Mollina e Borbollones", desembocadura: "Río Guadalquivir (Alcolea del Río)", longitud: 177, id_cuenca: 9 },
    { id_rio: 70, rio: "Jándula", nacimiento: "Uníón dos ríos Montoro, Ojailén e Fresnedas, en Serra Madrona", desembocadura: "Río Guadalquivir (Marmolejo)", longitud: 141, id_cuenca: 9 },
    { id_rio: 71, rio: "Río Bembézar", nacimiento: "Preto de Azuaga", desembocadura: "Río Guadalquivir (preto de Palacio de Moratalla)", longitud: 126, id_cuenca: 9 },
    { id_rio: 72, rio: "Río Viar", nacimiento: "Porto Cañada (Serra de Tentudía)", desembocadura: "Río Guadalquivir", longitud: 124, id_cuenca: 9 },
    { id_rio: 73, rio: "Río Guadalete", nacimiento: "Serra do Pinar e Serra do Endrinal", desembocadura: "Océano Atlántico (baía de Cádiz, Puerto de Santa María)", longitud: 173, id_cuenca: 9 },
    { id_rio: 74, rio: "Río Guadiaro", nacimiento: "Serra de Tolox", desembocadura: "Mar Mediterráneo (San Enrique de Guadioso)", longitud: 79, id_cuenca: 10 },
    { id_rio: 75, rio: "Río Guadalhorce", nacimiento: "Porto das Alazores", desembocadura: "Mar Mediterráneo (preto de Punta del Pino)", longitud: 154, id_cuenca: 10 },
    { id_rio: 76, rio: "Río Guadalmedina", nacimiento: "Pico da Cruz, na Serra de Camarolos", desembocadura: "Mar Mediterráneo (Málaga)", longitud: 47, id_cuenca: 10 },
    { id_rio: 77, rio: "Río Guadalfeo", nacimiento: "Confluencia dos ríos Lanjarón, Boqueira e Trevélez", desembocadura: "Mar Mediterráneo (Salobreña)", longitud: 72, id_cuenca: 10 },
    { id_rio: 78, rio: "Río Adra ou Grande", nacimiento: "Preto do Puerto de la Ragua", desembocadura: "Mar Mediterráneo (ao leste de Adra)", longitud: 47, id_cuenca: 10 },
    { id_rio: 79, rio: "Río Andarax ou Almería", nacimiento: "Faldas do Chullo", desembocadura: "Mar Mediterráneo (preto de Almería)", longitud: 62, id_cuenca: 10 },
    { id_rio: 80, rio: "Río Almanzora", nacimiento: "Llanos de Huelgo, Serra de Baza", desembocadura: "Mar Mediterráneo (Cerros Colorados)", longitud: 105, id_cuenca: 10 },
    { id_rio: 81, rio: "Río Segura", nacimiento: "Serra de Segura", desembocadura: "Mar Mediterráneo (Guardamar del Segura)", longitud: 325, id_cuenca: 11 },
    { id_rio: 82, rio: "Río Mundo", nacimiento: "Calar del Mundo", desembocadura: "Río Segura", longitud: 150, id_cuenca: 11 },
    { id_rio: 83, rio: "Río Guadalentín", nacimiento: "Serra de María", desembocadura: "Río Segura", longitud: 121, id_cuenca: 11 },
    { id_rio: 84, rio: "Río Xúcar", nacimiento: "Ojuelos de Valdeminguete, Serra de Tragacete", desembocadura: "Mar Mediterráneo (Cullera)", longitud: 498, id_cuenca: 12 },
    { id_rio: 85, rio: "Río Cabriel", nacimiento: "Muela de San Juan", desembocadura: "Río Xúcar (Cofrentes)", longitud: 220, id_cuenca: 12 },
    { id_rio: 86, rio: "Río Magre", nacimiento: "Norte de Utiel", desembocadura: "Río Xúcar", longitud: 130, id_cuenca: 12 },
    { id_rio: 87, rio: "Río Valdemembra", nacimiento: "Solera de Gabaldón", desembocadura: "Río Xúcar (Valdeganga)", longitud: 85, id_cuenca: 12 },
    { id_rio: 88, rio: "Río Turia (ou Guadalaviar)", nacimiento: "Muela de San Juan (Montes Universais)", desembocadura: "Mar Mediterráneo (El Grao, Valencia)", longitud: 280, id_cuenca: 12 },
    { id_rio: 89, rio: "Río Millars", nacimiento: "Alto de Torrijas", desembocadura: "Mar Mediterráneo (Torre Almassora)", longitud: 156, id_cuenca: 12 },
    { id_rio: 90, rio: "Río Ebro", nacimiento: "Fontibre", desembocadura: "Mar Mediterráneo (Amposta)", longitud: 910, id_cuenca: 13 },
    { id_rio: 91, rio: "Río Zadorra", nacimiento: "Porto de Opakua", desembocadura: "Río Ebro (preto de Miranda de Ebro)", longitud: 78, id_cuenca: 13 },
    { id_rio: 92, rio: "Río Najerilla", nacimiento: "Confluencia dos ríos Canales e Neila", desembocadura: "Río Ebro (preto de Torremontalbo)", longitud: 100, id_cuenca: 13 },
    { id_rio: 93, rio: "Río Ega", nacimiento: "Preto de Lagrán", desembocadura: "Río Ebro (preto de San Adrián)", longitud: 113, id_cuenca: 13 },
    { id_rio: 94, rio: "Río Cidacos", nacimiento: "Porto de Oncala", desembocadura: "Río Ebro (preto de Calahorra)", longitud: 83, id_cuenca: 13 },
    { id_rio: 95, rio: "Río Aragón", nacimiento: "Val de Astún", desembocadura: "Río Ebro (Villafranca)", longitud: 197, id_cuenca: 13 },
    { id_rio: 96, rio: "Río Arga", nacimiento: "collado de Urquiaga", desembocadura: "Río Aragón", longitud: 145, id_cuenca: 13 },
    { id_rio: 97, rio: "Río Alhama", nacimiento: "Serra do Madero", desembocadura: "Río Ebro (Alfaro)", longitud: 84, id_cuenca: 13 },
    { id_rio: 98, rio: "Río Arba", nacimiento: "Serra de Santo Domingo", desembocadura: "Río Ebro (Gallur)", longitud: 96, id_cuenca: 13 },
    { id_rio: 99, rio: "Río Jalón", nacimiento: "Serra Ministra", desembocadura: "Río Ebro (entre Cabañas de Ebro e Torres de Berrellén)", longitud: 224, id_cuenca: 13 },
    { id_rio: 100, rio: "Río Jiloca", nacimiento: "Serra de Albarracín", desembocadura: "Río Jalón (preto de Calatayud)", longitud: 126, id_cuenca: 13 },
    { id_rio: 101, rio: "Río Huerva", nacimiento: "Fonfría (Teruel)", desembocadura: "Río Ebro (Zaragoza)", longitud: 135, id_cuenca: 13 },
    { id_rio: 102, rio: "Río Gállego", nacimiento: "Próximo ao Porto de Portalet", desembocadura: "Río Ebro (Zaragoza)", longitud: 203, id_cuenca: 13 },
    { id_rio: 103, rio: "Río Aguasvivas", nacimiento: "Fonfría\/Allueva (Teruel)", desembocadura: "Río Ebro (La Zaida)", longitud: 100, id_cuenca: 13 },
    { id_rio: 104, rio: "Río Martín", nacimiento: "Portalrubio (Teruel)", desembocadura: "Río Ebro (Escatrón)", longitud: 98, id_cuenca: 13 },
    { id_rio: 105, rio: "Río Guadalope", nacimiento: "Serra de Gúdar", desembocadura: "Río Ebro (preto de Caspe)", longitud: 182, id_cuenca: 13 },
    { id_rio: 106, rio: "Río Segre", nacimiento: "Monts Louis (Francia)", desembocadura: "Río Ebro (Mequinenza)", longitud: 261, id_cuenca: 13 },
    { id_rio: 107, rio: "Río Cinca", nacimiento: "Circo de Pineta", desembocadura: "Río Segre (preto de Mequinenza)", longitud: 170, id_cuenca: 13 },
    { id_rio: 108, rio: "Río Ésera", nacimiento: "Macizo da Maladeta", desembocadura: "Río Cinca", longitud: 99, id_cuenca: 13 },
    { id_rio: 109, rio: "Río Noguera Ribagorzana", nacimiento: "Macizo da Maladeta", desembocadura: "Río Segre (en Corbins)", longitud: 133, id_cuenca: 13 },
    { id_rio: 110, rio: "Río Noguera Pallaresa", nacimiento: "Val de Arán", desembocadura: "Río Segre", longitud: 154, id_cuenca: 13 },
    { id_rio: 111, rio: "Río Matarraña", nacimiento: "Portos de Beceite", desembocadura: "Río Ebro", longitud: 97, id_cuenca: 13 },
    { id_rio: 112, rio: "Río Francolí", nacimiento: "Ao norte de Espluga de Francolí", desembocadura: "Mar Mediterráneo (Tarragona)", longitud: 58, id_cuenca: 14 },
    { id_rio: 113, rio: "Río Llobregat", nacimiento: "Serra de Cadí, entre Coll de Jou e o de Toses", desembocadura: "Mar Mediterráneo (El Prat de Llobregat)", longitud: 157, id_cuenca: 14 },
    { id_rio: 114, rio: "Río Cardener", nacimiento: "Fonts del Cardener", desembocadura: "Río Llobregat", longitud: 87, id_cuenca: 14 },
    { id_rio: 115, rio: "Río Tordera", nacimiento: "Vertente occidental do Montseny", desembocadura: "Mar Mediterráneo (Malgrat de Mar)", longitud: 50, id_cuenca: 14 },
    { id_rio: 116, rio: "Río Ter", nacimiento: "Ulldeter", desembocadura: "Mar Mediterráneo (Torroella de Montgrí)", longitud: 209, id_cuenca: 14 },
    { id_rio: 117, rio: "Río Fluvià", nacimiento: "Grau Olot", desembocadura: "Mar Mediterráneo (golfo de Roses)", longitud: 98, id_cuenca: 14 }
  ]
  ngOnChanges(): void {
    console.log(this.cuenca)
    this.cuencaSel = parseInt(this.cuenca)
  }

  ponerOpacidad() {
    document.getElementById("tablaRios")?.setAttribute("style", "opacity: 1")

  }
  ponerTransparente() {
    document.getElementById("tablaRios")?.setAttribute("style", "opacity: 0.2")

  }

  cambioRio() {
    document.getElementById("r" + this.rio)?.classList.add("destacado")
    document.getElementById("r" + this.rioAnt)?.classList.remove("destacado")
   
    this.rioAnt = this.rio
  }

}





