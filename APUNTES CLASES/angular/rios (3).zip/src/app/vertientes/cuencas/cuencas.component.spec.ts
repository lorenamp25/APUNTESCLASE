import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CuencasComponent } from './cuencas.component';

describe('CuencasComponent', () => {
  let component: CuencasComponent;
  let fixture: ComponentFixture<CuencasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CuencasComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CuencasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
