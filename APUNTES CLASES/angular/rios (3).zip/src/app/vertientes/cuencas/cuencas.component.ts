import { Component, Input, OnChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RiosComponent } from './rios/rios.component'
import { NumberFormatStyle } from '@angular/common';

@Component({
  selector: 'app-cuencas',
  standalone: true,
  imports: [FormsModule,RiosComponent],
  templateUrl: './cuencas.component.html',
  styleUrl: './cuencas.component.css'
})
export class CuencasComponent implements OnChanges {

  @Input() vertiente: string = '0'
  vertienteSel:NumberFormatStyle = parseInt(this.vertiente)
  cuenca:string=""
  Cuencas = [
    {
      Id_cuenca: 1,
      Cuenca: "cuenca del Norte (País Vasco)",
      Vertiente: 1
    },
    {
      Id_cuenca: 2,
      Cuenca: "cuenca del Norte (Cantabria)",
      Vertiente: 1
    },
    {
      Id_cuenca: 3,
      Cuenca: "cuenca del Norte (Asturias)",
      Vertiente: 1
    },
    {
      Id_cuenca: 4,
      Cuenca: "cuenca de la Costa de Galicia",
      Vertiente: 2
    },
    {
      Id_cuenca: 5,
      Cuenca: "cuenca del Miño",
      Vertiente: 2
    },
    {
      Id_cuenca: 6,
      Cuenca: "cuenca del Duero",
      Vertiente: 2
    },
    {
      Id_cuenca: 7,
      Cuenca: "cuenca del Tajo",
      Vertiente: 2
    },
    {
      Id_cuenca: 8,
      Cuenca: "cuenca del Guadiana",
      Vertiente: 2
    },
    {
      Id_cuenca: 9,
      Cuenca: "cuenca del Guadalquivir",
      Vertiente: 2
    },
    {
      Id_cuenca: 10,
      Cuenca: "cuenca del Sur",
      Vertiente: 3
    },
    {
      Id_cuenca: 11,
      Cuenca: "cuenca del Segura",
      Vertiente: 3
    },
    {
      Id_cuenca: 12,
      Cuenca: "cuenca del Jucar",
      Vertiente: 3
    },
    {
      Id_cuenca: 13,
      Cuenca: "cuenca del Ebro",
      Vertiente: 3
    },
    {
      Id_cuenca: 14,
      Cuenca: "cuencas Internas de Cataluña",
      Vertiente: 3
    }
  ]
  ngOnChanges(): void {
    console.log(this.vertiente)
    this.vertienteSel = parseInt(this.vertiente)
  }

  cambioVertiente(vertiente: string) {
    this.vertienteSel = parseInt(vertiente)
  }

}
