import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CuencasComponent } from './cuencas/cuencas.component'

@Component({
  selector: 'app-vertientes',
  standalone: true,
  imports: [CuencasComponent, FormsModule],
  templateUrl: './vertientes.component.html',
  styleUrl: './vertientes.component.css'
})
export class VertientesComponent {
  vertiente:string = ""
  Vertientes = [
    {
      Id_vertiente: 1,
      Vertiente: "Cantábrica"
    },
    {
      Id_vertiente: 2,
      Vertiente: "Atlántica"
    },
    {
      Id_vertiente: 3,
      Vertiente: "Mediterranea"
    }
  ]

}
