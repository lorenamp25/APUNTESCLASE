import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VertientesComponent } from './vertientes.component';

describe('VertientesComponent', () => {
  let component: VertientesComponent;
  let fixture: ComponentFixture<VertientesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VertientesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VertientesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
