DROP DATABASE IF EXISTS turismo;
CREATE DATABASE turismo CHARACTER SET utf8mb4;
USE turismo;

CREATE TABLE IF NOT EXISTS REFUGIOS(
    nombre VARCHAR(256),
    acceso VARCHAR(256),
    observaciones VARCHAR(256),
    señalizacionexterna VARCHAR(100),
    latitud DECIMAL(24, 20),
    longitud DECIMAL(24, 20)
);

CREATE TABLE IF NOT EXISTS ALOJAMIENTOS(
    establecimiento VARCHAR(100),
    tipo VARCHAR(100),
    categoria VARCHAR(100),
    nombre VARCHAR(256),
    municipio VARCHAR(100),
    web VARCHAR(256),
    telefono INT(11),
    wikidata VARCHAR(100),
    imagenmunicipio VARCHAR(256),
    poblacionmunicipio INT(11),
    longitud DECIMAL(24, 20),
    latitud DECIMAL(24, 20)
);

INSERT INTO
    REFUGIOS(
        nombre,
        acceso,
        observaciones,
        señalizacionexterna,
        latitud,
        longitud
    )
VALUES
    (
        'Refugio del Pastor',
        NULL,
        'Refugio de 20x20m adosado a la taina',
        'No',
        41.97594421811293,
        -2.4216914915689713
    ),

(
    'Costalago',
    'Pista forestal desde Hontoria del Pinar y desde Espeja de San Marcelino',
    'Tiene cerca una fuente',
    'No',
    41.8115972068461,
    -3.1753284543579663
),

(
    'Fuente del Pino',
    'Pista forestal desde Santa María de las Hoyas',
    'Tiene cerca una fuente',
    'No',
    41.79015688693406,
    -3.1386832427237423
),

(
    'Refugio del Cristo Sierra',
    NULL,
    'Refugio de piedra con dos estancias: una capilla y una estancia comedor-refugio con chimenea. Techo 2,15m, altura max. 4m aprox., anchura muro 40 cm. El interior del refugio tiene las paredes llenas de pintadas. Hay tres bancos y una mesa en el interior',
    'No',
    42.85135142842837,
    -4.741300924280982
),

(
    'Refugio de Santa Marina',
    NULL,
    'Refugio de montaña construído en piedra, en un enclave muy emblemático. Interior abajo: 480anchox390largox240alt. Arriba: 480x390x204en el centro y cero a los extremos. Frente ext. Incl. Alas de piedra 11,2 m',
    'No',
    42.9742768284834,
    -4.606141419814238
),

(
    'Refugio de Mazobre',
    NULL,
    'Refugio con paredes de piedra rejuntada. Anchura de muros 60 cm. y cubierta de tejas coloración gris. Tiene una puerta y una ventana, ambas de madera en la fachada. Dotaciones: 4bancos de metal, dos mesas en el interior y una escalera metalica en el inte',
    'No',
    42.952532701694444,
    -4.777062127604179
),

(
    'Refugio de Postil Soña',
    NULL,
    'Refugio de montaña. De planta rectangular con muros de piedra y cubierta de teja. Altura total: 1,80+2,30m, anchura pared 50 cm. Dotaciones: mesa de madera tipo camping con dos bancos acoplados, banco de piedra en el interior y banco de piedra en la fach',
    'No',
    42.960162583759306,
    -4.693226582414925
),

(
    'Caseta refugio junto al sendero',
    NULL,
    'Caseta refugio con estructura de madera y cubierta de tejas. Paredes de mampostería de coloración rojiza. Banco interior de madera en ángulo: 40 anch.x 50 alt x (1,80+3,50) long. Anch.muro 50, alt vita ant 2,70.',
    'No',
    42.91675954859096,
    -4.475459701396004
),

(
    'Casa del Dolar',
    'Río Frío-La Mina-Caseta el Dolar',
    'Fuente natural cercana.',
    'No',
    42.0456252507547,
    -2.944957870281135
),

(
    'Refugio en Matanoso',
    NULL,
    'RDM.01 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.132400914148484,
    -6.779486450184807
),

(
    'Refugio de la Agrupación Montañera Zamorana en Chanos de Anta',
    NULL,
    'RDM.02 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.15259603338269,
    -6.726680748182988
),

(
    'Refugio de la majada',
    NULL,
    'RDM.04 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.186176385904965,
    -6.7159186909896835
),

(
    'Refugio de Cubellos',
    NULL,
    'RDM.06 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.06988757250989,
    -6.7542775462475735
),

(
    'Refugio de Peña Cueva',
    NULL,
    'RDM.07 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.08640052552907,
    -6.750341153581084
),

(
    'Refugio de Puente Porto',
    NULL,
    'RDM.08 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.11748654855109,
    -6.828126383030869
),

(
    'Refugio en As Corvaceiras',
    NULL,
    'RDM.09 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.149923466714846,
    -6.860486300839933
),

(
    'Refugio de Valdesirgas',
    NULL,
    'RDM.10 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.14798903170844,
    -6.877477122158696
),

(
    'Chozo de la majada de Valdesirgas',
    NULL,
    'RDM.11 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.135728118108716,
    -6.880369443224023
),

(
    'Refugio de la Sierra de Rábano',
    NULL,
    'RDM.12 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.177218948686125,
    -6.809163907820946
),

(
    'Refugio de los Puertos de Ungilde y Quintana',
    NULL,
    'RDM.13 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.12518828682831,
    -6.833043090631666
),

(
    'Refugio de la Porpasa',
    NULL,
    'RDM.15 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.19218599582605,
    -6.885127307819423
),

(
    'Refugio de Corrais',
    NULL,
    'RDM.16 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.1853289587033,
    -6.919145558832725
),

(
    'Refugio de Pescadores Coto de Galende',
    NULL,
    'RDP.01 / Sirve principalmente para dar cobijo a los pescadores que vienen a este coto.',
    'Si',
    42.122895365559515,
    -6.6858493913642665
),

(
    'Refugio de Pescadores Orilla del Lago',
    NULL,
    'RDP.02 / Se utiliza como centro de socorro durante los meses veraniegos.',
    'Si',
    42.1175221550251,
    -6.720958987775617
),

(
    'Refugio de montaña de Ríopedro',
    NULL,
    'En el GR84',
    'Si',
    42.21494586198043,
    -6.756860605873188
),

(
    'Refugio de montaña de Campo Laiol',
    NULL,
    'En el GR84',
    'Si',
    42.102909333253265,
    -6.86509247235083
),

(
    'Refugio de montaña del Marmolin',
    NULL,
    'En el GR84',
    'Si',
    42.086350718761736,
    -6.818191986359196
),

(
    'Refugio de montaña de Sotillo de Sanabria',
    NULL,
    'En el GR84',
    'Si',
    42.102446350535324,
    -6.759349270005513
),

(
    'Refugio de la Agrupación Montañera Zamorana en Vega de Conde',
    NULL,
    'RDM.03 / Cabaña construida con piedra y cubierta de pizarras. Están equipadas con chimeneas y tarimas - camas.',
    'Si',
    42.20435280323211,
    -6.770258176544844
),

(
    'Refugiode montaña de la Majada Murias',
    NULL,
    'En el GR84',
    'Si',
    42.192225638785395,
    -6.725076889697868
),

(
    'Ocejo',
    NULL,
    'Se puede acceder por una pista forestal en vehículo pero restringida a vehiculos autorizados. Se puede solicitar permiso a la Casa Forestal.',
    'No',
    42.71160479711914,
    -3.419929409591949
),

(
    'Pociles',
    NULL,
    'Se puede acceder por una pista forestal en vehículo pero restringida a vehiculos autorizados. Se puede solicitar permiso a la Casa Forestal.',
    'No',
    42.76145633123603,
    -3.399780756652776
),

(
    'Refugio Pico del Ángel',
    'Pista forestal de tierra-grava',
    'Gestionado desde La Casa del Parque. Punto de agua no potable para extinción de incendios forestales. Señalización usos y servicios.',
    'Si',
    43.06645719928565,
    -3.653533502410445
),

(
    'Ampurias-Finisterre-Tramo leonés',
    NULL,
    'De madera y piedra',
    'No',
    43.05817191169544,
    -4.792625457655235
),

(
    'Aprisco La Horcada',
    NULL,
    'Paraje: La Horcada',
    'No',
    43.081045266735245,
    -5.135296497925694
),

(
    'Arroyo de Orpiñas',
    NULL,
    'Piedra',
    'No',
    43.05817191169544,
    -4.792625457655235
),

(
    'Becenes',
    NULL,
    'Paraje: Becenes',
    'No',
    43.09371144340194,
    -5.067122901450807
),

(
    'Boca Culebrejas',
    NULL,
    'Paraje: Boca Culebrejas',
    'No',
    43.05817191169544,
    -4.792625457655235
),

(
    'Bocivacas',
    NULL,
    'No enviado archivo anterior',
    'No',
    43.04715473765325,
    -5.2245026490576985
),

(
    'Bustraniego',
    NULL,
    'Paraje: Bustraniego',
    'No',
    42.93901876116236,
    -5.018920797201117
),

(
    'Campomuelle',
    NULL,
    'Paraje: Campomuelle',
    'No',
    43.00902824407005,
    -5.351889598568266
),

(
    'Carcedo',
    NULL,
    'Paraje: Carcedo',
    'No',
    43.087871032123104,
    -5.120321287274807
),

(
    'Carrerina blanca',
    NULL,
    'Caseta madera elevada',
    'No',
    43.00979779437119,
    -5.214335285370457
),

(
    'Castillejo',
    NULL,
    'Ganaderia',
    'No',
    43.00911506599,
    -5.044112561379165
),

(
    'Cerranzana',
    NULL,
    'No enviado archivo anterior',
    'No',
    43.06914259223937,
    -5.10623178646481
),

(
    'Collada San Martín',
    NULL,
    'Tiene ficha hecha',
    'No',
    42.906545845191296,
    -5.01482573955386
),

(
    'Collado Jermoso (Federacion De Montaña)',
    NULL,
    'Paraje: Collado Jermoso',
    'No',
    43.173005728877904,
    -4.869441985094073
),

(
    'Corral de los lobos',
    NULL,
    'Tiene ficha hecha',
    'No',
    42.904475945732855,
    -4.990869645305585
),

(
    'Cosalines',
    NULL,
    'Ganaderia',
    'No',
    43.03509898136123,
    -5.159765547967992
),

(
    'El Collado-Majada Uña',
    NULL,
    'Ganaderia',
    'No',
    43.089549476750896,
    -5.151854733565384
),

(
    'Erendia',
    NULL,
    'Ganaderia',
    'No',
    43.026948096588825,
    -5.134584436972001
),

(
    'Fontasquesa',
    NULL,
    'Paraje: Fontasquesa',
    'No',
    43.03595891242747,
    -5.246306507272344
),

(
    'Gustalapiedra',
    NULL,
    'Hecho 2001',
    'No',
    42.98191587098687,
    -4.816098745493999
),

(
    'La Cebada',
    NULL,
    'ganaderia',
    'No',
    43.08803994615642,
    -4.973081516096615
),

(
    'La Fonfria',
    NULL,
    'Paraje: La Fonfria',
    'No',
    43.09484179388085,
    -5.116858710496304
),

(
    'La Guaria',
    NULL,
    'Caseta madera elevada',
    'No',
    43.04375199275019,
    -5.282532266753339
),

(
    'La Horcada',
    NULL,
    'Paraje: La Horcada',
    'No',
    43.081584883540714,
    -5.134169800987744
),

(
    'La Oscura',
    NULL,
    'caseta madera elevada',
    'No',
    43.015632987885716,
    -5.235149884192862
),

(
    'La Pared',
    NULL,
    'Paraje: La Pared',
    'No',
    43.03852408689648,
    -5.173536712985041
),

(
    'La Prada',
    NULL,
    'Paraje: La Prada (El Joberon)',
    'No',
    42.99941475195936,
    -4.914070597834728
),

(
    'La Traviesa',
    NULL,
    'Abierto 24h',
    'No',
    42.9476817219198,
    -5.096306182796821
),

(
    'Lago Isoba',
    NULL,
    'Paraje: Lago Isoba',
    'No',
    43.061597155657005,
    -5.321034070492635
),

(
    'Las Coronas',
    NULL,
    'tiene ficha hecha',
    'No',
    42.87927424137862,
    -4.99686433020586
),

(
    'Las Hazas',
    NULL,
    'Madera o piedra',
    'No',
    43.05817191169544,
    -4.792625457655235
),

(
    'Las Rebequeras',
    NULL,
    'Paraje: Las Rebequeras',
    'No',
    42.94315559666301,
    -5.113888930012119
),

(
    'Llampas',
    NULL,
    'Abierto 24h',
    'No',
    42.90268710729137,
    -5.090187402460484
),

(
    'Llampiellas',
    NULL,
    'Abierto 24h',
    'No',
    42.90523410655962,
    -5.093702249757531
),

(
    'Llorada',
    NULL,
    'Abierto 24h',
    'No',
    42.997225008414176,
    -5.114541067703276
),

(
    'Llos',
    NULL,
    'Paraje: Llos',
    'No',
    43.16075166865407,
    -4.957587342733542
),

(
    'Lois',
    NULL,
    'Cerrado',
    'No',
    42.98203138836932,
    -5.126363774735699
),

(
    'Los Acebos',
    NULL,
    'Paraje: Los Acebos',
    'No',
    42.954569575627595,
    -4.856229712404533
),

(
    'Los Castros',
    NULL,
    'Abierto 24h',
    'No',
    42.96451785630882,
    -5.125228562514807
),

(
    'Los Llanos',
    NULL,
    'Solo se observa antigua planta',
    'No',
    42.89735231555927,
    -5.182213659208334
),

(
    'Los Portales',
    NULL,
    'Paraje: Los Portales (Valdosin)',
    'No',
    43.020669116067616,
    -5.210973845171479
),

(
    'Luriana Alta',
    NULL,
    'Paraje: Luriana Alta',
    'No',
    43.084475232003356,
    -4.82721702907324
),

(
    'Luriana Baja',
    NULL,
    'Paraje: Luriana Baja',
    'No',
    43.0846880815015,
    -4.847273986531815
),

(
    'Machoril (Caseta)',
    NULL,
    'Paraje: Machoril',
    'No',
    42.99108148392111,
    -4.845658561506482
),

(
    'Maganaves',
    NULL,
    'Paraje: Puerto De Maganaves',
    'No',
    42.982919253289765,
    -4.850609841869053
),

(
    'Majada Lario (Riosol)',
    NULL,
    'No enviado archivo anterior',
    'No',
    43.075224154160246,
    -5.176499231042268
),

(
    'Majada Montó (Las Hazas)',
    NULL,
    'Ganaderia',
    'No',
    43.07219817443717,
    -4.916971840856555
),

(
    'Majada Redihorno',
    NULL,
    'Ganadería (en listado antes Camperas)',
    'No',
    42.96279653527303,
    -5.092654465781673
),

(
    'Mataferrera',
    NULL,
    'caseta madera elevada',
    'No',
    43.02426197441236,
    -5.281527064889101
),

(
    'Melendrín',
    NULL,
    'Ganaderia',
    'No',
    43.0699084291769,
    -5.129109769986513
),

(
    'Mirva-Rabanal',
    NULL,
    'Paraje: Mirva',
    'No',
    43.05817191169544,
    -4.792625457655235
),

(
    'Monte Ranedo',
    NULL,
    'Paraje: Monte Ranedo',
    'No',
    43.047801512161264,
    -5.083597148189817
),

(
    'Monte Viejo',
    NULL,
    'Ganaderia',
    'No',
    42.90337310489564,
    -4.907057084734319
),

(
    'Morro Las Vegas',
    NULL,
    'Ganaderia',
    'No',
    43.04353569285268,
    -5.009322983450417
),

(
    'Mostajal',
    NULL,
    'Ganaderia',
    'No',
    43.09765734497785,
    -4.84490597704534
),

(
    'Naranco',
    NULL,
    'Paraje: Naranco',
    'No',
    43.05010597896376,
    -4.7652827416128405
),

(
    'Peña Terrionda',
    NULL,
    'Cerrado',
    'No',
    42.95484699594451,
    -5.1732879963861595
),

(
    'Peña Todos Los Vientos',
    NULL,
    'Paraje: Peña Todos Los Vientos',
    'No',
    43.0171547561642,
    -5.146991124924779
),

(
    'Peñalba',
    NULL,
    'Paraje: Peñalba',
    'No',
    42.94708683373893,
    -4.820804115535256
),

(
    'Pescadores',
    NULL,
    'Cerrado',
    'No',
    42.92644831992824,
    -5.112643750089987
),

(
    'Picones',
    NULL,
    'Paraje: Picones',
    'No',
    42.91996363173331,
    -4.866353668543927
),

(
    'Piedrashitas',
    NULL,
    'Paraje: Piedrashitas',
    'No',
    43.13486877113639,
    -4.980908024720083
),

(
    'Piedrasobas',
    NULL,
    'Paraje: Piedrasobas',
    'No',
    43.072173152760705,
    -4.779620468219563
),

(
    'Puerma',
    NULL,
    'Paraje: Puerma',
    'No',
    43.092799318410734,
    -4.85728867700131
),

(
    'Puerto de Horcadas',
    NULL,
    'Paraje: Puerto De Horcadas',
    'No',
    42.924577429882106,
    -5.0364701492643755
),

(
    'Puerto Grande',
    NULL,
    'Planta circular, paredes de piedra, techo de escoba',
    'No',
    42.97974958874539,
    -5.116219297714165
),

(
    'Recubiles',
    NULL,
    'Paraje: Recubiles',
    'No',
    42.9651077679966,
    -5.178658403368829
),

(
    'Recubiles Aprisco',
    NULL,
    'Paraje: Recubiles',
    'No',
    42.96473136515896,
    -5.179654540464292
),

(
    'Río la Puerta',
    NULL,
    'No enviado archivo anterior',
    'No',
    43.069902837816635,
    -5.0870386530339875
),

(
    'Riosol',
    NULL,
    'Paraje: Riosol',
    'No',
    43.076085630711916,
    -5.215332138516384
),

(
    'Roza La Calle',
    NULL,
    'Paraje: Roza La Calle',
    'No',
    42.999836699265146,
    -4.8205761092021495
),

(
    'Salamón',
    NULL,
    'Abierto 24h',
    'No',
    42.95808262783125,
    -5.108638616034508
),

(
    'San Miguel',
    NULL,
    'Ganaderia',
    'No',
    43.07346716165321,
    -5.158546131094257
),

(
    'Subida Tronisco',
    NULL,
    'Caseta madera elevada',
    'No',
    43.0491291646722,
    -5.265626556929536
),

(
    'Susarón',
    NULL,
    'Caseta madera elevada',
    'No',
    42.990515640011246,
    -5.30627977924551
),

(
    'Tejedo',
    NULL,
    'Solo se observa la antigua planta',
    'No',
    42.888744988973095,
    -5.109892969296372
),

(
    'Tejedo',
    NULL,
    'Ganaderia',
    'No',
    43.05439320859396,
    -4.847690281624076
),

(
    'Trapa',
    NULL,
    'Abierto 24h',
    'No',
    42.8985020579179,
    -5.087170562550859
),

(
    'Tronisco',
    NULL,
    'Paraje: Tronisco',
    'No',
    43.050284634633314,
    -5.250366235976981
),

(
    'Valcarque',
    NULL,
    'Ganaderia',
    'No',
    43.08231913101958,
    -4.913231716585791
),

(
    'Valdesalamón',
    NULL,
    'Levantamiento reciente, paredes de piedra cimentada, techo de escoba',
    'No',
    42.94315190633294,
    -5.113150213627782
),

(
    'Valdesolle',
    NULL,
    'Paraje: Valdesolle',
    'No',
    42.97824941683178,
    -5.20733705292724
),

(
    'Vallerianes',
    NULL,
    'Caseta madera elevada',
    'No',
    43.03365709319009,
    -5.283306329793517
),

(
    'Vallines',
    NULL,
    'Paraje: Vallines De Arriba',
    'No',
    43.07391442256413,
    -4.856420779043659
),

(
    'Vallinoso',
    NULL,
    'Cerrado',
    'No',
    42.94933695113157,
    -5.15468500413542
),

(
    'Vega Lasprón',
    NULL,
    'Planta circular, paredes de piedra cimentada, techo de escoba',
    'No',
    42.99198100708404,
    -5.170701589740848
),

(
    'Vegabaño',
    NULL,
    'Uso libre (previo pago)',
    'No',
    43.166031887537876,
    -5.004995609110647
),

(
    'Venticueva',
    NULL,
    'Abierto 24h',
    'No',
    42.942833751769484,
    -5.094819449084917
),

(
    'Vioba',
    NULL,
    'Abierto 24h',
    'No',
    42.99732221102486,
    -5.172083441838383
),

(
    'Zampuerna',
    NULL,
    'Paraje: Zampuerna',
    'No',
    43.07475689229674,
    -5.267269748617479
),

(
    'Zampuerna-Aprisco',
    NULL,
    'Paraje: Zampuerna',
    'No',
    43.074626201541186,
    -5.267154517272408
),

(
    'Refugio de pescadores del Escenario Deportivo Social de Pesca de Castronuño',
    'Cruzamos el río Duero por la presa de San José en dirección a San Román de Hornija, y justo pasada la presa giramos 90º y entramos en el camino de Cubillas. Seguir este camino 1,5 kilómetros en dirección al río Duero y llegamos el refugio.',
    'El refugio se presta a los colectivos de pescadores que ostentan la fecha en cuestión según el calendario de pesca',
    'No',
    41.402251733939025,
    -5.251031836908777
),

(
    'Sanchivieco',
    'Desde Hoyos del Espino por la carretera de la plataforma y pasado el Puente del Duque a 2 km, por la pista cerrada de tierra a Sanchivieco y Las Maliciosas a 1,4 Km. A pie de pista.',
    'Edificios adosados con tres dependencias, una de ellas dispone de chimenea. Abrevadero grande de piedra para el ganado, cerramiento de piedra, zona de pinar y praderas.',
    'No',
    40.32943247088586,
    -5.170752374041429
),

(
    'Prado del Toro',
    'Desde Navalperal por la pista de asfalto que baja al rio Tormes y cruzado el puente al fondo de la pradera del prado del Toro',
    'Situado en la margen izquierda del río Tormes, al inicio de la senda de Cinco lagunas',
    'No',
    40.34765506518954,
    -5.29005834826906
),

(
    'El Cotorro',
    'A 15 minutos andando desde la carretera C-500 Km 44 con dirección Sur, hacia el cordel de ganado del Puerto del Pico a Piedrahita, se llega a la valla del pinar y dentro, a 100 m de la puerta en dirección Oeste.',
    'Refugio con 2 pequeñas dependencias. Tiene una barrera de hierro a la entrada para impedir que entre el ganado.',
    'No',
    40.352091706470425,
    -5.102886030914381
),

(
    'Peña Histórica',
    'Desde Navarredonda por la pista del frontón y entrada al pinar de Navahondilla, M.U.P 98, 2,5 Km.',
    'Tiene 2 bancos de fábrica interiores y una barrera de hierro a la entrada para impedir que entre en ganado.',
    'Si',
    40.35122245351969,
    -5.1138424254724315
),

(
    'Casa del Guarda',
    'Desde el puerto de Serranillos por la pista forestal que conduce hasta el puerto del Pico, pasandop por las antenas de tv, a unos dos kilometros',
    'Grande y de piedra con un amplio corral de piedra en la parte de atrás y con grandes paredes de piedra',
    'No',
    40.32080276216228,
    -4.943670839105723
),

(
    'Cazadores',
    'A 15 Km de San Esteban del Valle, por el puerto de Serranillos y desde allí a 200 metros con dirección Oeste. Desde el puerto se Serranillos a 200 m por la pista forestal',
    'Casa grande con porche y recinto vallado con árboles. Cerca del puerto de Serranillos. Utilizado por los cazadores al< paso de las palomas en el mes de noviembre',
    'No',
    40.30761267981567,
    -4.949162497680822
),

(
    'Casa de los Vaqueros',
    'Desde la plataforma de Gredos a 25 minutos hacia la Laguna Grande y desviandose 300 m al Norte del camino en el llano de Las Pozas. Junto a los refugios de Reguero Llano. También directamente desde la plataforma a 25 minutos con dirección Oeste.',
    'Pequeño refugio con corral a la entrada y puerta cerrada. Interior con dependencias para dormir. Cerrado.',
    'No',
    40.274883988849375,
    -5.237250700162342
),

(
    'Casa de Gredos',
    NULL,
    'En la cuerda de la montaña cercano a la pared de la sierra entre la Aliseda y Navamediana, a casi 2000 metros de altitud',
    'No',
    40.286867140581734,
    -5.32777219237335
),

(
    'El Churrital',
    NULL,
    'En la senda de la gargfanta de Navamediana',
    'No',
    40.28946014095969,
    -5.38973985731099
),

(
    'Las Portillas',
    'Desde Candeleda, por la pista del camino del Puerto de Candeleda hasta la Torreta de Incendios, unos 5 Km. Desde Poyales se llega por la pista forestal de tierra de La Garganta, pasar la Casa de La Barrera y 4 Km. Hasta La Torreta, unos 11 Km.',
    'Pequeño refugio con tejado a un agua. Con vistas a los Riscos de Morezón, Hermanitos de Gredos y Almanzor por el Norte, al Sur se encuentran el Valle del Tietar y el pantano de Rosarito. Usado por el vigilante de la torreta de incendio.',
    'No',
    40.185626276465364,
    -5.211495344812472
),

(
    'Refugio pescadores El Tejar',
    'Desde el puente del Tejar, en el Hornillo a 30 metros del puente por una pista de tierra',
    'Refugio abierto en la orilla del río Arenal, en el Hornillo.',
    'No',
    40.238770139508425,
    -5.090399342322275
),

(
    'Cañada La Huesa',
    'Andando desde la pista de Brbellido y collado tejedo por una trocha a 1,3 h andando',
    'Abierto todo el año y utilizado por cazadores, montañeros y ganaderos. Tiene un gran corral de piedra alrededor',
    'Si',
    40.31437317914876,
    -5.242958847550035
),

(
    'El Artiñuelo',
    'Desde la plataforma de Gredos.',
    'Antigua cabaña de pastores con dos dependencias restaurada, una de ellas orientada al oeste y alejada de la garganta de las Pozas.',
    'Si',
    40.28371302974828,
    -5.244658722285547
),

(
    'La Moncillera',
    'Pista de tierra que sale del Km 24,2 de la C-500, con dirección Sur, hacia el río, de 2 km y termina en el refugio.',
    'Típico refugio de pescadores próximo al río Tormes con pequeño porche, al pie de la pista que acaba en este punto. Cubierta a un agua.',
    'Si',
    40.35099080760605,
    -5.270031419802606
),

(
    'Los Labradillos',
    'Desde Navalperal por el camino de la garganta de Gredos, a 2,3 h andando en subida . Desde la Plataforma por la garganta de Prado de las Pozas y garganta de Gredos, en bajada a 2 h.',
    'Dos cabañas adosadas con camastros y bancos, en el camino de la Garganta de Gredos, en la margen izquierda, cerca de Roncesvalles, en zona de robles. Señalizado.',
    'Si',
    40.30991117846249,
    -5.270509263646004
),

(
    'Roncesvalles',
    'Desde Navalperal por la garganta de Gredos y pasado el puente de Roncesvalles, por la garganta de Las Pozas a 3 h. También desde la plataforma de Gredos por la garganta de las Pozas, en bajada y antes de llegar a la garganta de Gredos, a 1,3 h.',
    'Refugio semicircular en zona de antiguos puestos de pastores.',
    'Si',
    40.301542425664834,
    -5.267052264465742
),

(
    'La Mangá',
    'Pista forestal del Colmenar.',
    'Refugio de piedra grande con tejado a dos aguas, a pie de pista del Colmenar, en zona de pinar orientado al norte.',
    'No',
    40.343046292118935,
    -4.987129449571573
),

(
    'El Cervunal',
    'Por la garganta de Gredos',
    'Pequeño edificio de forma cónica con paredes de piedra y cubierta de tejas en la base del Cabeza Nevada.',
    'Si',
    40.29067538093488,
    -5.288541012359619
),

(
    'La Barranca',
    'Desde Navalperal por la senda de Cinco Lagunas a 2,3 h.',
    'Refugio de fortuna circular sobre un antiguo chozo de pastores, con cubierta de tejas de forma cónica, en zona de montaña, alejado, en la senda de Cinco Lagunas.',
    'Si',
    40.29004237872063,
    -5.299752127496822
),

(
    'Las Hoyuelas',
    'Desde el puente nuevo de Zapardiel de la Ribera por la garganta del Hornillo, a 2 h.',
    'Caseta de ganaderos cerca del arroyo de una sola pieza, porche de piedra a la entrada y corral grande de piedra para el ganado.',
    'No',
    40.30625869886446,
    -5.315717507628014
),

(
    'Los Barquillos',
    'Desde la fuente de Navalperal remontar a la Cuerda del Barquillo, a 30 minutos.',
    'Refugio de fortuna con cubierta a un agua, apoyado en una gran roca. Orientado al este, en la parte alta de la Cuerda de los Barquillos.',
    'No',
    40.29833659283631,
    -5.3023879632934765
),

(
    'La Albarea',
    'Pista forestal de la Garganta Blanca',
    'Refugio de dos plantas, tejado a dos aguas con cubierta de teja. Piso de cemento, escalera de madera y chapado exterior en parte con piedra. Cuarto exterior adosado con puerta exterior.',
    'Si',
    40.21560241620345,
    -5.247632095013402
),

(
    'La Ortiga',
    'Carretera del Arenal al puerto de la Centenera km. 4,5 . A pie de carretera en un ensanche después del arroyo de la Ortiga.',
    'Refugio de fortuna a pie de carretera con tejado a un agua y bancos exteriores de madera, en zona de pinar.',
    'Si',
    40.292378487236014,
    -5.072184734716197
),

(
    'Las Campanas',
    'Desde el puerto de la Centenera hacia el Norte, por la pista de las Campanas, a 35 minutos andando desde este puerto.',
    'Refugio en la ruta del puerto del Arenal. Con tejado a un agua y banco interior.',
    'Si',
    40.298876442056105,
    -5.05875242774699
),

(
    'Collado de la Casa',
    'Desde el Hornillo por la pista forestal de la Francisca',
    'Pequeño refugio con tejado a un agua, a pie de pista forestal en zona de pinar.',
    'No',
    40.24550477684034,
    -5.123109754113551
),

(
    'Domingo Fernando',
    'A unos 7,2 Km del Hornillo por el carril forestal del Charco Verde. Desde la plataforma de Domingo Fernando por la calleja andando durante 10 minutos por el camino del Puerto del Peón.',
    'Refugio de fortuna cerca del inicio de la senda del Puerto del Peón y Canal Seca, con tejado a un agua.',
    'Si',
    40.262207327575005,
    -5.140059888787319
),

(
    'La Francisca',
    'Carretera del Hornillo a Guisando. Camino Forestal al Collado de la Casa y La Francisca, cruzando el Río Cantos. A 2,5 Km desde El Hornillo.',
    'Refugio grande, con porche a la entrada, en la zona de la Francisca, cubierta a dos aguas. Contraventanas de madera y almacén.',
    'No',
    40.25855954832226,
    -5.129726388942039
),

(
    'La Lancha del Rey',
    'Desde el Hornillo 7,1 Km., dirección a Guisando y por el camino de La Francisca, después por pista de tierra dirección la Lancha del Rey. A 80 m de la pista forestal. Pista de las Tormeras.',
    'Pequeño refugio de fortuna con tejado a una agua cerca del area recreativa, en zona de pinar con buenas vistas.',
    'Si',
    40.265862535573426,
    -5.122062318567204
),

(
    'Las Tormeras',
    'Desde el Hornillo a 8,5 Km por pista forestal hacia la Lancha del Rey y desde allí continúa una pista hacia las Tormeras. Después andando, desde el final de esta pista con dirección Norte, durante 5 minutos.',
    'Edificio a dos aguas, entre pinos. Tejado de pizarra negra con porche cubierto en la entrada.',
    'Si',
    40.27145253550592,
    -5.12564232088739
),

(
    'El Hoyuelo',
    'Desde Guisando sale la pista con dirección a el Hoyuelo, a 4,5 Km.',
    'Pequeño refugio en el cruce de pistas forestales con tejado a un agua, en zona de pinar.',
    'Si',
    40.24141251909841,
    -5.1388322235477775
),

(
    'Guisandillo',
    'A 5 Km de Guisando por la carretera a Candeleda, desviandose en el P.K. 4,5 por la pista forestal a la derecha. En la confluencia de pistas forestales y cortafuegos.',
    'Pequeño refugio en el cruce de pistas forestales y cortafuegos, con tejado a un agua, en zona de pinar.',
    'No',
    40.206047019832766,
    -5.135556177322612
),

(
    'La Sillita',
    'Desde Guisando a unos 10 Km. por la pista forestal que une Guisando con la C-501 y desde esta por el camino forestal de La Torreta. Desde Arenas a unos 17 km dirección Candeleda y por la pista de Arbillas y la de La Torreta.',
    'Refugio de fortuna con tejado a un agua en zona de pinar, con vistas a Arenas y al Valle del Tietar. Usado por el vigilante de la torreta de incendios de la Sillita',
    'Si',
    40.20316124317286,
    -5.144190138490398
),

(
    'Nogal del Barranco',
    'Desde Guisando 4,5 Km por la carretera al Nogal del Barranco',
    'Edificio con porche a la entrada y zócalo alrededor. Con tejado de pizarra a dos aguas en la plataforma del Nogal del Barranco, zona de pinar.',
    'Si',
    40.23453115655951,
    -5.162403609900362
),

(
    'La Hoya',
    'Desde Hoyos del Collado por pista asfaltada a 2 Km dirección Norte. Andando desde Prado Molino en Hoyos del Espino por el cordel de ganado dirección a Barco de Avila 15 minutos.',
    'Refugio grande en la margen derecha del río Tormes en el tramo del GR-10 entre Hoyos del Espino y Navacepeda.',
    'Si',
    40.344586154678844,
    -5.201275089712695
),

(
    'El Mellizo',
    'Carretera de la Plataforma de Gredos y desvio a Navacepeda de Tormes. Desde Navacepeda de Tormes, por la pista de Barbellido',
    'Típico refugio de pescadores, próximo a la Garganta de Barbellido con pequeño porche, al pie de pista . Cubierta a un agua.',
    'Si',
    40.31630245414213,
    -5.2136823372806855
),

(
    'Carbonero',
    'Desde la Aliseda por la pista forestal de la garganta de La Solana a 4,5 Km. Situado a 200 metros del final de la pista. Sin señalización.',
    'Pequeño refugio en la garganta de la Solana, en zona de pastos. Cubierta a dos aguas de teja roja árabe. Cercado alrededor de piedra.',
    'No',
    40.30847564115573,
    -5.347386344807386
),

(
    'El Carbonero',
    'Desde la Aliseda por la pista forestal de la garganta de La Solana a 4,5 Km. Situado a 200 metros del final de la pista. Sin señalización.',
    'Pequeño refugio en la garganta de la Solana, en zona de pastos. Cubierta a dos aguas de teja roja árabe. Cercado alrededor de piedra.',
    'No',
    40.30851010112174,
    -5.347276945653959
),

(
    'Majada del Tío Manteca',
    'Desde el puerto del Pico por la senda del Torozo',
    'Caseta de piedra con tejado a dos aguas en un pequeño rellano de la Senda del Torozo.',
    'No',
    40.32122145739214,
    -5.0050982928885785
),

(
    'El Belesar',
    'Camino de la Garganta de Bohoyo, en la base de la última subida hasta la cumbre del Belesar. A 5 h del pueblo de Bohoyo.',
    'Refugio de fortuna circular de piedra, con tejado a dos aguas, bajo y muy alejado, en zona de pradera a bastante altitud.',
    'Si',
    40.26534236086085,
    -5.332892131957992
),

(
    'El Lanchón',
    'Por el camino de la Garganta de Bohoyo a 2,45 h. Zona de canchales al pie del camino en zona alta.',
    'Refugio pequeño y bajo en la senda de la garganta de Bohoyo, tejado a un agua . Uso sólo en mal tiempo. Poco confortable.',
    'Si',
    40.26891228501365,
    -5.371572143006547
),

(
    'La Longuilla',
    'Camino de la Garganta de Bohoyo en la zona alta de una amplia pradera, separado de la ruta unos 200 metros, próximo a la regadera alta. A 2 h del inicio.',
    'Edificio grande con dos dependencias adosadas. Una parte con cuarto de leña, habitación grande con suelo de cemento. Buen refugio en caso de mal tiempo.',
    'Si',
    40.274102289645356,
    -5.3953720922698665
),

(
    'La Redonda',
    'Camino de la Garganta de Bohoyo, después del refugio de La Secá a 50 minutos del inicio de ruta.',
    'Caseta restaurada con tejado a dos aguas en el camino de la gargantra de Bohoyo, señalizada.',
    'Si',
    40.27755226722316,
    -5.4154220386168275
),

(
    'La Secá',
    'Camino de la Garganta de Bohoyo, pasada la segunda portera en una pradera a la izquierda. A 35 minutos a pie, por camino entre bosques.',
    'Caseta con tejado a dos aguas y pequeño corral de caballos a la entrada, en senda de la Garganta de Bohoyo.',
    'Si',
    40.281432216258985,
    -5.422142042439429
),

(
    'Quemaculos',
    'Desde Navamediana por la garganta a 2,3 h.',
    'En la garagnata de Navamediana, con suelo de cemento y cuarto de leña.',
    'No',
    40.28639180391136,
    -5.36738479258528
),

(
    'Regero Llano',
    'Desde la plataforma de Gredos a 25 minutos, hacia la Laguna Grande, desviándose 300 m del camino hacia el lado Norte del Prado de Las Pozas. Otra forma de llegar es directamente desde la plataforma a 20 minutos, con dirección Oeste por una cuesta inclina',
    'Edificio grande de piedra, alto, con tejado a dos aguas. En el lado sur del Prado Pozas, cercano a otros refugios.',
    'No',
    40.27621115603988,
    -5.237305211801721
),

(
    'Casa de Requejo',
    'Carretera N-502 en el Puerto del Pico y pista forestal de Orzaduero, al oeste, a 1,2 km.',
    'Casa de piedra con tejado a dos aguas y porche cubierto. En la pista del Colmenar con direcion a la torreteta de Horzaduero',
    'No',
    40.32528257756746,
    -5.016952420386586
),

(
    'Llanos de Raigoso',
    'Desde la N- 502 en el km 47, al lado este por la entrada a la base de helicópteros.',
    'Casa grande utilizada como base de helicópteros en campaña de incendios. Agua, luz, varias habitaciones, cocinas, servicios, depósito de combustible, base de helicópteros, servicios, taquillas.',
    'No',
    40.331768279418846,
    -5.013030639161536
),

(
    'Casa',
    'Carretera N-502 en la Venta de Rasca, por un puente pequeño en la otra orilla de río Piquillo, a 200 m.',
    'Edificio blanco con tejado a dos aguas, con un pequeño porche a la entrada y almacén semiderruido en la pared de atrás.',
    'No',
    40.36777542971542,
    -5.014345816028654
),

(
    'Casa del Mayoral',
    'Carretera N-502 en la entrada a la base de helicopteros y por dentro de la finca a 1,5 km. También en la entrada a las Casas del Colmenar desde la N-502 y siguiendo la pista hasta el fondo de las praderas.',
    'Edificio de piedra grande con porche de entrada, reparado recientemente.',
    'No',
    40.343932560040955,
    -5.008102503657826
),

(
    'Refugio de Paz',
    'Desde la plataforma de Gredos a 25 minutos hacia la Laguna Grande, desviado 300 m del camino en el lado norte del Prado de Las Pozas. También se puede llegar directamente desde la plataforma, a 20 minutos, con dirección Oeste por una cuesta inclinada.',
    'Edificio grande con tejado a dos aguas en el lado sur del Prado Pozas',
    'No',
    40.275932210000136,
    -5.237113285534311
),

(
    'Victory',
    'Andando desde la plataforma del Nogal del Barranco por el camino del Carril de los Galayos, a 2,3 h.',
    'Edificio austero de dos plantas y cubierta de hormigón con aislante blanco, situado en la base de los Galayos con impresionantes vistas.',
    'No',
    40.25991252927045,
    -5.173302170683029
),

(
    'Antigua Piscifactoría',
    'Desde Navalperal hacia el río Tormes, pasado el puente a la izquierda por la pista que sale del Prado del Toro, a 30 metros.',
    'Edificio con tejadillo a un agua. Utilizada como dependencia y almacén. Bancos de piedra exteriores en la antigua piscifactoria de Navalperal de Tormes.',
    'No',
    40.348002370959016,
    -5.2880322571435014
),

(
    'Almacén del Colmenar',
    'Carretera N -502 en la entrada del vivero forestal del Colmenar.',
    'Edificio grande rectangular, con cubierta de pizarra negra a dos aguas. Se utliza de almacen.',
    'No',
    40.32805145885799,
    -5.108426496936961
),

(
    'Ganadero',
    'A 3,9 Km por pista de tierra desde el puerto de Umbrías (entre la Nava de barco y Umbrías)',
    'Refugio con tejado a un agua, mesas y bancos en el exterior.',
    'No',
    40.27955879439671,
    -5.5846684958513695
),

(
    'Las Mesilla',
    'Desde Guisando por la pista al Hoyuelo y después por la de las Mesillas. Está al final de la pista forestal pasado el pilón de incendios.',
    'Caseta en un puesto de ganaderos de verano, cerca del arroyo, con tejado a una agua. Otras dos chozos de piornos para quesera y pienso para cabras, una tenada de cabras grande y ocupado por cabreros en verano, de junio a octubre',
    'No',
    40.249152502521845,
    -5.148462200042371
),

(
    'La Covacha',
    'Senda del Puerto de Peón desde Hoyos del Espino a 30 minutos del inicio, pasada la segunda portera. Llega la pista forestal.',
    'Caseta típica de ganaderos con tejado a dos aguas, dos dependencias y suelo de piedra. En la senda del Puerto de Peón.',
    'No',
    40.300979525522344,
    -5.177628627717802
),

(
    'La Potrica',
    'Desde Navarredonda con dirección Valdeascas, 2,4 km y por el cordel de ganado hacia el arroyo de la Potrica. Se entra en el pinar y se sube por la pradera 20 minutos. Entre pinos.',
    'En el pinar de Navarredonda, próximo al cordel de ganado. Tejado a dos aguas. Abierto pero muy poco frecuentado.',
    'No',
    40.336932498506506,
    -5.122582398677688
),

(
    'Corrales de La Covacha',
    'En la entrada de la finca de la Covacha, inicio de la senda del Puerto del Peón, seguir la pista hasta que comienza a bajar, a 450 m de la carretera.',
    'Pequeña cabaña dentro de los corrales de ganado, con tejado a una agua. Paredes con grandes piedras y cubierta con teja roja árabe.',
    'No',
    40.30019581982741,
    -5.1904646192383845
),

(
    'La Cepeda',
    'Pista de Barbellido a Collado Tejedo, cruzando la garganta de Barbellido cerca del refugio de los Mellizos.A 20 minutos andando por la pista de tierra.',
    'Pequeño refugio con tejado a un agua, al lado de la pista forestal, con valla a la entrada.',
    'No',
    40.309750708212846,
    -5.222891902101272
),

(
    'El Helecho',
    'Se llega andando por la garganta de Valdeascas tomando la garganta de los barquillos a 200 metros de esta, 1 h. También se puede llegar en 4x4 por la pista del Helecho.',
    'Cubierta de madera y teja a dos aguas. Adosado a la pared un pequeño corral de piedra. Tentadero circular de piedra próximo.',
    'No',
    40.3194543952226,
    -5.135826645575321
),

(
    'Laguna de Galin Gómez',
    'Senda de la laguna de Galin Gomez o de Barco, al final de la senda y a la orilla de la laguna.',
    'En la orilla de la laguna de Galin Gomez o de Barco, con posiblidades de reformas',
    'No',
    40.23390236294635,
    -5.602069973705718
),

(
    'Prado Puerto',
    'Desde la plataforma de Gredos a 25 minutos por el camino del Puerto de Candeleda, en la otra orilla derecha de la garganta. Desviado de la ruta 400 metros, en zona alta de una pradera. Poco visible.',
    'Caseta típica de ganaderos en zona alta de pradera con cubierta baja a dos aguas y orientado al sur.',
    'No',
    40.26399246088406,
    -5.234172160636319
),

(
    'Refugio del Rey',
    'Desde la plataforma de Gredos dirección a Navasonera , a 1,30 h, o por la ruta del puerto de Candeleda desviandose por el camino del Rey, a 2 h.',
    'En ruinas. Bloques de las paredes de piedra derruidas, cubierta de hormigón caida. Sin uso.',
    'No',
    40.25122260429366,
    -5.253074769668124
),

(
    'Chozo de Laguna de los Caballeros',
    'Por la senda de Garganta de los Caballeros',
    'Refugio chozo de fortuna',
    'No',
    40.21948559450862,
    -5.541309242207124
),

(
    'Majada de Anselmo',
    'Desde en puerto de Umbrías por la pista de tierra andando durante 3 h, en la bajada a la garganta, a la orilla de la laguna.',
    'Caseta de planta rectangular con tejado de cemento a una agua, en la orilla de la laguna de Galín Goméz.',
    'No',
    40.2537707797336,
    -5.604811371600613
),

(
    'Prado de la Casa',
    'Desde Hoyos de Espino por la carretera de la plataforma y pasado el puente de Las Juntas y a 1 km por pista de tierra hasta el puente de la garganta de Prado Puerto. Andando 15 m. más hasta el arroyo del Prado de la Casa.',
    'Edificio de piedra, con dos dependencias adosadas iguales y corral de caballos cerca, al pie de la regadera del arroyo de Prado la Casa.',
    'No',
    40.2838751170555,
    -5.216349529819747
),

(
    'Laguna del Duque',
    'Desde Solana de Avila a unos 5,5 Km con dirección al puerto del Tremedal, y por la pista de la central del Zaburdón y del Chorro. Al final de la pista se comienza a andar por una senda marcada próxima a la tubería de la central, a 35 minutos.',
    'Refugio con cubierta a un agua, de planta rectangular y dos dependencias en zona de pradera por debajo de la laguna del Duque.',
    'No',
    40.3050159842809,
    -5.681841535319622
),

(
    'El Piesnillo',
    'Margen izquierda de la garaganta de Bohoyo, en zona de robledal y brezal.',
    'En la margen izquierda de la garaganta de Bohoyo.',
    'No',
    40.29963000560808,
    -5.40666743576138
),

(
    'Navacasera',
    'Senda de la Garganta de la Nava, en zona de pradera, a media hora del inicio en la portera de la sierra.',
    'Cabaña pequeña de piedra con tejado a dos aguas, y banco exterior de piedra. En la senda de la Laguna de la Nava.',
    'No',
    40.26348433363848,
    -5.565184573956817
),

(
    'La Losa',
    'Senda de la Garganta de la Nava, en una zona de pradera, a 45 minutos del inicio en la portera de la sierra.',
    'Refugio de fortuna de piedra, con tejado a un agua. En la senda de la Laguna de la Nava.',
    'No',
    40.25516210220126,
    -5.5672031237280235
),

(
    'El Baldío',
    'Desde Navarredonda a 4 Km por el camino a Valdeascas y por el Cordel del Puerto del Pico a Barco de Avila, dirección Este rodeando el pinar, hasta el alto del Cotorro. Entrada de tierra y valla ganadera. Visible desde en cordel.',
    'Refugio en la entrada de la finca del Baldío. Cubierta de teja de cemento gris a un agua.',
    'No',
    40.34153246326953,
    -5.109932345359892
),

(
    'Elola',
    'Desde la plataforma de Gredos por el camino de la Laguna Grande de Gredos 2,3 h.',
    'Edificio moderno sobre la cabezera de la Laguna Grande de Gredos de forma rectangular y dos plantas.',
    'Si',
    40.25060727200535,
    -5.279883110537708
),

(
    'Cabeza la Parra',
    NULL,
    'Zona de reserva',
    'No',
    40.391270602273515,
    -4.5404065164943965
),

(
    'Majalespino',
    NULL,
    'Zona de uso limitado',
    'No',
    40.37271012444576,
    -4.534921979969676
);

INSERT INTO
    ALOJAMIENTOS(
        establecimiento,
        tipo,
        categoria,
        nombre,
        municipio,
        web,
        telefono,
        wikidata,
        imagenmunicipio,
        poblacionmunicipio,
        longitud,
        latitud
    )
VALUES
    (
        'Alojam. Turismo Rural',
        'Casa Rural de Alquiler',
        '2 Estrellas',
        'LOS ABUELOS',
        'La Adrada',
        NULL,
        630982862,
        'http://www.wikidata.org/entity/Q1606366',
        'https://www.wikidata.org/wiki/Q1606366#/media/File:La_Adrada_(Ávila).JPG',
        2750,
        -4.6197771,
        40.301296099069155
    ),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'EL PAJAR DE LA ADRADA',
    'La Adrada',
    NULL,
    609151712,
    'http://www.wikidata.org/entity/Q1606366',
    'https://www.wikidata.org/wiki/Q1606366#/media/File:La_Adrada_(Ávila).JPG',
    2750,
    -4.635890000000001,
    40.299529999069186
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CONCEJO I',
    'La Adrada',
    NULL,
    920206204,
    'http://www.wikidata.org/entity/Q1606366',
    'https://www.wikidata.org/wiki/Q1606366#/media/File:La_Adrada_(Ávila).JPG',
    2750,
    -4.636681499999999,
    40.30051449906917
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CONCEJO II',
    'La Adrada',
    NULL,
    920206204,
    'http://www.wikidata.org/entity/Q1606366',
    'https://www.wikidata.org/wiki/Q1606366#/media/File:La_Adrada_(Ávila).JPG',
    2750,
    -4.636681499999999,
    40.30051449906917
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'EL REFUGIO DE LUCAS',
    'La Adrada',
    NULL,
    616846546,
    'http://www.wikidata.org/entity/Q1606366',
    'https://www.wikidata.org/wiki/Q1606366#/media/File:La_Adrada_(Ávila).JPG',
    2750,
    -4.637017,
    40.29802199906919
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'REFUGIO DE PERDIGONES',
    'El Arenal',
    NULL,
    669874048,
    'http://www.wikidata.org/entity/Q1632614',
    'https://www.wikidata.org/wiki/Q1632614#/media/File:Vista_de_El_Arenal.JPG',
    938,
    -5.086388899999999,
    40.27972219906929
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA RINCONADA',
    'El Barraco',
    NULL,
    600518190,
    'http://www.wikidata.org/entity/Q1618246',
    'https://www.wikidata.org/wiki/Q1618246#/media/File:El_Barraco_(41096154022).jpg',
    1956,
    -4.599389,
    40.41452899906859
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DE LA REGADERA',
    'Becedas',
    'www.casasgredos.com',
    920206204,
    'http://www.wikidata.org/entity/Q512237',
    'https://www.wikidata.org/wiki/Q512237#/media/File:Becedas,_Ávila_01.jpg',
    172,
    -5.6365157,
    40.40245059906864
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'TÍA PAULINA',
    'Bohoyo',
    NULL,
    696635580,
    'http://www.wikidata.org/entity/Q1620302',
    'https://www.wikidata.org/wiki/Q1620302#/media/File:Bohoyo.jpg',
    230,
    -5.406798599999999,
    40.354485899068884
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL ACEBO',
    'Candeleda',
    NULL,
    699192401,
    'http://www.wikidata.org/entity/Q1442696',
    'https://www.wikidata.org/wiki/Q1442696#/media/File:CandeledaVistaDelPueblo.jpg',
    5044,
    -5.31031,
    40.15946879906994
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL MADROÑO',
    'Candeleda',
    NULL,
    699192401,
    'http://www.wikidata.org/entity/Q1442696',
    'https://www.wikidata.org/wiki/Q1442696#/media/File:CandeledaVistaDelPueblo.jpg',
    5044,
    -5.31031,
    40.15946879906994
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'CAÑO DEL SANTO',
    'Cardeñosa',
    'www.elcanodelsanto@yahoo.es',
    920049221,
    'http://www.wikidata.org/entity/Q285411',
    'https://www.wikidata.org/wiki/Q285411#/media/File:Cardenhosa01.jpg',
    425,
    -4.7455615,
    40.74195189906694
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CELESTINA',
    'La Carrera',
    NULL,
    920085090,
    'http://www.wikidata.org/entity/Q1775460',
    'https://www.wikidata.org/wiki/Q1775460#/media/File:Fuente_de_La_Carrera_(Ávila).jpg',
    157,
    -5.5549453,
    40.34822029906892
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA VIÑUELA',
    'Casavieja',
    NULL,
    920206204,
    'http://www.wikidata.org/entity/Q1445437',
    'https://www.wikidata.org/wiki/Q1445437#/media/File:Casavieja_vista_general.jpg',
    1418,
    -4.7663216,
    40.28313589906926
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'HOSPEDERIA DE LA TIA MARIA',
    'Casillas',
    NULL,
    918667203,
    'http://www.wikidata.org/entity/Q1645641',
    'https://www.wikidata.org/wiki/Q1645641#/media/File:Casillas,_Avila_(39778512643).jpg',
    649,
    -4.572633499999999,
    40.32371649906905
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LAS CHORRERAS',
    'Cuevas del Valle',
    NULL,
    696712079,
    'http://www.wikidata.org/entity/Q1607095',
    'https://www.wikidata.org/wiki/Q1607095#/media/File:Vista_de_Cuevas_del_Valle.JPG',
    523,
    -5.0351,
    40.30289999906917
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA FONTE',
    'Fontiveros',
    NULL,
    636037955,
    'http://www.wikidata.org/entity/Q1442826',
    'https://www.wikidata.org/wiki/Q1442826#/media/File:Fontiveros_fuente_01.jpg',
    719,
    -4.9613889,
    40.92527779906607
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA BODEGA',
    'Guisando',
    'www.casarurallabodega.com',
    669270999,
    'http://www.wikidata.org/entity/Q1450130',
    'https://www.wikidata.org/wiki/Q1450130#/media/File:GUISANDO,_Ávila._Espa�a-Spain.jpg',
    497,
    -5.139551,
    40.222587799069586
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA SAMUEL PARACA',
    'Guisando',
    'www.casaruralsamuelparaca.com',
    680108876,
    'http://www.wikidata.org/entity/Q1450130',
    'https://www.wikidata.org/wiki/Q1450130#/media/File:GUISANDO,_Ávila._Espa�a-Spain.jpg',
    497,
    -5.139721999999999,
    40.2224299990696
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL RINCON DE ANTER B',
    'Higuera de las Dueñas',
    NULL,
    686201584,
    'http://www.wikidata.org/entity/Q1632728',
    'https://www.wikidata.org/wiki/Q1632728#/media/File:Vista_de_Higuera_de_las_Due�as.JPG',
    270,
    -4.601063400000001,
    40.23805969906951
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL RINCON DE ANTER A',
    'Higuera de las Dueñas',
    NULL,
    686201584,
    'http://www.wikidata.org/entity/Q1632728',
    'https://www.wikidata.org/wiki/Q1632728#/media/File:Vista_de_Higuera_de_las_Due�as.JPG',
    270,
    -4.601063400000001,
    40.23805969906951
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL SOTILLO',
    'La Horcajada',
    'www.lahorcajada.org',
    920364001,
    'http://www.wikidata.org/entity/Q1632783',
    'https://www.wikidata.org/wiki/Q1632783#/media/File:Lahorcajada.jpg',
    482,
    -5.466856700000001,
    40.43661159906845
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'VALDENEGRO II',
    'La Horcajada',
    'www.lahorcajada.org',
    920364001,
    'http://www.wikidata.org/entity/Q1632783',
    'https://www.wikidata.org/wiki/Q1632783#/media/File:Lahorcajada.jpg',
    482,
    -5.470154600000001,
    40.43462579906847
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL PARQUE',
    'La Horcajada',
    'www.lahorcajada.org',
    920364001,
    'http://www.wikidata.org/entity/Q1632783',
    'https://www.wikidata.org/wiki/Q1632783#/media/File:Lahorcajada.jpg',
    482,
    -5.4697323,
    40.435310699068474
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'VALDENEGRO I',
    'La Horcajada',
    'www.lahorcajada.org',
    920364001,
    'http://www.wikidata.org/entity/Q1632783',
    'https://www.wikidata.org/wiki/Q1632783#/media/File:Lahorcajada.jpg',
    482,
    -5.470154600000001,
    40.43462579906847
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'RIOFRAGUAS',
    'La Horcajada',
    'www.lahorcajada.org',
    920364001,
    'http://www.wikidata.org/entity/Q1632783',
    'https://www.wikidata.org/wiki/Q1632783#/media/File:Lahorcajada.jpg',
    482,
    -5.4612511,
    40.439457499068446
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL FIELATO',
    'La Horcajada',
    'www.lahorcajada.org',
    920364001,
    'http://www.wikidata.org/entity/Q1632783',
    'https://www.wikidata.org/wiki/Q1632783#/media/File:Lahorcajada.jpg',
    482,
    -5.466721099999999,
    40.43810229906845
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'VALDENEGRO III',
    'La Horcajada',
    'www.lahorcajada.org',
    920364001,
    'http://www.wikidata.org/entity/Q1632783',
    'https://www.wikidata.org/wiki/Q1632783#/media/File:Lahorcajada.jpg',
    482,
    -5.470154600000001,
    40.43462579906847
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DEL RIO TEJOS',
    'El Hornillo',
    'www.casasgredos.com',
    920206204,
    'http://www.wikidata.org/entity/Q1632606',
    'https://www.wikidata.org/wiki/Q1632606#/media/File:Vista_de_El_Hornillo,_Ávila.JPG',
    270,
    -5.103554999999999,
    40.250740299069435
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DEL RIO CANTO',
    'El Hornillo',
    'www.casasgredos.com',
    920374531,
    'http://www.wikidata.org/entity/Q1632606',
    'https://www.wikidata.org/wiki/Q1632606#/media/File:Vista_de_El_Hornillo,_Ávila.JPG',
    270,
    -5.103554999999999,
    40.250740299069435
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DEL MEDICO',
    'Hoyocasero',
    'www.casasgredos.com',
    920206204,
    'http://www.wikidata.org/entity/Q1632400',
    'https://www.wikidata.org/wiki/Q1632400#/media/File:Vista_de_Hoyocasero.JPG',
    276,
    -4.9748707,
    40.399075199068655
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS CUATRO BALCONES',
    'Hoyocasero',
    'www.casasdegredos.com',
    920206204,
    'http://www.wikidata.org/entity/Q1632400',
    'https://www.wikidata.org/wiki/Q1632400#/media/File:Vista_de_Hoyocasero.JPG',
    276,
    -4.9748707,
    40.399075199068655
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS CINCO BALCONES',
    'Hoyocasero',
    'www.casasdegredos.com',
    920206204,
    'http://www.wikidata.org/entity/Q1632400',
    'https://www.wikidata.org/wiki/Q1632400#/media/File:Vista_de_Hoyocasero.JPG',
    276,
    -4.9748707,
    40.399075199068655
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS TRIGALES',
    'Hoyorredondo',
    'www.casasgredos.com',
    920206204,
    'http://www.wikidata.org/entity/Q1606975',
    'https://www.wikidata.org/wiki/Q1606975#/media/File:Hoyorredondo_18.jpg',
    58,
    -5.3805141,
    40.48595209906821
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS RISCOS DE GREDOS',
    'Hoyos de Miguel Muñoz',
    'www.casasdegredos.com',
    920206204,
    'http://www.wikidata.org/entity/Q634713',
    'https://www.wikidata.org/wiki/Q634713#/media/File:Hoyos_de_Miguel_Mu�oz_panorama.jpg',
    25,
    -5.0668076,
    40.39276709906869
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA ASOMAILLA ARRIBA',
    'Hoyos del Espino',
    NULL,
    920349010,
    'http://www.wikidata.org/entity/Q1632480',
    'https://www.wikidata.org/wiki/Q1632480#/media/File:P1070707hoyosdelespino.JPG',
    364,
    -5.174864299999999,
    40.352610599068896
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS GUIJOS I',
    'Hoyos del Espino',
    NULL,
    920349123,
    'http://www.wikidata.org/entity/Q1632480',
    'https://www.wikidata.org/wiki/Q1632480#/media/File:P1070707hoyosdelespino.JPG',
    364,
    -5.175366599999999,
    40.35440729906889
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PUENTE 9',
    'Hoyos del Espino',
    NULL,
    920349065,
    'http://www.wikidata.org/entity/Q1632480',
    'https://www.wikidata.org/wiki/Q1632480#/media/File:P1070707hoyosdelespino.JPG',
    364,
    -5.175366599999999,
    40.35440729906889
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL LEÑADOR I',
    'Hoyos del Espino',
    'www.casaruralengredos.com',
    671604251,
    'http://www.wikidata.org/entity/Q1632480',
    'https://www.wikidata.org/wiki/Q1632480#/media/File:P1070707hoyosdelespino.JPG',
    364,
    -5.176662799999999,
    40.356921199068886
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL LEÑADOR II',
    'Hoyos del Espino',
    'www.casaruralengredos.com',
    671604251,
    'http://www.wikidata.org/entity/Q1632480',
    'https://www.wikidata.org/wiki/Q1632480#/media/File:P1070707hoyosdelespino.JPG',
    364,
    -5.176662799999999,
    40.356921199068886
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PUENTE 10',
    'Hoyos del Espino',
    NULL,
    920349065,
    'http://www.wikidata.org/entity/Q1632480',
    'https://www.wikidata.org/wiki/Q1632480#/media/File:P1070707hoyosdelespino.JPG',
    364,
    -5.175366599999999,
    40.35440729906889
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS GUIJOS II',
    'Hoyos del Espino',
    NULL,
    920349123,
    'http://www.wikidata.org/entity/Q1632480',
    'https://www.wikidata.org/wiki/Q1632480#/media/File:P1070707hoyosdelespino.JPG',
    364,
    -5.175366599999999,
    40.35440729906889
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LAS ERILLAS B',
    'Lanzahita',
    NULL,
    635145558,
    'http://www.wikidata.org/entity/Q1606445',
    'https://www.wikidata.org/wiki/Q1606445#/media/File:Lanzah�ta.JPG',
    819,
    -4.9342872,
    40.202824899069704
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LAS ERILLAS A',
    'Lanzahita',
    NULL,
    652460363,
    'http://www.wikidata.org/entity/Q1606445',
    'https://www.wikidata.org/wiki/Q1606445#/media/File:Lanzah�ta.JPG',
    819,
    -4.9342872,
    40.202824899069704
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'DOMI Y VIRTU',
    'Martiherrero',
    NULL,
    646930412,
    'http://www.wikidata.org/entity/Q1632641',
    'https://www.wikidata.org/wiki/Q1632641#/media/File:Martiherrero_3.jpg',
    338,
    -4.7797,
    40.673607999067265
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA SERROTA',
    'Navacepedilla de Corneja',
    NULL,
    920206204,
    'http://www.wikidata.org/entity/Q932657',
    'https://www.wikidata.org/wiki/Q932657#/media/File:Plaza_mayor_de_Navacepedilla_del_Corneja.jpg',
    91,
    -5.1841566,
    40.486414499068204
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CANCHA II',
    'Navalacruz',
    NULL,
    649979184,
    'http://www.wikidata.org/entity/Q1632363',
    'https://www.wikidata.org/wiki/Q1632363#/media/File:Navalacruz_carnicer�a.jpg',
    215,
    -4.9339576,
    40.440482999068436
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CANCHA I',
    'Navalacruz',
    NULL,
    649979184,
    'http://www.wikidata.org/entity/Q1632363',
    'https://www.wikidata.org/wiki/Q1632363#/media/File:Navalacruz_carnicer�a.jpg',
    215,
    -4.9339576,
    40.440482999068436
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PLAZUELA',
    'Navalonguilla',
    NULL,
    610914721,
    'http://www.wikidata.org/entity/Q630479',
    'https://www.wikidata.org/wiki/Q630479#/media/File:Navalonguilla_0.jpg',
    205,
    -5.521739,
    40.25950459906939
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL HORNO',
    'Navalonguilla',
    'www.casasgredos.com',
    920343832,
    'http://www.wikidata.org/entity/Q630479',
    'https://www.wikidata.org/wiki/Q630479#/media/File:Navalonguilla_0.jpg',
    205,
    -5.4993997,
    40.27776729906929
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PLAZUELA',
    'Navalonguilla',
    NULL,
    920343802,
    'http://www.wikidata.org/entity/Q630479',
    'https://www.wikidata.org/wiki/Q630479#/media/File:Navalonguilla_0.jpg',
    205,
    -5.4993997,
    40.27776729906929
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CUCURRUMACHA',
    'Navalosa',
    NULL,
    625352450,
    'http://www.wikidata.org/entity/Q1632696',
    'https://www.wikidata.org/wiki/Q1632696#/media/File:Navalosa_nevada.jpeg',
    317,
    -4.9742799,
    40.39894719906866
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DEL MAESTRO II',
    'Navalosa',
    NULL,
    920206204,
    'http://www.wikidata.org/entity/Q1632696',
    'https://www.wikidata.org/wiki/Q1632696#/media/File:Navalosa_nevada.jpeg',
    317,
    -4.9313944,
    40.40086039906864
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DEL MAESTRO I',
    'Navalosa',
    NULL,
    920206234,
    'http://www.wikidata.org/entity/Q1632696',
    'https://www.wikidata.org/wiki/Q1632696#/media/File:Navalosa_nevada.jpeg',
    317,
    -4.9313944,
    40.40086039906864
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA NARANJA',
    'Navalperal de Pinares',
    NULL,
    606920882,
    'http://www.wikidata.org/entity/Q283318',
    'https://www.wikidata.org/wiki/Q283318#/media/File:Estaci�n_de_Navalperal.jpg',
    761,
    -4.412274899999999,
    40.59514129906764
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PANTIZUELA-LA GRANDE',
    'Navalperal de Tormes',
    NULL,
    658961479,
    'http://www.wikidata.org/entity/Q1632599',
    'https://www.wikidata.org/wiki/Q1632599#/media/File:Iglesia_de_Navalperal_de_Tormes.jpg',
    81,
    -5.304105500000001,
    40.365136799068836
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DE ANA',
    'Navaluenga',
    NULL,
    920298206,
    'http://www.wikidata.org/entity/Q1406656',
    'https://www.wikidata.org/wiki/Q1406656#/media/File:Navaluenga_01_by-dpc.jpg',
    2136,
    -4.7106509,
    40.411421199068585
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL PAJAR',
    'Navaluenga',
    NULL,
    655581778,
    'http://www.wikidata.org/entity/Q1406656',
    'https://www.wikidata.org/wiki/Q1406656#/media/File:Navaluenga_01_by-dpc.jpg',
    2136,
    -4.705704099999999,
    40.41265139906858
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PIEDRA',
    'Navaluenga',
    NULL,
    920286173,
    'http://www.wikidata.org/entity/Q1406656',
    'https://www.wikidata.org/wiki/Q1406656#/media/File:Navaluenga_01_by-dpc.jpg',
    2136,
    -4.7098477,
    40.4094767990686
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL SALÓN DE BAILE',
    'Navarredondilla',
    'www.casasgredos.com',
    920206204,
    'http://www.wikidata.org/entity/Q1631128',
    'https://www.wikidata.org/wiki/Q1631128#/media/File:Navarredondilla_(cropped).jpg',
    156,
    -4.821290500000001,
    40.454265699068365
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS PORTALILLOS II',
    'Navatalgordo',
    'www.casasgredos.com',
    920206002,
    'http://www.wikidata.org/entity/Q1632355',
    'https://www.wikidata.org/wiki/Q1632355#/media/File:Navatalgordo_8.jpg',
    238,
    -4.8699961,
    40.41447309906858
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS PORTALILLOS I',
    'Navatalgordo',
    'www.casasgredos.com',
    920206002,
    'http://www.wikidata.org/entity/Q1632355',
    'https://www.wikidata.org/wiki/Q1632355#/media/File:Navatalgordo_8.jpg',
    238,
    -4.8699961,
    40.41447309906858
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS PALOMOS',
    'Peñalba de Ávila',
    NULL,
    920255475,
    'http://www.wikidata.org/entity/Q1631119',
    'https://www.wikidata.org/wiki/Q1631119#/media/File:Penhalba0509.jpg',
    109,
    -4.6825885,
    40.822570699066546
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'NEVERITAS',
    'Piedrahita',
    NULL,
    657804447,
    'http://www.wikidata.org/entity/Q764491',
    'https://www.wikidata.org/wiki/Q764491#/media/File:Piedrahitacuesta.jpg',
    1720,
    -5.3272334,
    40.464698099068315
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS SERRANILLOS-LAS BELLOTAS',
    'Piedrahita',
    'www.losserranillos.com',
    686492830,
    'http://www.wikidata.org/entity/Q764491',
    'https://www.wikidata.org/wiki/Q764491#/media/File:Piedrahitacuesta.jpg',
    1720,
    -5.3188008,
    40.451300699068376
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS SERRANILLOS-LOS PILARES',
    'Piedrahita',
    'www.losserranillos.com',
    686492830,
    'http://www.wikidata.org/entity/Q764491',
    'https://www.wikidata.org/wiki/Q764491#/media/File:Piedrahitacuesta.jpg',
    1720,
    -5.3188008,
    40.451300699068376
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA ARAÑA',
    'Piedralaves',
    'www.casaruralpiedralaves.com',
    655549410,
    'http://www.wikidata.org/entity/Q1607872',
    'https://www.wikidata.org/wiki/Q1607872#/media/File:Piedralavs_Municipio.jpg',
    2123,
    -4.696113399999999,
    40.31705269906908
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CASA DEL CUERO (CIERRE TEMPORAL)',
    'Poyales del Hoyo',
    NULL,
    685109020,
    'http://www.wikidata.org/entity/Q1630438',
    'https://www.wikidata.org/wiki/Q1630438#/media/File:Poyales_del_Hoyo.JPG',
    463,
    -5.1609715000000005,
    40.17461459906985
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'CARLOS V',
    'Puerto Castilla',
    NULL,
    920342700,
    'http://www.wikidata.org/entity/Q1449893',
    'https://www.wikidata.org/wiki/Q1449893#/media/File:Puerto_Castilla_32.jpg',
    111,
    -5.629439999999999,
    40.28832999906925
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'TIO VIVILLO',
    'San Juan de Gredos',
    NULL,
    658961479,
    'http://www.wikidata.org/entity/Q1632850',
    'https://www.wikidata.org/wiki/Q1632850#/media/File:Molino_en_San_Juan_de_Gredos.jpg',
    251,
    -5.2506386,
    40.35952349906886
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PASAILLA',
    'San Juan de Gredos',
    'www.lapasailla.com',
    618018311,
    'http://www.wikidata.org/entity/Q1632850',
    'https://www.wikidata.org/wiki/Q1632850#/media/File:Molino_en_San_Juan_de_Gredos.jpg',
    251,
    -5.266212299999999,
    40.37651639906877
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'MIRA AL CENTRO DE GREDOS',
    'San Juan de Gredos',
    NULL,
    658961479,
    'http://www.wikidata.org/entity/Q1632850',
    'https://www.wikidata.org/wiki/Q1632850#/media/File:Molino_en_San_Juan_de_Gredos.jpg',
    251,
    -5.266212299999999,
    40.37651639906877
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL CERRILLO',
    'San Martín del Pimpollar',
    'www.loscerrillosdegredos.com',
    655889148,
    'http://www.wikidata.org/entity/Q1630378',
    'https://www.wikidata.org/wiki/Q1630378#/media/File:San_Mart�n_del_Pimpollar_0.jpg',
    213,
    -5.054501799999999,
    40.36802419906881
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA -CARRILES',
    'Santa María de los Caballeros',
    NULL,
    619606025,
    'http://www.wikidata.org/entity/Q1630468',
    'https://www.wikidata.org/wiki/Q1630468#/media/File:SantaMar�aDeLosCaballeros_storks.jpg',
    61,
    -5.465856400000001,
    40.398599999068665
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DEL CHOPO',
    'Santiago del Tormes',
    'www.casasgredos.com',
    676107103,
    'http://www.wikidata.org/entity/Q1630577',
    'https://www.wikidata.org/wiki/Q1630577#/media/File:Aliseda_de_Tormes_27.jpg',
    112,
    -5.387907,
    40.340961199068964
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'AL PATIO',
    'Solana de Ávila',
    NULL,
    608303400,
    'http://www.wikidata.org/entity/Q1628144',
    'https://www.wikidata.org/wiki/Q1628144#/media/File:SOLANA_DE_AVILA.(Avila).jpg',
    110,
    -5.5984271,
    40.34793269906892
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'REFUGIO LA LUMBRE',
    'Solana de Ávila',
    NULL,
    608303400,
    'http://www.wikidata.org/entity/Q1628144',
    'https://www.wikidata.org/wiki/Q1628144#/media/File:SOLANA_DE_AVILA.(Avila).jpg',
    110,
    -5.597682999999999,
    40.34800329906893
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL EMBALSE',
    'Solana de Ávila',
    NULL,
    680303400,
    'http://www.wikidata.org/entity/Q1628144',
    'https://www.wikidata.org/wiki/Q1628144#/media/File:SOLANA_DE_AVILA.(Avila).jpg',
    110,
    -5.613708099999998,
    40.315287599069094
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA LAGUNA',
    'Solana de Ávila',
    NULL,
    608303400,
    'http://www.wikidata.org/entity/Q1628144',
    'https://www.wikidata.org/wiki/Q1628144#/media/File:SOLANA_DE_AVILA.(Avila).jpg',
    110,
    -5.5984271,
    40.34793269906892
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LOS CASTAÑOS',
    'Solana de Ávila',
    NULL,
    608303400,
    'http://www.wikidata.org/entity/Q1628144',
    'https://www.wikidata.org/wiki/Q1628144#/media/File:SOLANA_DE_AVILA.(Avila).jpg',
    110,
    -5.5980556,
    40.34777779906893
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA RASPA',
    'Solosancho',
    NULL,
    920291157,
    'http://www.wikidata.org/entity/Q1610933',
    'https://www.wikidata.org/wiki/Q1610933#/media/File:Solosancho_01_by-dpc.jpg',
    792,
    -4.9041177,
    40.55262409906787
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA JUNTANA',
    'Tormellas',
    NULL,
    69903850,
    'http://www.wikidata.org/entity/Q1607010',
    'https://www.wikidata.org/wiki/Q1607010#/media/File:Tormellas_4.jpg',
    37,
    -5.510649199999999,
    40.30452329906916
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL MENDRUGO I',
    'Tornadizos de Ávila',
    'www.elmendrugo.com',
    63550036,
    'http://www.wikidata.org/entity/Q1627969',
    'https://www.wikidata.org/wiki/Q1627969#/media/File:Tornadizos_de_Ávila.jpg',
    451,
    -4.614049,
    40.626234899067505
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL MENDRUGO II',
    'Tornadizos de Ávila',
    'www.elmendrugo.com',
    635500036,
    'http://www.wikidata.org/entity/Q1627969',
    'https://www.wikidata.org/wiki/Q1627969#/media/File:Tornadizos_de_Ávila.jpg',
    451,
    -4.614049,
    40.626234899067505
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA  ABILIO',
    'Villatoro',
    NULL,
    626583505,
    'http://www.wikidata.org/entity/Q1630428',
    'https://www.wikidata.org/wiki/Q1630428#/media/File:Villatoro,_Ávila_03.jpg',
    156,
    -5.113249299999999,
    40.555898499067844
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CHIMENEA',
    'Villatoro',
    NULL,
    626583505,
    'http://www.wikidata.org/entity/Q1630428',
    'https://www.wikidata.org/wiki/Q1630428#/media/File:Villatoro,_Ávila_03.jpg',
    156,
    -5.113249299999999,
    40.555898499067844
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'BARRIO DE ARRIBA',
    'Villatoro',
    NULL,
    920213269,
    'http://www.wikidata.org/entity/Q1630428',
    'https://www.wikidata.org/wiki/Q1630428#/media/File:Villatoro,_Ávila_03.jpg',
    156,
    -5.1132469,
    40.55638549906785
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA CASA DE LA PLAZA',
    'Zapardiel de la Ribera',
    NULL,
    920349531,
    'http://www.wikidata.org/entity/Q538770',
    'https://www.wikidata.org/wiki/Q538770#/media/File:Zapardiel_de_la_Ribera.jpg',
    92,
    -5.589166699999999,
    40.33694439906898
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PINTORA',
    'Aranda de Duero',
    NULL,
    600401082,
    'http://www.wikidata.org/entity/Q495380',
    'https://www.wikidata.org/wiki/Q495380#/media/File:Aranda_de_Duero_Aerea.jpg',
    33172,
    -3.6665491999999986,
    41.70102389906283
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'BACO',
    'Baños de Valdearados',
    'www.casaruralbaco.com',
    947534155,
    'http://www.wikidata.org/entity/Q929461',
    'https://www.wikidata.org/wiki/Q929461#/media/File:Iglesia_de_la_Asunción_BdV_6.jpg',
    332,
    -3.5567120000000005,
    42.7694809990595
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LA HENERA',
    'Barrios de Colina',
    'www.sanjuandeortega.es',
    947409935,
    'http://www.wikidata.org/entity/Q1448007',
    'https://www.wikidata.org/wiki/Q1448007#/media/File:Iglesia_de_San_Juan_de_Ortega,_Burgos.JPG',
    56,
    -3.436035,
    42.37548499906057
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LAS MACHORRAS I',
    'Espinosa de los Monteros',
    NULL,
    947143764,
    'http://www.wikidata.org/entity/Q507149',
    'https://www.wikidata.org/wiki/Q507149#/media/File:Vista_Amplia_Espinosa.JPG',
    1642,
    -3.5892778,
    43.116611099058694
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LAS MACHORRAS',
    'Espinosa de los Monteros',
    NULL,
    947143764,
    'http://www.wikidata.org/entity/Q507149',
    'https://www.wikidata.org/wiki/Q507149#/media/File:Vista_Amplia_Espinosa.JPG',
    1642,
    -3.5476617,
    43.07947009905878
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LAS MACHORRAS II',
    'Espinosa de los Monteros',
    NULL,
    947143764,
    'http://www.wikidata.org/entity/Q507149',
    'https://www.wikidata.org/wiki/Q507149#/media/File:Vista_Amplia_Espinosa.JPG',
    1642,
    -3.5924167000000002,
    43.116611099058694
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'CASTRO VALNERA',
    'Espinosa de los Monteros',
    NULL,
    651359659,
    'http://www.wikidata.org/entity/Q507149',
    'https://www.wikidata.org/wiki/Q507149#/media/File:Vista_Amplia_Espinosa.JPG',
    1642,
    -3.6129999999999995,
    43.128999999058664
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'POZA DE LA TORCA I',
    'Frías',
    NULL,
    629862468,
    'http://www.wikidata.org/entity/Q1657230',
    'https://www.wikidata.org/wiki/Q1657230#/media/File:Fr�as_.jpg',
    267,
    -3.3045880000000003,
    42.75073099905955
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'POZA DE LA TORCA II',
    'Frías',
    NULL,
    693758611,
    'http://www.wikidata.org/entity/Q1657230',
    'https://www.wikidata.org/wiki/Q1657230#/media/File:Fr�as_.jpg',
    267,
    -3.3045800000000005,
    42.750730999059556
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA TEJERA',
    'Huerta de Rey',
    'www.latejera.eu5.org',
    635594939,
    'http://www.wikidata.org/entity/Q1645211',
    'https://www.wikidata.org/wiki/Q1645211#/media/File:Huerta_atardecer.jpg',
    894,
    -3.3491299999999997,
    41.839899999062325
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CONEJERA',
    'Madrigalejo del Monte',
    'www.casarurallaconejera.es',
    659751544,
    'http://www.wikidata.org/entity/Q1643642',
    'https://www.wikidata.org/wiki/Q1643642#/media/File:Casa_consistorial_de_Madrigalejo_del_Monte.jpg',
    183,
    -3.725133,
    42.123785999061354
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'REOYO I',
    'Mambrilla de Castrejón',
    'www.casaruralreoyo.com',
    947540444,
    'http://www.wikidata.org/entity/Q1630618',
    'https://www.wikidata.org/wiki/Q1630618#/media/File:Mambrilla_de_Castrej�n_entrada.jpg',
    107,
    -3.9852944000000003,
    41.665969999062966
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'REOYO II',
    'Mambrilla de Castrejón',
    'www.casaruralreoyo.com',
    947540444,
    'http://www.wikidata.org/entity/Q1630618',
    'https://www.wikidata.org/wiki/Q1630618#/media/File:Mambrilla_de_Castrej�n_entrada.jpg',
    107,
    -3.9852944000000003,
    41.665969999062966
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA PLATERïA ll',
    'Mambrilla de Castrejón',
    'www.casaruralreoyo.com',
    947540444,
    'http://www.wikidata.org/entity/Q1630618',
    'https://www.wikidata.org/wiki/Q1630618#/media/File:Mambrilla_de_Castrej�n_entrada.jpg',
    107,
    -3.9847299999999994,
    41.66709999906296
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA PLATERÍA l',
    'Mambrilla de Castrejón',
    'www.casaruralreoyo.com',
    947540444,
    'http://www.wikidata.org/entity/Q1630618',
    'https://www.wikidata.org/wiki/Q1630618#/media/File:Mambrilla_de_Castrej�n_entrada.jpg',
    107,
    -3.9847299999999994,
    41.66709999906296
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL CAMPANARIO',
    'Miranda de Ebro',
    'www.casaruralelcampanario.com',
    678692473,
    'http://www.wikidata.org/entity/Q11994',
    'https://www.wikidata.org/wiki/Q11994#/media/File:Puente_Carlos_III_Miranda.JPG',
    35239,
    -3.0267333,
    42.73284439905959
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL ATRIO',
    'Nava de Roa',
    NULL,
    677403588,
    'http://www.wikidata.org/entity/Q1617624',
    'https://www.wikidata.org/wiki/Q1617624#/media/File:Navaderoa.jpg',
    200,
    -3.9639982999999996,
    41.61347289906317
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL  ESQUILADOR',
    'Oña',
    NULL,
    947300109,
    'http://www.wikidata.org/entity/Q1609760',
    'https://www.wikidata.org/wiki/Q1609760#/media/File:2014-04-16_Norte_de_Burgos_188_-_O�a.jpg',
    976,
    -3.3279288,
    42.714169399059635
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA REAL',
    'Peñaranda de Duero',
    NULL,
    636687733,
    'http://www.wikidata.org/entity/Q953384',
    'https://www.wikidata.org/wiki/Q953384#/media/File:Pe�aranda_de_Duero,_Burgos,_Castilla_y_Le�n,Espa�a.jpg',
    510,
    -3.4790150999999994,
    41.68912369906287
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL TRINQUETE',
    'Peñaranda de Duero',
    NULL,
    636687733,
    'http://www.wikidata.org/entity/Q953384',
    'https://www.wikidata.org/wiki/Q953384#/media/File:Pe�aranda_de_Duero,_Burgos,_Castilla_y_Le�n,Espa�a.jpg',
    510,
    -3.478649299999999,
    41.68852869906288
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CASA DE LA ABUELA',
    'Peñaranda de Duero',
    NULL,
    609056262,
    'http://www.wikidata.org/entity/Q953384',
    'https://www.wikidata.org/wiki/Q953384#/media/File:Pe�aranda_de_Duero,_Burgos,_Castilla_y_Le�n,Espa�a.jpg',
    510,
    -3.4782526,
    41.68856949906288
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CANTAMORA',
    'Peñaranda de Duero',
    NULL,
    636687733,
    'http://www.wikidata.org/entity/Q953384',
    'https://www.wikidata.org/wiki/Q953384#/media/File:Pe�aranda_de_Duero,_Burgos,_Castilla_y_Le�n,Espa�a.jpg',
    510,
    -3.4790150999999994,
    41.68912369906287
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LOS BARRUECOS',
    'Pinilla de los Barruecos',
    'www.hrlosbarruecos.com',
    625186773,
    'http://www.wikidata.org/entity/Q957974',
    'https://www.wikidata.org/wiki/Q957974#/media/File:Panor�mica_de_Pinilla_de_los_Barruecos.jpg',
    98,
    -3.3038600000000002,
    41.91846999906205
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'CASABARRIA',
    'Pradoluengo',
    'www.casabarria.es',
    623065319,
    'http://www.wikidata.org/entity/Q932730',
    'https://www.wikidata.org/wiki/Q932730#/media/File:Pradoluengo.jpg',
    1096,
    -3.2011628,
    42.32487029906072
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LOS ROBLONES',
    'Rabanera del Pinar',
    NULL,
    619132114,
    'http://www.wikidata.org/entity/Q510140',
    'https://www.wikidata.org/wiki/Q510140#/media/File:Rabanera_del_pinar01.jpg',
    96,
    -3.1970906999999995,
    41.89577319906213
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'FUENTELAMORA',
    'La Revilla y Ahedo',
    'www.fuentelamora.com',
    947380383,
    'http://www.wikidata.org/entity/Q1643541',
    'https://www.wikidata.org/wiki/Q1643541#/media/File:Ahedo20130220171129P1170102.jpg',
    94,
    -3.330929999999999,
    42.01327399906173
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA ANTIGUA OLMA',
    'Riocavado de la Sierra',
    NULL,
    680981913,
    'http://www.wikidata.org/entity/Q764104',
    'https://www.wikidata.org/wiki/Q764104#/media/File:Riocavado_de_la_sierra.jpg',
    56,
    -3.1974239999999994,
    42.15297299906127
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'ALTO TIRON',
    'San Vicente del Valle',
    'www.altotiron.es',
    659159700,
    'http://www.wikidata.org/entity/Q1641308',
    'https://www.wikidata.org/wiki/Q1641308#/media/File:Riotiron.JPG',
    29,
    -3.162195,
    42.337203999060684
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'SANTO DOMINGO DE SILOS',
    'Santo Domingo de Silos',
    'www.apartamentosantodomingodesilos.com',
    947390053,
    'http://www.wikidata.org/entity/Q1766072',
    'https://www.wikidata.org/wiki/Q1766072#/media/File:Iglesia_de_Santo_Domingo_de_Silos.jpg',
    264,
    -3.4197,
    41.962399999061894
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LAS CONDESAS',
    'Santo Domingo de Silos',
    NULL,
    650347801,
    'http://www.wikidata.org/entity/Q1766072',
    'https://www.wikidata.org/wiki/Q1766072#/media/File:Iglesia_de_Santo_Domingo_de_Silos.jpg',
    264,
    -3.41866,
    41.9628746990619
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LAS CONDESAS I',
    'Santo Domingo de Silos',
    NULL,
    650347801,
    'http://www.wikidata.org/entity/Q1766072',
    'https://www.wikidata.org/wiki/Q1766072#/media/File:Iglesia_de_Santo_Domingo_de_Silos.jpg',
    264,
    -3.41866,
    41.9628746990619
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'MIRADOR DE SILOS',
    'Santo Domingo de Silos',
    'www.miradordesilos.com',
    947212857,
    'http://www.wikidata.org/entity/Q1766072',
    'https://www.wikidata.org/wiki/Q1766072#/media/File:Iglesia_de_Santo_Domingo_de_Silos.jpg',
    264,
    -3.4186600999999994,
    41.96287479906189
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'CASA GLORIA',
    'Sasamón',
    NULL,
    947370059,
    'http://www.wikidata.org/entity/Q1628353',
    'https://www.wikidata.org/wiki/Q1628353#/media/File:Sasamon01.jpg',
    957,
    -4.0441889,
    42.41787339906045
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'PEÑA AMAYA',
    'Sotresgudo',
    'www.casaruralamaya.com',
    947363216,
    'http://www.wikidata.org/entity/Q1641152',
    'https://www.wikidata.org/wiki/Q1641152#/media/File:Sotresgudo-junio-2014-panoramica-4.jpg',
    433,
    -4.1635906,
    42.64202479905983
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'AMAYA',
    'Sotresgudo',
    'www.casaruralamaya.com',
    947363216,
    'http://www.wikidata.org/entity/Q1641152',
    'https://www.wikidata.org/wiki/Q1641152#/media/File:Sotresgudo-junio-2014-panoramica-4.jpg',
    433,
    -4.163865299999999,
    42.64194049905983
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'FUENTEVIEJA DE TEJADA',
    'Tejada, Burgos',
    'www.casaruralfuentevieja.es',
    608393048,
    'http://www.wikidata.org/entity/Q1641349',
    'https://www.wikidata.org/wiki/Q1641349#/media/File:Ayuntamiento_de_Tejada_02.jpg',
    34,
    -3.5351999999999997,
    41.95286899906193
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'ATLANTIDA',
    'Tordómar',
    'www.atlantidarural.com',
    616071079,
    'http://www.wikidata.org/entity/Q1641163',
    'https://www.wikidata.org/wiki/Q1641163#/media/File:VistaDeTord�mar-rectangular.jpg',
    324,
    -3.871503000000001,
    42.04336799906162
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA CONDESONA',
    'Torresandino',
    'www.lacondesona.com',
    646074684,
    'http://www.wikidata.org/entity/Q1630680',
    'https://www.wikidata.org/wiki/Q1630680#/media/File:Torresandino20110908152718P1130302.jpg',
    583,
    -3.9094443999999995,
    41.82944439906235
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LAS FUENTES DE MENA',
    'Valle de Mena',
    NULL,
    947126198,
    'http://www.wikidata.org/entity/Q1614774',
    'https://www.wikidata.org/wiki/Q1614774#/media/File:Mena.jpg',
    4030,
    -3.342561000000001,
    43.08261699905877
),

(
    'Alojam. Turismo Rural',
    'Posada',
    '2 Estrellas',
    'POSADA DON SAULO',
    'Valle de Mena',
    'www.grupodonpablo.com',
    947126663,
    'http://www.wikidata.org/entity/Q1614774',
    'https://www.wikidata.org/wiki/Q1614774#/media/File:Mena.jpg',
    4030,
    -3.270156,
    43.10630599905874
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA CASA DE LA SERENIDAD',
    'Valle de Oca',
    NULL,
    678167026,
    'http://www.wikidata.org/entity/Q1656723',
    'https://www.wikidata.org/wiki/Q1656723#/media/File:Iglesia_1986.jpg',
    165,
    -3.320563,
    42.4356739990604
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LOLO Y VICENT',
    'Valle de Sedano',
    'www.casadeloloyvicent.es',
    947150267,
    'http://www.wikidata.org/entity/Q746624',
    'https://www.wikidata.org/wiki/Q746624#/media/File:Iglesia_de_Sedano.jpg',
    417,
    -3.7509022000000005,
    42.72323529905962
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL MOLINO DE LA CASCADA',
    'Valle de Sedano',
    'www.elmolinodeorbaneja.com',
    947150900,
    'http://www.wikidata.org/entity/Q746624',
    'https://www.wikidata.org/wiki/Q746624#/media/File:Iglesia_de_Sedano.jpg',
    417,
    -3.793611100000001,
    42.83472219905933
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'COLÁS',
    'Valle de Tobalina',
    NULL,
    947358734,
    'http://www.wikidata.org/entity/Q1630657',
    'https://www.wikidata.org/wiki/Q1630657#/media/File:Iglesia_de_Herr�n.JPG',
    896,
    -3.3269175,
    42.80338169905942
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL PAJAR',
    'Valle de Tobalina',
    'www.clubrural.net/El Pajar',
    677231998,
    'http://www.wikidata.org/entity/Q1630657',
    'https://www.wikidata.org/wiki/Q1630657#/media/File:Iglesia_de_Herr�n.JPG',
    896,
    -3.3202693999999995,
    42.78806939905945
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DEL ABUELO VICTOR',
    'Valle de Valdelaguna',
    NULL,
    947215641,
    'http://www.wikidata.org/entity/Q1986407',
    'https://www.wikidata.org/wiki/Q1986407#/media/File:Huerta_de_abajo_desde_el_cuento.JPG',
    196,
    -3.335556,
    42.93472199905909
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LAS HOYAS II',
    'Valle de Valdelaguna',
    NULL,
    947380437,
    'http://www.wikidata.org/entity/Q1986407',
    'https://www.wikidata.org/wiki/Q1986407#/media/File:Huerta_de_abajo_desde_el_cuento.JPG',
    196,
    -3.1032209999999996,
    42.09512399906144
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LAS HOYAS I',
    'Valle de Valdelaguna',
    NULL,
    947380437,
    'http://www.wikidata.org/entity/Q1986407',
    'https://www.wikidata.org/wiki/Q1986407#/media/File:Huerta_de_abajo_desde_el_cuento.JPG',
    196,
    -3.103313,
    42.09504799906146
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DE PRIMITIVA',
    'Valle de Valdelaguna',
    NULL,
    947215641,
    'http://www.wikidata.org/entity/Q1986407',
    'https://www.wikidata.org/wiki/Q1986407#/media/File:Huerta_de_abajo_desde_el_cuento.JPG',
    196,
    -3.1383609999999997,
    42.09910399906143
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'LA CASA DEL VALLE',
    'Valle de Zamanzas',
    NULL,
    686344307,
    'http://www.wikidata.org/entity/Q1630756',
    'https://www.wikidata.org/wiki/Q1630756#/media/File:Hermitage_of_Saint_Christopher_Martyr_(Ailanes)_02.JPG',
    46,
    -3.7540967,
    42.850402199059296
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'SENDAS DEL EBRO',
    'Valle de Zamanzas',
    'www.casaruralsendasdelebro.blog',
    947621907,
    'http://www.wikidata.org/entity/Q1630756',
    'https://www.wikidata.org/wiki/Q1630756#/media/File:Hermitage_of_Saint_Christopher_Martyr_(Ailanes)_02.JPG',
    46,
    -3.4859,
    42.856199999059285
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LA FONDA LEAL',
    'La Vid y Barrios',
    'www.lafondaleal.com',
    679963522,
    'http://www.wikidata.org/entity/Q1643567',
    'https://www.wikidata.org/wiki/Q1643567#/media/File:La_Vid,_monasterio-PM_17526.jpg',
    260,
    -3.4589469999999998,
    41.62149899906313
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'PUERTA NORTE',
    'Villadiego',
    'www.casaruralpuertanorte.com',
    947361878,
    'http://www.wikidata.org/entity/Q1630718',
    'https://www.wikidata.org/wiki/Q1630718#/media/File:Padre_Florez.jpg',
    1478,
    -4.008867,
    42.516020999060174
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'LA ALPARGATERIA',
    'Villafranca Montes de Oca',
    'www.casaruralalpargateria.es',
    947582029,
    'http://www.wikidata.org/entity/Q959000',
    'https://www.wikidata.org/wiki/Q959000#/media/File:Perlineus_Sint-Dj�ke_Villafranca_Montes_de_Oca.JPG',
    116,
    -3.3080586999999997,
    42.39006999906054
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'CASA DE LOS DESEOS',
    'Villambistia',
    NULL,
    653326020,
    'http://www.wikidata.org/entity/Q958629',
    'https://www.wikidata.org/wiki/Q958629#/media/File:Villambistia,_Burgos.JPG',
    45,
    -3.2591666999999998,
    42.411944399060474
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'CASA ZARRACATANITA',
    'Villanueva de Carazo',
    'www.casaruralelartedevivir.com',
    653236221,
    'http://www.wikidata.org/entity/Q1630669',
    'https://www.wikidata.org/wiki/Q1630669#/media/File:VillanuevaDeCarazo20100203074024SAM_1907.jpg',
    24,
    -3.322644899999999,
    41.98579029906181
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'ANA MARI',
    'Villarcayo de Merindad de Castilla la Vieja',
    'www.anamari.org',
    947131528,
    'http://www.wikidata.org/entity/Q370934',
    'https://www.wikidata.org/wiki/Q370934#/media/File:Plazavillarcayo.JPG',
    3942,
    -3.5997361,
    42.941140299059086
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DEL MANCO',
    'Arganza',
    NULL,
    987568614,
    'http://www.wikidata.org/entity/Q1607162',
    'https://www.wikidata.org/wiki/Q1607162#/media/File:Colegio_p�blico_de_Arganza_y_Ayuntamiento.jpg',
    778,
    -6.704230899999999,
    42.67647739905975
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA CALISTA',
    'Astorga',
    'www.lacalista.com',
    654170118,
    'http://www.wikidata.org/entity/Q465078',
    'https://www.wikidata.org/wiki/Q465078#/media/File:A�rea_de_Astorga_02.jpg',
    10392,
    -6.1301135,
    42.46534679906031
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'EL CAMINANTE',
    'Astorga',
    NULL,
    987691098,
    'http://www.wikidata.org/entity/Q465078',
    'https://www.wikidata.org/wiki/Q465078#/media/File:A�rea_de_Astorga_02.jpg',
    10392,
    -6.158202,
    42.45517379906034
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'LOS NOGALES',
    'Los Barrios de Luna',
    NULL,
    987581422,
    'http://www.wikidata.org/entity/Q26442',
    'https://www.wikidata.org/wiki/Q26442#/media/File:Los_Barrios_de_Luna_(Le�n).JPG',
    299,
    -5.8657761,
    42.84271049905932
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL SARDÓN',
    'Bembibre',
    NULL,
    628121230,
    'http://www.wikidata.org/entity/Q1157834',
    'https://www.wikidata.org/wiki/Q1157834#/media/File:Bembibre.JPG',
    8279,
    -6.4066707,
    42.66773059905976
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'PIEDRAS BLANCAS',
    'El Burgo Ranero',
    NULL,
    607163982,
    'http://www.wikidata.org/entity/Q26585',
    'https://www.wikidata.org/wiki/Q26585#/media/File:El_Burgo_Ranero.jpg',
    697,
    -5.220188499999999,
    42.42334729906043
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'LA ERA II',
    'Burón',
    NULL,
    987740096,
    'http://www.wikidata.org/entity/Q26640',
    'https://www.wikidata.org/wiki/Q26640#/media/File:Polvoredo_panoramica.JPG',
    290,
    -5.093226999999999,
    43.04016229905886
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'LA ERA I',
    'Burón',
    NULL,
    987740096,
    'http://www.wikidata.org/entity/Q26640',
    'https://www.wikidata.org/wiki/Q26640#/media/File:Polvoredo_panoramica.JPG',
    290,
    -5.093226999999999,
    43.04016229905886
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL LAGAR',
    'Cacabelos',
    NULL,
    987563210,
    'http://www.wikidata.org/entity/Q695202',
    'https://www.wikidata.org/wiki/Q695202#/media/File:Cacabelos-Santa-Maria.jpg',
    4874,
    -6.723607999999998,
    42.633390999059856
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'EL RINCÓN DEL CUCO',
    'Candín',
    'www.elrincondelcuco.com',
    987564321,
    'http://www.wikidata.org/entity/Q1615397',
    'https://www.wikidata.org/wiki/Q1615397#/media/File:Pereda_de_Ancares_03.jpg',
    248,
    -6.7279541,
    42.816529699059394
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL LOCEO',
    'Candín',
    'www.valledeancares.com',
    987564284,
    'http://www.wikidata.org/entity/Q1615397',
    'https://www.wikidata.org/wiki/Q1615397#/media/File:Pereda_de_Ancares_03.jpg',
    248,
    -6.7279541,
    42.816529699059394
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CORNATELIA I',
    'Carracedelo',
    'www.casa-cornatelia.com',
    987562817,
    'http://www.wikidata.org/entity/Q1442707',
    'https://www.wikidata.org/wiki/Q1442707#/media/File:Carracedo_(Le)_-_Monasterio_de_Santa_Maria_07.jpg',
    3434,
    -6.7297123,
    42.55540119906006
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CORNATELIA II',
    'Carracedelo',
    'www.casa-cornatelia.com',
    644889919,
    'http://www.wikidata.org/entity/Q1442707',
    'https://www.wikidata.org/wiki/Q1442707#/media/File:Carracedo_(Le)_-_Monasterio_de_Santa_Maria_07.jpg',
    3434,
    -6.7297123,
    42.55540119906006
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA BAENA',
    'Carrocera',
    'www.encuevas.com',
    626721040,
    'http://www.wikidata.org/entity/Q137207',
    'https://www.wikidata.org/wiki/Q137207#/media/File:Piedrasecha_05_by-dpc.jpg',
    458,
    -5.7524077,
    42.81556589905938
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS CALDERONES DE PIEDRASECHA  I',
    'Carrocera',
    'WWW.LOSCALDERONES.COM',
    987581300,
    'http://www.wikidata.org/entity/Q137207',
    'https://www.wikidata.org/wiki/Q137207#/media/File:Piedrasecha_05_by-dpc.jpg',
    458,
    -5.7789236,
    42.823447599059364
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS CALDERONES DE PIEDRASECHA  II',
    'Carrocera',
    'WWWLOSCALDERONES.COM',
    987581300,
    'http://www.wikidata.org/entity/Q137207',
    'https://www.wikidata.org/wiki/Q137207#/media/File:Piedrasecha_05_by-dpc.jpg',
    458,
    -5.7789236,
    42.823447599059364
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA OCA',
    'Carrocera',
    'www.casarurallaoca.com',
    609221179,
    'http://www.wikidata.org/entity/Q137207',
    'https://www.wikidata.org/wiki/Q137207#/media/File:Piedrasecha_05_by-dpc.jpg',
    458,
    -5.7688156,
    42.786705299059456
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CARRILES ROMANOS',
    'Castrillo de Cabrera',
    'www.carrilesromanos.es',
    629158842,
    'http://www.wikidata.org/entity/Q141252',
    'https://www.wikidata.org/wiki/Q141252#/media/File:Noceda_de_Cabrera1.JPG',
    106,
    -6.593683,
    42.34811299906066
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'NUESTRA SEÑORA DE LOURDES',
    'Hospital de Órbigo',
    NULL,
    987388253,
    'http://www.wikidata.org/entity/Q848293',
    'https://www.wikidata.org/wiki/Q848293#/media/File:Puente_del_Paso_Honroso_en_Hospital_de_Orbigo.jpg',
    981,
    -5.8819108,
    42.46361439906032
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA TRALLERA',
    'Igüeña',
    'WWW.COLINASDELCAMPO.ES',
    676415797,
    'http://www.wikidata.org/entity/Q44791',
    'https://www.wikidata.org/wiki/Q44791#/media/File:',
    1108,
    -6.291554999999999,
    42.76901699905949
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA GORTINA',
    'Igüeña',
    NULL,
    987519566,
    'http://www.wikidata.org/entity/Q44791',
    'https://www.wikidata.org/wiki/Q44791#/media/File:',
    1108,
    -6.292793999999999,
    42.76901599905949
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CENTRAL DE ROBLEDO',
    'Magaz de Cepeda',
    NULL,
    987636018,
    'http://www.wikidata.org/entity/Q141235',
    'https://www.wikidata.org/wiki/Q141235#/media/File:Magaz_de_Cepeda.jpg',
    357,
    -6.0740204,
    42.53924139906011
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'CASA JOACO',
    'Mansilla Mayor',
    'www.casajoaco.com',
    987310062,
    'http://www.wikidata.org/entity/Q141177',
    'https://www.wikidata.org/wiki/Q141177#/media/File:Plaza_del_Ayuntamiento,_Mansilla_Mayor.jpg',
    327,
    -5.4426935,
    42.509312099060196
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'LA TRUCHA DEL ARCO IRIS',
    'Molinaseca',
    'WWW.CASARURALACEBO.COM',
    987695548,
    'http://www.wikidata.org/entity/Q44873',
    'https://www.wikidata.org/wiki/Q44873#/media/File:Molinaseca_Bridge_2005.jpg',
    851,
    -6.457425000000001,
    42.49869499906023
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'ABUELO JOSE I',
    'Noceda del Bierzo',
    'www.abuelojose.com',
    987511980,
    'http://www.wikidata.org/entity/Q44799',
    'https://www.wikidata.org/wiki/Q44799#/media/File:Noceda_del_Bierzo_(Le�n)_(03).jpg',
    612,
    -6.4024279,
    42.70636579905966
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DO CONCELLO',
    'Oencia',
    'www.casadoconcello.com',
    987421647,
    'http://www.wikidata.org/entity/Q1617652',
    'https://www.wikidata.org/wiki/Q1617652#/media/File:Oencia-iglesia1.jpg',
    267,
    -6.9772844,
    42.53400599906012
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LOS DE LA CENTRAL',
    'Oseja de Sajambre',
    NULL,
    655854178,
    'http://www.wikidata.org/entity/Q1640150',
    'https://www.wikidata.org/wiki/Q1640150#/media/File:VistaDeOsejaDeSajambre2.jpg',
    236,
    -5.04823,
    43.124324999058686
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA CASA DE MARTINA',
    'Oseja de Sajambre',
    NULL,
    651190831,
    'http://www.wikidata.org/entity/Q1640150',
    'https://www.wikidata.org/wiki/Q1640150#/media/File:VistaDeOsejaDeSajambre2.jpg',
    236,
    -5.054468,
    43.141265999058646
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'SEÑORIO DE LOS BAZAN',
    'Palacios de la Valduerna',
    'www.senoriodelosbazan.com',
    987665628,
    'http://www.wikidata.org/entity/Q137186',
    'https://www.wikidata.org/wiki/Q137186#/media/File:Plaza_del_grande.jpg',
    366,
    -5.9342131,
    42.32683819906072
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA ALBINA',
    'Palacios del Sil',
    NULL,
    987488054,
    'http://www.wikidata.org/entity/Q1391476',
    'https://www.wikidata.org/wiki/Q1391476#/media/File:Tejedo.jpg',
    886,
    -6.4992605,
    42.84179399905932
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL CORREDOR',
    'La Pola de Gordón',
    NULL,
    647852197,
    'http://www.wikidata.org/entity/Q1605928',
    'https://www.wikidata.org/wiki/Q1605928#/media/File:La_Pola_de_Gord�n_-_Ayuntamiento_01.jpg',
    2929,
    -5.6815666,
    42.86756489905926
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'CAMINO MÉDULAS I',
    'Ponferrada',
    'www.hotelruralcaminomedulas.com',
    987426900,
    'http://www.wikidata.org/entity/Q12164',
    'https://www.wikidata.org/wiki/Q12164#/media/File:Ayto_ponferrada_2005.jpg',
    63052,
    -6.6050014,
    42.54682919906008
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'RIBERA DEL CANTERO',
    'Ponferrada',
    NULL,
    987791949,
    'http://www.wikidata.org/entity/Q12164',
    'https://www.wikidata.org/wiki/Q12164#/media/File:Ayto_ponferrada_2005.jpg',
    63052,
    -6.600107099999998,
    42.55247169906008
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'MIRALMONTE',
    'Ponferrada',
    NULL,
    619723561,
    'http://www.wikidata.org/entity/Q12164',
    'https://www.wikidata.org/wiki/Q12164#/media/File:Ayto_ponferrada_2005.jpg',
    63052,
    -6.6149593,
    42.54385369906009
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'FLORENCIA',
    'Posada de Valdeón',
    NULL,
    681153190,
    'http://www.wikidata.org/entity/Q1635220',
    'https://www.wikidata.org/wiki/Q1635220#/media/File:Posada_de_Valde�n.jpg',
    420,
    -4.930715,
    43.146633999058636
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'PICOS DE EUROPA',
    'Posada de Valdeón',
    'www.picosdeeuropa.org',
    987740593,
    'http://www.wikidata.org/entity/Q1635220',
    'https://www.wikidata.org/wiki/Q1635220#/media/File:Posada_de_Valde�n.jpg',
    420,
    -4.922411,
    43.15081899905862
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'ABEDUL',
    'Puebla de Lillo',
    'WWW.SUSARON.NET',
    654300300,
    'http://www.wikidata.org/entity/Q1615418',
    'https://www.wikidata.org/wiki/Q1615418#/media/File:VistaLillo.JPG',
    666,
    -5.2734611,
    43.00782119905894
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA MAMPODRE',
    'Puebla de Lillo',
    NULL,
    987731027,
    'http://www.wikidata.org/entity/Q1615418',
    'https://www.wikidata.org/wiki/Q1615418#/media/File:VistaLillo.JPG',
    666,
    -5.2734611,
    43.00782119905894
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'HOSPITAL DEL CAMINANTE I',
    'Puebla de Lillo',
    'WWW.HOSPITALDELCAMINANTE.COM',
    646232367,
    'http://www.wikidata.org/entity/Q1615418',
    'https://www.wikidata.org/wiki/Q1615418#/media/File:VistaLillo.JPG',
    666,
    -5.274403,
    43.00784599905894
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'ARROYO MURIAS',
    'Puebla de Lillo',
    NULL,
    987731027,
    'http://www.wikidata.org/entity/Q1615418',
    'https://www.wikidata.org/wiki/Q1615418#/media/File:VistaLillo.JPG',
    666,
    -5.2734611,
    43.00782119905894
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'PEÑA POLINOSA',
    'Puebla de Lillo',
    NULL,
    987731027,
    'http://www.wikidata.org/entity/Q1615418',
    'https://www.wikidata.org/wiki/Q1615418#/media/File:VistaLillo.JPG',
    666,
    -5.2734611,
    43.00782119905894
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'HOSPITAL DEL CAMINANTE II',
    'Puebla de Lillo',
    'WWW.HOSPITALDELCAMINANTE.COM',
    646232367,
    'http://www.wikidata.org/entity/Q1615418',
    'https://www.wikidata.org/wiki/Q1615418#/media/File:VistaLillo.JPG',
    666,
    -5.274306999999999,
    43.00792399905894
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'BARBADIEL',
    'Quintana del Castillo',
    NULL,
    650425528,
    'http://www.wikidata.org/entity/Q137729',
    'https://www.wikidata.org/wiki/Q137729#/media/File:24397_Quintana_del_Castillo,_Le�n,_Spain_-_panoramio.jpg',
    709,
    -5.923664999999999,
    42.582588299059985
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'MIRADOR DE BABIA II',
    'San Emiliano',
    'WWW.MIRADORDEBABIA.COM',
    655867674,
    'http://www.wikidata.org/entity/Q141211',
    'https://www.wikidata.org/wiki/Q141211#/media/File:La_Iglesia_de_San_Emiliano.jpg',
    626,
    -6.0007506,
    42.971710599059016
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LA CASONA DE BABIA',
    'San Emiliano',
    'WWW.CASONADEBABIA.COM',
    987594014,
    'http://www.wikidata.org/entity/Q141211',
    'https://www.wikidata.org/wiki/Q141211#/media/File:La_Iglesia_de_San_Emiliano.jpg',
    626,
    -5.9914480999999995,
    43.011808499058915
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'MIRADOR DE BABIA I',
    'San Emiliano',
    'WWW.MIRADORDEBABIA.COM',
    655867674,
    'http://www.wikidata.org/entity/Q141211',
    'https://www.wikidata.org/wiki/Q141211#/media/File:La_Iglesia_de_San_Emiliano.jpg',
    626,
    -6.0007506,
    42.971710599059016
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LA POSADA DE GASPAR',
    'Santa Colomba de Somoza',
    'www.laposadadegaspar.com',
    987631629,
    'http://www.wikidata.org/entity/Q141080',
    'https://www.wikidata.org/wiki/Q141080#/media/File:Calle_Mayor,_Santa_Colomba_de_Somoza.jpg',
    529,
    -6.285758,
    42.48244299906027
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA COLOMBA',
    'Santa Colomba de Somoza',
    'www.casacolomba.com',
    606381337,
    'http://www.wikidata.org/entity/Q141080',
    'https://www.wikidata.org/wiki/Q141080#/media/File:Calle_Mayor,_Santa_Colomba_de_Somoza.jpg',
    529,
    -6.246404000000001,
    42.44468899906037
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'EL MOLINERO DE SANTA COLOMBA DE SOMOZA',
    'Santa Colomba de Somoza',
    NULL,
    987631591,
    'http://www.wikidata.org/entity/Q141080',
    'https://www.wikidata.org/wiki/Q141080#/media/File:Calle_Mayor,_Santa_Colomba_de_Somoza.jpg',
    529,
    -6.242626,
    42.44326199906037
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CASA DEL ABUELO JULIAN',
    'Toreno',
    'WWW.CASASRURALESENELBIERZO.COM',
    987533612,
    'http://www.wikidata.org/entity/Q44913',
    'https://www.wikidata.org/wiki/Q44913#/media/File:Toreno_nevado.jpg',
    2980,
    -6.459898699999999,
    42.71960579905962
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'CASINA DE SARA',
    'Toreno',
    NULL,
    652129648,
    'http://www.wikidata.org/entity/Q44913',
    'https://www.wikidata.org/wiki/Q44913#/media/File:Toreno_nevado.jpg',
    2980,
    -6.530390399999999,
    42.75590649905954
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA ROSALIA',
    'Trabadelo',
    NULL,
    696978652,
    'http://www.wikidata.org/entity/Q842698',
    'https://www.wikidata.org/wiki/Q842698#/media/File:Pereje.jpg',
    338,
    -6.8813079,
    42.64939949905981
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CADEVILLA',
    'Truchas',
    NULL,
    987664722,
    'http://www.wikidata.org/entity/Q1774781',
    'https://www.wikidata.org/wiki/Q1774781#/media/File:Truchas_Paisaje_20110424.jpg',
    418,
    -6.4627541000000015,
    42.28340589906085
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LOS ARGÜELLOS',
    'Valdelugueros',
    NULL,
    681189671,
    'http://www.wikidata.org/entity/Q1635276',
    'https://www.wikidata.org/wiki/Q1635276#/media/File:Luguerospueblo.jpg',
    501,
    -5.413597900000001,
    42.972255499059024
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA MURIA',
    'Valderrueda',
    NULL,
    648060298,
    'http://www.wikidata.org/entity/Q1615406',
    'https://www.wikidata.org/wiki/Q1615406#/media/File:Big_12611163_0_500-375.jpg',
    820,
    -4.9922991,
    42.8091776990594
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'MAGDALENA I',
    'Vega de Espinareda',
    NULL,
    987568806,
    'http://www.wikidata.org/entity/Q1605960',
    'https://www.wikidata.org/wiki/Q1605960#/media/File:Monasterio_de_San_Andr�s_de_Vega_de_Espinareda_(422509303).jpg',
    2018,
    -6.6512528,
    42.71254409905965
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'MAGDALENA II',
    'Vega de Espinareda',
    NULL,
    987568806,
    'http://www.wikidata.org/entity/Q1605960',
    'https://www.wikidata.org/wiki/Q1605960#/media/File:Monasterio_de_San_Andr�s_de_Vega_de_Espinareda_(422509303).jpg',
    2018,
    -6.6512528,
    42.71254409905965
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA ANTONIO',
    'Vega de Espinareda',
    NULL,
    987568588,
    'http://www.wikidata.org/entity/Q1605960',
    'https://www.wikidata.org/wiki/Q1605960#/media/File:Monasterio_de_San_Andr�s_de_Vega_de_Espinareda_(422509303).jpg',
    2018,
    -6.713259399999999,
    42.73138719905959
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA ABUELA',
    'Vega de Espinareda',
    'www.casarurallaabuela.com',
    689912546,
    'http://www.wikidata.org/entity/Q1605960',
    'https://www.wikidata.org/wiki/Q1605960#/media/File:Monasterio_de_San_Andr�s_de_Vega_de_Espinareda_(422509303).jpg',
    2018,
    -6.713259399999999,
    42.73138719905959
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL PAJAR DE INES',
    'Vega de Espinareda',
    NULL,
    987568408,
    'http://www.wikidata.org/entity/Q1605960',
    'https://www.wikidata.org/wiki/Q1605960#/media/File:Monasterio_de_San_Andr�s_de_Vega_de_Espinareda_(422509303).jpg',
    2018,
    -6.7134952000000006,
    42.73117939905959
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'EL PARAISO DEL BIERZO',
    'Vega de Valcarce',
    'www.paraisodelbierzo.com',
    987684137,
    'http://www.wikidata.org/entity/Q918084',
    'https://www.wikidata.org/wiki/Q918084#/media/File:Vegadevalcarce.jpg',
    579,
    -6.975336999999999,
    42.67247399905975
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA CALECHA',
    'Villablino',
    'www.casacalecha.com',
    987490110,
    'http://www.wikidata.org/entity/Q1605938',
    'https://www.wikidata.org/wiki/Q1605938#/media/File:San_Miguel_de_Laciana_y_Villablino.jpg',
    8086,
    -6.371289,
    42.952839999059066
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'MONTEALEGRE',
    'Villagatón',
    'WWW-CTRMONTEALEGRE.NET',
    987691823,
    'http://www.wikidata.org/entity/Q1622304',
    'https://www.wikidata.org/wiki/Q1622304#/media/File:Villagat�n_(Le�n).JPG',
    650,
    -6.1873450000000005,
    42.63218989905986
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LOS LLÁGANOS',
    'Villaturiel',
    'www.casarural.losllaganos.com',
    656412405,
    'http://www.wikidata.org/entity/Q1607183',
    'https://www.wikidata.org/wiki/Q1607183#/media/File:Roderos.jpg',
    1878,
    -5.48626,
    42.51639199906017
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA 1',
    'Aguilar de Campoo',
    'www.posadasantamarialareal.com',
    979122000,
    'http://www.wikidata.org/entity/Q398349',
    'https://www.wikidata.org/wiki/Q398349#/media/File:Aguilar_de_Campoo_entrada.jpg',
    6646,
    -4.2390083,
    42.85685559905928
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA 5 "TORRE"',
    'Aguilar de Campoo',
    'www.posadasantamarialareal.com',
    979122000,
    'http://www.wikidata.org/entity/Q398349',
    'https://www.wikidata.org/wiki/Q398349#/media/File:Aguilar_de_Campoo_entrada.jpg',
    6646,
    -4.275397,
    42.76756399905951
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA 3',
    'Aguilar de Campoo',
    'www.posadasantamarialareal.com',
    979122000,
    'http://www.wikidata.org/entity/Q398349',
    'https://www.wikidata.org/wiki/Q398349#/media/File:Aguilar_de_Campoo_entrada.jpg',
    6646,
    -4.2390083,
    42.85685559905928
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA 4',
    'Aguilar de Campoo',
    'www.posadasantamarialareal.com',
    979122000,
    'http://www.wikidata.org/entity/Q398349',
    'https://www.wikidata.org/wiki/Q398349#/media/File:Aguilar_de_Campoo_entrada.jpg',
    6646,
    -4.2390083,
    42.85685559905928
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA 2',
    'Aguilar de Campoo',
    'www.posadasantamarialareal.com',
    979122000,
    'http://www.wikidata.org/entity/Q398349',
    'https://www.wikidata.org/wiki/Q398349#/media/File:Aguilar_de_Campoo_entrada.jpg',
    6646,
    -4.275397,
    42.76756399905951
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'VILLA Y CORTE',
    'Ampudia',
    'www.villaycorte.com',
    979768632,
    'http://www.wikidata.org/entity/Q1657195',
    'https://www.wikidata.org/wiki/Q1657195#/media/File:Ampudia_-_036_(39300086170).jpg',
    600,
    -4.780366100000001,
    41.91698779906206
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PAVANA',
    'Ampudia',
    'www.casarurallapavana.com',
    607357694,
    'http://www.wikidata.org/entity/Q1657195',
    'https://www.wikidata.org/wiki/Q1657195#/media/File:Ampudia_-_036_(39300086170).jpg',
    600,
    -4.7812389,
    41.916285199062045
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'SAN VITORES',
    'Astudillo, Palencia',
    'www.apatur.org',
    979822090,
    'http://www.wikidata.org/entity/Q1849424',
    'https://www.wikidata.org/wiki/Q1849424#/media/File:Plaza_mayor1ast.jpg',
    1031,
    -4.296059,
    42.19396299906113
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'CASA EBRO',
    'Berzosilla',
    NULL,
    979181323,
    'http://www.wikidata.org/entity/Q1907531',
    'https://www.wikidata.org/wiki/Q1907531#/media/File:Ermitabascones.jpg',
    40,
    -4.0112962,
    42.779891999059465
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'JARÍN MANDALA - LOS OTOÑOS',
    'Brañosera',
    NULL,
    657913208,
    'http://www.wikidata.org/entity/Q1923970',
    'https://www.wikidata.org/wiki/Q1923970#/media/File:Bra�osera,_Primer_ayuntamiento_de_Espa�a.JPG',
    252,
    -4.240591000000001,
    42.913209999059156
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CUADRA DE LA TILA',
    'Castrejón de la Peña',
    'www.latilacasarural.com',
    678860910,
    'http://www.wikidata.org/entity/Q1929204',
    'https://www.wikidata.org/wiki/Q1929204#/media/File:AyuntamientoCastrej�nPe�a_001.JPG',
    332,
    -4.625658,
    42.7680609990595
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA TILA',
    'Castrejón de la Peña',
    NULL,
    678860910,
    'http://www.wikidata.org/entity/Q1929204',
    'https://www.wikidata.org/wiki/Q1929204#/media/File:AyuntamientoCastrej�nPe�a_001.JPG',
    332,
    -4.667255,
    42.82024199905938
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'CASA MEDIAVILLA',
    'Cervera de Pisuerga',
    NULL,
    979877636,
    'http://www.wikidata.org/entity/Q1771120',
    'https://www.wikidata.org/wiki/Q1771120#/media/File:Cervera_de_Pisuerga_-_021_(41066436862).jpg',
    2256,
    -4.5077053,
    42.86137019905927
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS PERALEJOS "A"',
    'Cervera de Pisuerga',
    NULL,
    979184286,
    'http://www.wikidata.org/entity/Q1771120',
    'https://www.wikidata.org/wiki/Q1771120#/media/File:Cervera_de_Pisuerga_-_021_(41066436862).jpg',
    2256,
    -4.5583772,
    42.90136819905918
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LA ACEÑA',
    'Cervera de Pisuerga',
    'www.casarural-acena.com',
    979870264,
    'http://www.wikidata.org/entity/Q1771120',
    'https://www.wikidata.org/wiki/Q1771120#/media/File:Cervera_de_Pisuerga_-_021_(41066436862).jpg',
    2256,
    -4.423605499999999,
    42.85353989905929
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LOS PERALEJOS "B"',
    'Cervera de Pisuerga',
    NULL,
    979184286,
    'http://www.wikidata.org/entity/Q1771120',
    'https://www.wikidata.org/wiki/Q1771120#/media/File:Cervera_de_Pisuerga_-_021_(41066436862).jpg',
    2256,
    -4.5583772,
    42.90136819905918
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA TOBA',
    'Cevico Navero',
    'www.latobacasarural.com',
    607516354,
    'http://www.wikidata.org/entity/Q1919414',
    'https://www.wikidata.org/wiki/Q1919414#/media/File:Cevico_Navero_vistas.jpg',
    189,
    -4.1860705,
    41.861469499062245
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'HOTEL RURAL SAN PEDRO',
    'Frómista',
    NULL,
    979810016,
    'http://www.wikidata.org/entity/Q988834',
    'https://www.wikidata.org/wiki/Q988834#/media/File:San_Martin_Fromista.jpg',
    768,
    -4.404694,
    42.268307999060895
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'FINCA SANTA EUFEMIA CASA DEL PASTOR',
    'Olmos de Ojeda',
    'www.lagranjasantaeufemia.com',
    636328534,
    'http://www.wikidata.org/entity/Q1919129',
    'https://www.wikidata.org/wiki/Q1919129#/media/File:Santa_Eufemia_-_Olmos_de_Ojeda_-_panoramio.jpg',
    195,
    -4.424273,
    42.729963999059606
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'FINCA SANTA EUFEMIA CASA DE LA ERA',
    'Olmos de Ojeda',
    'www.lagranjasantaeufemia.com',
    979142414,
    'http://www.wikidata.org/entity/Q1919129',
    'https://www.wikidata.org/wiki/Q1919129#/media/File:Santa_Eufemia_-_Olmos_de_Ojeda_-_panoramio.jpg',
    195,
    -4.424281,
    42.7300999990596
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'FINCA SANTA EUFEMIA CASA DEL CAPELLAN',
    'Olmos de Ojeda',
    'www.lagranjasantaeufemia.com',
    636328534,
    'http://www.wikidata.org/entity/Q1919129',
    'https://www.wikidata.org/wiki/Q1919129#/media/File:Santa_Eufemia_-_Olmos_de_Ojeda_-_panoramio.jpg',
    195,
    -4.424492,
    42.7301199990596
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'VENTA MORENA',
    'La Pernía',
    NULL,
    979879042,
    'http://www.wikidata.org/entity/Q1918857',
    'https://www.wikidata.org/wiki/Q1918857#/media/File:Lebanza_pueblo_001.jpg',
    316,
    -4.490998,
    42.94757299905907
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    '"CASA LOPE"',
    'La Pernía',
    NULL,
    979879701,
    'http://www.wikidata.org/entity/Q1918857',
    'https://www.wikidata.org/wiki/Q1918857#/media/File:Lebanza_pueblo_001.jpg',
    316,
    -4.533280400000001,
    42.996940099058975
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'AMANECER EN CAMPOS',
    'Población de Campos',
    NULL,
    979811099,
    'http://www.wikidata.org/entity/Q986562',
    'https://www.wikidata.org/wiki/Q986562#/media/File:Vista_de_Poblaci�n_de_Campos.jpg',
    132,
    -4.445518999999999,
    42.2687879990609
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CASA DEL CURA',
    'Renedo de la Vega',
    NULL,
    678832034,
    'http://www.wikidata.org/entity/Q1918767',
    'https://www.wikidata.org/wiki/Q1918767#/media/File:Renedo_de_la_Vega_02_Rollo_by-dpc.jpg',
    198,
    -4.703040099999999,
    42.45294609906034
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA VALDENIEVAS',
    'Triollo',
    NULL,
    979866163,
    'http://www.wikidata.org/entity/Q1906984',
    'https://www.wikidata.org/wiki/Q1906984#/media/File:Estela_Vidrieros_003.JPG',
    75,
    -4.6648143,
    42.942382399059085
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'CASA RURAL FUENTES CARRIONAS',
    'Triollo',
    NULL,
    609715315,
    'http://www.wikidata.org/entity/Q1906984',
    'https://www.wikidata.org/wiki/Q1906984#/media/File:Estela_Vidrieros_003.JPG',
    75,
    -4.66491,
    42.943009999059086
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA CHACON 2',
    'Velilla del Río Carrión',
    NULL,
    659118529,
    'http://www.wikidata.org/entity/Q986559',
    'https://www.wikidata.org/wiki/Q986559#/media/File:Velilla_pe�a.JPG',
    1173,
    -4.810347,
    42.87877099905923
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA CHACON 1',
    'Velilla del Río Carrión',
    NULL,
    659118529,
    'http://www.wikidata.org/entity/Q986559',
    'https://www.wikidata.org/wiki/Q986559#/media/File:Velilla_pe�a.JPG',
    1173,
    -4.810309999999999,
    42.87863699905923
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASAN I',
    'Velilla del Río Carrión',
    NULL,
    979861432,
    'http://www.wikidata.org/entity/Q986559',
    'https://www.wikidata.org/wiki/Q986559#/media/File:Velilla_pe�a.JPG',
    1173,
    -4.8466266,
    42.82393559905936
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA BECERRO',
    'La Alberca',
    NULL,
    923415102,
    'http://www.wikidata.org/entity/Q1012961',
    'https://www.wikidata.org/wiki/Q1012961#/media/File:Plaza_Mayor,_La_Alberca.JPG',
    1071,
    -6.111354,
    40.49004999906818
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'CASA NEIRA',
    'Almenara de Tormes',
    NULL,
    625601744,
    'http://www.wikidata.org/entity/Q681076',
    'https://www.wikidata.org/wiki/Q681076#/media/File:Iglesia_de_Almenara_de_Tormes_02.jpg',
    303,
    -5.82093,
    41.06439999906543
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA RESBALINA',
    'Cabeza del Caballo',
    NULL,
    949332496,
    'http://www.wikidata.org/entity/Q1639363',
    'https://www.wikidata.org/wiki/Q1639363#/media/File:Molino_de_Lucas.jpg',
    247,
    -6.5579757999999995,
    41.129396499065145
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA ZAGALA',
    'Candelario',
    'www.casazagala.com',
    620131696,
    'http://www.wikidata.org/entity/Q1777917',
    'https://www.wikidata.org/wiki/Q1777917#/media/File:Candelario_07_by-dpc_2.jpg',
    871,
    -5.7416539,
    40.365841699068824
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL BOTON CHARRO II',
    'Candelario',
    NULL,
    923413364,
    'http://www.wikidata.org/entity/Q1777917',
    'https://www.wikidata.org/wiki/Q1777917#/media/File:Candelario_07_by-dpc_2.jpg',
    871,
    -5.744507199999999,
    40.368044599068824
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA REGADERA',
    'Candelario',
    NULL,
    923413101,
    'http://www.wikidata.org/entity/Q1777917',
    'https://www.wikidata.org/wiki/Q1777917#/media/File:Candelario_07_by-dpc_2.jpg',
    871,
    -5.7416667,
    40.36638889906882
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL BOTON CHARRO I',
    'Candelario',
    NULL,
    923413364,
    'http://www.wikidata.org/entity/Q1777917',
    'https://www.wikidata.org/wiki/Q1777917#/media/File:Candelario_07_by-dpc_2.jpg',
    871,
    -5.744507199999999,
    40.368044599068824
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA MÁ LUZ',
    'Las Casas del Conde',
    'www.casamariluz.com',
    916945598,
    'http://www.wikidata.org/entity/Q1640703',
    'https://www.wikidata.org/wiki/Q1640703#/media/File:Las_Casas_del_Conde1.jpg',
    64,
    -6.0412706,
    40.507767299068085
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASONA LOS PEREGRINOS I',
    'Cepeda',
    'www.casonadelosperegrinos.com',
    923432434,
    'http://www.wikidata.org/entity/Q1640738',
    'https://www.wikidata.org/wiki/Q1640738#/media/File:CepedaI_edited.JPG',
    290,
    -6.0402395,
    40.46575409906831
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CASA DE CUTU',
    'Cepeda',
    NULL,
    923432028,
    'http://www.wikidata.org/entity/Q1640738',
    'https://www.wikidata.org/wiki/Q1640738#/media/File:CepedaI_edited.JPG',
    290,
    -6.0399733,
    40.46590709906832
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'MELANIA',
    'Cepeda',
    NULL,
    923432238,
    'http://www.wikidata.org/entity/Q1640738',
    'https://www.wikidata.org/wiki/Q1640738#/media/File:CepedaI_edited.JPG',
    290,
    -6.0403685,
    40.464850199068316
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'CASA RURAL VICTORIA',
    'El Cerro',
    NULL,
    0,
    'http://www.wikidata.org/entity/Q1770005',
    'https://www.wikidata.org/wiki/Q1770005#/media/File:Iglesia_de_El_Cerro_(Salamanca).JPG',
    380,
    -5.926444,
    40.28861799906923
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'SANJUANEJO',
    'Ciudad Rodrigo',
    NULL,
    923460398,
    'http://www.wikidata.org/entity/Q820476',
    'https://www.wikidata.org/wiki/Q820476#/media/File:Ciudad_Rodrigo.jpg',
    11973,
    -6.4918161,
    40.570605099067784
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA LANCHA',
    'Fuenteguinaldo',
    'www.casalalancha.com',
    923471027,
    'http://www.wikidata.org/entity/Q1640604',
    'https://www.wikidata.org/wiki/Q1640604#/media/File:Fuenteguinaldo_-_Portal_Cuartel_General_de_Lord_Wellington.jpg',
    667,
    -6.675620999999998,
    40.4276345990685
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'VIA DE LA PLATA',
    'Fuenterroble de Salvatierra',
    NULL,
    923613198,
    'http://www.wikidata.org/entity/Q1650181',
    'https://www.wikidata.org/wiki/Q1650181#/media/File:Iglesia_de_Fuenterroble_de_Salvatierra.JPG',
    260,
    -5.7360191,
    40.562739599067825
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA PAQUI',
    'Fuenterroble de Salvatierra',
    'www.casaruralpaqui.com',
    923151060,
    'http://www.wikidata.org/entity/Q1650181',
    'https://www.wikidata.org/wiki/Q1650181#/media/File:Iglesia_de_Fuenterroble_de_Salvatierra.JPG',
    260,
    -5.735635,
    40.56219919906782
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'VIA DE LA PLATA II',
    'Fuenterroble de Salvatierra',
    NULL,
    637714698,
    'http://www.wikidata.org/entity/Q1650181',
    'https://www.wikidata.org/wiki/Q1650181#/media/File:Iglesia_de_Fuenterroble_de_Salvatierra.JPG',
    260,
    -5.731613,
    40.5650219990678
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'CORTIJO MACOTERANO',
    'Macotera',
    NULL,
    923555642,
    'http://www.wikidata.org/entity/Q570936',
    'https://www.wikidata.org/wiki/Q570936#/media/File:Ayuntamiento_de_Macotera_y_Museo_provincial_de_las_llanuras_y_campi�as_de_Salamanca.jpg',
    999,
    -5.2855683,
    40.830519499066504
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA BELEN I',
    'Madroñal',
    NULL,
    923433035,
    'http://www.wikidata.org/entity/Q1911011',
    'https://www.wikidata.org/wiki/Q1911011#/media/File:Madro�al_-_casa_consistorial.jpg',
    140,
    -6.0631408,
    40.46350679906832
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA BELEN II',
    'Madroñal',
    NULL,
    923433035,
    'http://www.wikidata.org/entity/Q1911011',
    'https://www.wikidata.org/wiki/Q1911011#/media/File:Madro�al_-_casa_consistorial.jpg',
    140,
    -6.0624521,
    40.461750599068345
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'ALFARO I',
    'Martiago',
    NULL,
    923480125,
    'http://www.wikidata.org/entity/Q1769438',
    'https://www.wikidata.org/wiki/Q1769438#/media/File:Martiago,_plaza_Constitucional.jpg',
    267,
    -6.4905721,
    40.45224689906839
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'ALFARO II',
    'Martiago',
    NULL,
    923480125,
    'http://www.wikidata.org/entity/Q1769438',
    'https://www.wikidata.org/wiki/Q1769438#/media/File:Martiago,_plaza_Constitucional.jpg',
    267,
    -6.4905721,
    40.45224689906839
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'ALFARO IV',
    'Martiago',
    NULL,
    923480125,
    'http://www.wikidata.org/entity/Q1769438',
    'https://www.wikidata.org/wiki/Q1769438#/media/File:Martiago,_plaza_Constitucional.jpg',
    267,
    -6.4905721,
    40.45224689906839
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'ALFARO III',
    'Martiago',
    NULL,
    923480125,
    'http://www.wikidata.org/entity/Q1769438',
    'https://www.wikidata.org/wiki/Q1769438#/media/File:Martiago,_plaza_Constitucional.jpg',
    267,
    -6.4905721,
    40.45224689906839
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA ANABEL',
    'Miranda del Castañar',
    NULL,
    923432289,
    'http://www.wikidata.org/entity/Q1769783',
    'https://www.wikidata.org/wiki/Q1769783#/media/File:Miranda_del_Castanar_eljabalirosa_edited.JPG',
    396,
    -6.001026,
    40.485259999068205
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA VILLA I',
    'Miranda del Castañar',
    'www.villademiranda.com',
    923432087,
    'http://www.wikidata.org/entity/Q1769783',
    'https://www.wikidata.org/wiki/Q1769783#/media/File:Miranda_del_Castanar_eljabalirosa_edited.JPG',
    396,
    -6.001443,
    40.48565299906819
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'EL BALCON DE MOGARRAZ',
    'Mogarraz',
    'www.elbalcondemogarraz.com',
    923418104,
    'http://www.wikidata.org/entity/Q1910893',
    'https://www.wikidata.org/wiki/Q1910893#/media/File:SDFMOG01.jpg',
    240,
    -6.052808799999999,
    40.491336999068174
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'CUESTA GRANDE',
    'Pelabravo',
    'www.scapadas.com',
    923306698,
    'http://www.wikidata.org/entity/Q1768237',
    'https://www.wikidata.org/wiki/Q1768237#/media/File:Pelabravo.jpg',
    1284,
    -5.5794987,
    40.93729869906601
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA INMA',
    'San Martín del Castañar',
    NULL,
    923437348,
    'http://www.wikidata.org/entity/Q1643355',
    'https://www.wikidata.org/wiki/Q1643355#/media/File:San_Mart�n_del_Casta�ar_-_001_(33267152616).jpg',
    251,
    -6.064476699999999,
    40.522330799068015
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'EL CASTILLO I',
    'San Martín del Castañar',
    NULL,
    923437188,
    'http://www.wikidata.org/entity/Q1643355',
    'https://www.wikidata.org/wiki/Q1643355#/media/File:San_Mart�n_del_Casta�ar_-_001_(33267152616).jpg',
    251,
    -6.063604399999999,
    40.521117399068025
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA OLIVA',
    'Santibáñez de la Sierra',
    NULL,
    923435299,
    'http://www.wikidata.org/entity/Q1770816',
    'https://www.wikidata.org/wiki/Q1770816#/media/File:Panoramicasantibanezsierra.jpg',
    171,
    -5.9148161,
    40.49474609906816
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA ESPADAÑA',
    'Sequeros',
    'www.laespadanasequeros.com',
    680635877,
    'http://www.wikidata.org/entity/Q1766219',
    'https://www.wikidata.org/wiki/Q1766219#/media/File:Sequeros.JPG',
    235,
    -6.0256463,
    40.512566499068065
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA LORETO',
    'Tamames',
    NULL,
    923435433,
    'http://www.wikidata.org/entity/Q1640615',
    'https://www.wikidata.org/wiki/Q1640615#/media/File:Tamames_(Iglesia_y_ayuntamiento).JPG',
    811,
    -6.103482800000001,
    40.65565249906736
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL CARRASCAL',
    'Valdefuentes de Sangusín',
    NULL,
    923262472,
    'http://www.wikidata.org/entity/Q1995271',
    'https://www.wikidata.org/wiki/Q1995271#/media/File:Valdefuentes_de_Sangus�n_-_vista_xeral_2.jpg',
    192,
    -5.8336427,
    40.46577349906831
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LAURI',
    'Villanueva del Conde',
    NULL,
    923437576,
    'http://www.wikidata.org/entity/Q1766569',
    'https://www.wikidata.org/wiki/Q1766569#/media/File:Villanueva_del_Conde,_Camino_de_los_Prodigios.jpg',
    180,
    -6.011741,
    40.50885299906809
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA JOSE MARIA',
    'Villanueva del Conde',
    'www.casasenbatuecas.com',
    923437069,
    'http://www.wikidata.org/entity/Q1766569',
    'https://www.wikidata.org/wiki/Q1766569#/media/File:Villanueva_del_Conde,_Camino_de_los_Prodigios.jpg',
    180,
    -6.012958000000001,
    40.511301999068074
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CASITA I',
    'Villanueva del Conde',
    'www.casasenbatuecas.com',
    923437576,
    'http://www.wikidata.org/entity/Q1766569',
    'https://www.wikidata.org/wiki/Q1766569#/media/File:Villanueva_del_Conde,_Camino_de_los_Prodigios.jpg',
    180,
    -6.011968900000001,
    40.51036909906807
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL ESBEDAL',
    'Villarino de los Aires',
    NULL,
    677520502,
    'http://www.wikidata.org/entity/Q1640111',
    'https://www.wikidata.org/wiki/Q1640111#/media/File:Villarino_de_los_Aires_-_P1270268.jpg',
    764,
    -6.4647441,
    41.269279499064545
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'MARIA LUISA',
    'Ayllón',
    NULL,
    921555187,
    'http://www.wikidata.org/entity/Q1769718',
    'https://www.wikidata.org/wiki/Q1769718#/media/File:Ayllon_-_023_(31298066251).jpg',
    1154,
    -3.4236123999999997,
    41.384705199064065
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LOS ABUELOS',
    'Bernuy de Porreros',
    NULL,
    610419987,
    'http://www.wikidata.org/entity/Q1905435',
    'https://www.wikidata.org/wiki/Q1905435#/media/File:Bernuy_de_Porreros.jpg',
    903,
    -4.1277853,
    40.98230659906581
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA CASA DE LOS POLLOS',
    'Boceguillas',
    'www.lacasadelospollos.es',
    921121590,
    'http://www.wikidata.org/entity/Q1776849',
    'https://www.wikidata.org/wiki/Q1776849#/media/File:Iglesia_de_Boceguillas.jpg',
    682,
    -3.5921374,
    41.324868299064306
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'EL MIRADOR DE LA PINILLA',
    'Boceguillas',
    'www.elmiradordelapinilla.com',
    921121590,
    'http://www.wikidata.org/entity/Q1776849',
    'https://www.wikidata.org/wiki/Q1776849#/media/File:Iglesia_de_Boceguillas.jpg',
    682,
    -3.6421047,
    41.338185399064265
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'PANTANO DE BURGOMILLODO',
    'Carrascal del Río',
    'www.burgomillodo.com',
    921529420,
    'http://www.wikidata.org/entity/Q1776916',
    'https://www.wikidata.org/wiki/Q1776916#/media/File:Casa_consistorial_de_Carrascal_del_R�o.jpg',
    146,
    -3.9012232999999985,
    41.36938329906413
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'EL LABRIEGO - B',
    'Corral de Ayllón',
    NULL,
    610841158,
    'http://www.wikidata.org/entity/Q1919723',
    'https://www.wikidata.org/wiki/Q1919723#/media/File:CorralDeAyll�n20130117161325P1160943.jpg',
    79,
    -3.4596599999999995,
    41.39184379906403
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'EL LABRIEGO - A',
    'Corral de Ayllón',
    'www.casaruralellabriego.com',
    610841158,
    'http://www.wikidata.org/entity/Q1919723',
    'https://www.wikidata.org/wiki/Q1919723#/media/File:CorralDeAyll�n20130117161325P1160943.jpg',
    79,
    -3.4596599999999995,
    41.39184379906403
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA  ABUELA RUFA',
    'Fuenterrebollo',
    NULL,
    921521004,
    'http://www.wikidata.org/entity/Q1917520',
    'https://www.wikidata.org/wiki/Q1917520#/media/File:Iglesia_de_Fuenterrebollo.jpg',
    332,
    -3.9317017999999986,
    41.300113399064415
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'LA CASA DEL ABUELO ANDRES',
    'Juarros de Riomoros',
    NULL,
    921495577,
    'http://www.wikidata.org/entity/Q1905416',
    'https://www.wikidata.org/wiki/Q1905416#/media/File:Plaza_Mayor,_Juarros_de_Riomoros.jpg',
    49,
    -4.306299300000001,
    40.94621559906598
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'EL ARADO',
    'Marugán',
    'www.elarado.es',
    921196288,
    'http://www.wikidata.org/entity/Q1948746',
    'https://www.wikidata.org/wiki/Q1948746#/media/File:Portada_ermita.jpg',
    730,
    -4.383596900000001,
    40.8980303990662
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'REFUGIO LA HONDILLA',
    'Matabuena',
    'www.lahondilla.com',
    921504090,
    'http://www.wikidata.org/entity/Q2249259',
    'https://www.wikidata.org/wiki/Q2249259#/media/File:Ermita_San_Mart�n.jpg',
    175,
    -3.7578967000000008,
    41.095959699065304
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'PEÑALARA',
    'Real Sitio de San Ildefonso',
    'www.valsain.com',
    921470548,
    'http://www.wikidata.org/entity/Q1125500',
    'https://www.wikidata.org/wiki/Q1125500#/media/File:Catedral_de_La_Granja.pav.jpg',
    5188,
    -4.0124048,
    40.892673799066216
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA SILLA DEL REY',
    'Real Sitio de San Ildefonso',
    'www.valsain.com',
    921470548,
    'http://www.wikidata.org/entity/Q1125500',
    'https://www.wikidata.org/wiki/Q1125500#/media/File:Catedral_de_La_Granja.pav.jpg',
    5188,
    -4.0124048,
    40.892673799066216
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'SIETE PICOS',
    'Real Sitio de San Ildefonso',
    'www.valsain.com',
    921470548,
    'http://www.wikidata.org/entity/Q1125500',
    'https://www.wikidata.org/wiki/Q1125500#/media/File:Catedral_de_La_Granja.pav.jpg',
    5188,
    -4.0124048,
    40.892673799066216
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'MONTON DE TRIGO',
    'Real Sitio de San Ildefonso',
    'www.valsain.com',
    921470548,
    'http://www.wikidata.org/entity/Q1125500',
    'https://www.wikidata.org/wiki/Q1125500#/media/File:Catedral_de_La_Granja.pav.jpg',
    5188,
    -4.0124048,
    40.892673799066216
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA CASA DEL CURILLA',
    'Sacramenia',
    NULL,
    921527302,
    'http://www.wikidata.org/entity/Q1939060',
    'https://www.wikidata.org/wiki/Q1939060#/media/File:Sacramenia_Ayuntamiento_lou.jpg',
    358,
    -3.964483800000001,
    41.49379089906362
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'DEL SOL',
    'Segovia',
    'www.imarques.es/crural',
    696649706,
    'http://www.wikidata.org/entity/Q15684',
    'https://www.wikidata.org/wiki/Q15684#/media/File:Segovia_-_02_edited.jpg',
    50802,
    -4.1347222,
    40.96416669906589
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'SAN IGNACIO',
    'Sepúlveda',
    NULL,
    921543210,
    'http://www.wikidata.org/entity/Q1246441',
    'https://www.wikidata.org/wiki/Q1246441#/media/File:Sepulveda_02_by-dpc.jpg',
    1001,
    -3.736152000000001,
    41.30131699906441
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'SANTA ELENA',
    'Las Aldehuelas',
    'www.casasantaelena.com',
    635639326,
    'http://www.wikidata.org/entity/Q831729',
    'https://www.wikidata.org/wiki/Q831729#/media/File:Acceso_al_barrio_de_abajo_(Las_Aldehuelas).jpg',
    58,
    -2.3653794000000006,
    41.99526619906178
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CAÑÓN DEL RÍO LOBOS II',
    'Casarejos',
    'www.canonderiolobos.com',
    975376596,
    'http://www.wikidata.org/entity/Q829772',
    'https://www.wikidata.org/wiki/Q829772#/media/File:Casarejos,_Soria,_Espa�a,_2017-05-26,_DD_70.jpg',
    154,
    -2.9161494,
    41.78162019906253
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CANÓN DEL RÍO LOBOS I',
    'Casarejos',
    'www.canonderiolobos.com',
    975376596,
    'http://www.wikidata.org/entity/Q829772',
    'https://www.wikidata.org/wiki/Q829772#/media/File:Casarejos,_Soria,_Espa�a,_2017-05-26,_DD_70.jpg',
    154,
    -3.0333451000000005,
    41.79701649906247
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LA SABINA',
    'Castillejo de Robledo',
    'www.lasabinactr.com',
    975186080,
    'http://www.wikidata.org/entity/Q831405',
    'https://www.wikidata.org/wiki/Q831405#/media/File:VistaParcialDeCastillejoDeRobledo2.jpg',
    108,
    -3.4975936,
    41.559359299063374
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alojamiento Compartido',
    '2 Estrellas',
    'EL ROBLEDAL',
    'Castillejo de Robledo',
    NULL,
    975355005,
    'http://www.wikidata.org/entity/Q831405',
    'https://www.wikidata.org/wiki/Q831405#/media/File:VistaParcialDeCastillejoDeRobledo2.jpg',
    108,
    -3.4951770999999994,
    41.559084499063374
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LAS BARDAS',
    'Cubilla',
    'casalasbardas.negocio.site',
    662054572,
    'http://www.wikidata.org/entity/Q831396',
    'https://www.wikidata.org/wiki/Q831396#/media/File:Cubilla,_Soria,_Espa�a,_2017-05-26,_DD_76.jpg',
    25,
    -2.9389118,
    41.74980599906266
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA RURAL DE LUBIA II',
    'Cubo de la Solana',
    'www.lubiarural.com',
    676696839,
    'http://www.wikidata.org/entity/Q835846',
    'https://www.wikidata.org/wiki/Q835846#/media/File:CUBO_DE_LA_SOLANA-TIPICO_PUEBLO_AGRICOLA.jpg',
    166,
    -2.506977,
    41.64986699906302
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'CASA DE LA MARTINA',
    'Molinos de Duero',
    'www.casadelamartina.com',
    686557709,
    'http://www.wikidata.org/entity/Q985457',
    'https://www.wikidata.org/wiki/Q985457#/media/File:Ayuntamiento_de_Molinos_de_Duero.jpg',
    169,
    -2.7876743,
    41.88480379906217
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'DONDE ELVIRA',
    'Montejo de Tiermes',
    NULL,
    609475903,
    'http://www.wikidata.org/entity/Q837348',
    'https://www.wikidata.org/wiki/Q837348#/media/File:Montejo_de_Tiermes,_Soria,_Espa�a,_2017-05-26,_DD_21.jpg',
    141,
    -3.1252619999999993,
    41.356397999064185
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'YACIMIENTO DE TIERMES',
    'Montejo de Tiermes',
    'www.hoteltermes.com',
    975352055,
    'http://www.wikidata.org/entity/Q837348',
    'https://www.wikidata.org/wiki/Q837348#/media/File:Montejo_de_Tiermes,_Soria,_Espa�a,_2017-05-26,_DD_21.jpg',
    141,
    -3.1528550000000006,
    41.33678499906426
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA FUENTONA',
    'Muriel de la Fuente',
    'www.lafuentona.com',
    652945252,
    'http://www.wikidata.org/entity/Q833901',
    'https://www.wikidata.org/wiki/Q833901#/media/File:Muriel_de_la_Fuente,_Soria,_Espa�a,_2017-05-26,_DD_79.jpg',
    57,
    -2.8614708000000006,
    41.723688499062746
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL MIRADOR DE RELLO',
    'Rello',
    NULL,
    609692546,
    'http://www.wikidata.org/entity/Q1046930',
    'https://www.wikidata.org/wiki/Q1046930#/media/File:Rello.jpg',
    14,
    -2.7505051999999997,
    41.33342879906427
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA MURALLA',
    'Retortillo de Soria',
    NULL,
    975345053,
    'http://www.wikidata.org/entity/Q837197',
    'https://www.wikidata.org/wiki/Q837197#/media/File:Retortillo_de_Soria,_Soria,_Espa�a,_2017-05-26,_DD_16.jpg',
    152,
    -2.9808333,
    41.31194439906437
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'MERI',
    'Castromonte',
    NULL,
    983290569,
    'http://www.wikidata.org/entity/Q1907214',
    'https://www.wikidata.org/wiki/Q1907214#/media/File:Castromonte.jpg',
    314,
    -5.0376106,
    41.77336909906257
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'MARYOBELI',
    'Cogeces del Monte',
    'www. turismoruralmaryobeli.com',
    983699297,
    'http://www.wikidata.org/entity/Q1907192',
    'https://www.wikidata.org/wiki/Q1907192#/media/File:Iglesia_de_Cogeces_del_Monte.jpg',
    630,
    -4.318119499999999,
    41.50891829906357
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'LOS ABUELOS',
    'Montemayor de Pililla',
    'www.lacasaruraldelosabuelos.com',
    983694392,
    'http://www.wikidata.org/entity/Q1651701',
    'https://www.wikidata.org/wiki/Q1651701#/media/File:Fundaci�n_Joaqu�n_D�az_-_Iglesia_de_Santa_Mar�a_Magdalena_-_Montemayor_de_Pililla_(Valladolid).jpg',
    856,
    -4.458035,
    41.50933299906357
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'ANTIGUA CASA DELSINDICATO',
    'Santa Eufemia del Arroyo',
    NULL,
    983716107,
    'http://www.wikidata.org/entity/Q1919555',
    'https://www.wikidata.org/wiki/Q1919555#/media/File:Iglesia_Santa_Eufemia_del_Arroyo.jpg',
    69,
    -5.2650847,
    41.895295799062126
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'EVAN DE ABAJO II  LA TARAYUELA',
    'Siete Iglesias de Trabancos',
    'www.evandeabajo.es',
    983481014,
    'http://www.wikidata.org/entity/Q1907055',
    'https://www.wikidata.org/wiki/Q1907055#/media/File:Fundaci�n_Joaqu�n_D�az_-_Calle_-_Siete_Iglesias_de_Trabancos_(Valladolid).jpg',
    432,
    -5.1833770999999995,
    41.3521569990642
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA PICONA',
    'Fermoselle',
    'www.lapicona.net',
    980613401,
    'http://www.wikidata.org/entity/Q744993',
    'https://www.wikidata.org/wiki/Q744993#/media/File:Fermoselle_Vista_20080908_814_retouched.jpg',
    1128,
    -6.399119999999999,
    41.31525999906435
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'PEDRAZALES RURAL 3',
    'Galende',
    'www.pedrazalesrural.es',
    686725264,
    'http://www.wikidata.org/entity/Q1646379',
    'https://www.wikidata.org/wiki/Q1646379#/media/File:Galende-Zamora-Abril_2004.jpg',
    973,
    -6.6684969999999995,
    42.115143999061395
),

(
    'Alojam. Turismo Rural',
    'Posada',
    '2 Estrellas',
    'LA POSADA DE PEDRAZALES',
    'Galende',
    'www.laposadadepedrazales.com',
    980626840,
    'http://www.wikidata.org/entity/Q1646379',
    'https://www.wikidata.org/wiki/Q1646379#/media/File:Galende-Zamora-Abril_2004.jpg',
    973,
    -6.668844,
    42.11625599906139
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'PEDRAZALES RURAL 2',
    'Galende',
    'www.pedrazalesrural.es',
    686725264,
    'http://www.wikidata.org/entity/Q1646379',
    'https://www.wikidata.org/wiki/Q1646379#/media/File:Galende-Zamora-Abril_2004.jpg',
    973,
    -6.668351999999999,
    42.11508099906139
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'PEDRAZALES RURAL 1',
    'Galende',
    'www.pedrazalesrural.es',
    686725264,
    'http://www.wikidata.org/entity/Q1646379',
    'https://www.wikidata.org/wiki/Q1646379#/media/File:Galende-Zamora-Abril_2004.jpg',
    973,
    -6.668192000000001,
    42.11501999906139
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'ARZOBISPO MAYORAL',
    'Molacillos',
    'www.arzobispomayoral.com',
    980511907,
    'http://www.wikidata.org/entity/Q1765299',
    'https://www.wikidata.org/wiki/Q1765299#/media/File:Un_reba�o_-_Al_fondo_Molacillos_(7221129996)_(cropped).jpg',
    241,
    -5.6617456,
    41.581748299063285
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'TÍO BARTOLO',
    'Montamarta',
    NULL,
    659132710,
    'http://www.wikidata.org/entity/Q1765337',
    'https://www.wikidata.org/wiki/Q1765337#/media/File:Montamarta,_provincia_de_Zamora.jpg',
    558,
    -5.8041659999999995,
    41.64749999906304
),

(
    'Alojam. Turismo Rural',
    'Posada',
    '2 Estrellas',
    'DEHESA DE CONGOSTA',
    'Pereruela',
    'www.dehesacongosta.com',
    980569268,
    'http://www.wikidata.org/entity/Q1769052',
    'https://www.wikidata.org/wiki/Q1769052#/media/File:20110119_S_Rom�n_Infantes.jpg',
    521,
    -5.841953000000001,
    41.46711599906374
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'VILLA CELIA',
    'Puebla de Sanabria',
    'www.casaruralsanabria.es',
    669568518,
    'http://www.wikidata.org/entity/Q1646385',
    'https://www.wikidata.org/wiki/Q1646385#/media/File:Puebla_de_Sanabria06.jpg',
    1357,
    -6.6344959999999995,
    42.05317629906158
),

(
    'Alojam. Turismo Rural',
    'Hotel Rural',
    '2 Estrellas',
    'MAR ROJO',
    'Requejo',
    NULL,
    980622446,
    'http://www.wikidata.org/entity/Q515332',
    'https://www.wikidata.org/wiki/Q515332#/media/File:Requeixo_de_Seabra_desde_a_estaci�n_de_ferrocarril.jpg',
    130,
    -6.7427778,
    42.03083329906166
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA CASITA DE PAULINO',
    'San Justo',
    'www.lacasitadepaulino.es',
    658845510,
    'http://www.wikidata.org/entity/Q1922206',
    'https://www.wikidata.org/wiki/Q1922206#/media/File:San_Justo_concello_novo.jpg',
    197,
    -6.659548,
    42.1723239990612
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'LA PANERA',
    'San Vicente de la Cabeza',
    NULL,
    655798855,
    'http://www.wikidata.org/entity/Q1766453',
    'https://www.wikidata.org/wiki/Q1766453#/media/File:Balcones_corridos_-_Arquitectura_alistana.JPG',
    336,
    -6.2761111,
    41.82083329906239
),

(
    'Alojam. Turismo Rural',
    'Casa Rural',
    '2 Estrellas',
    'LA MOLINA 2',
    'San Vitero',
    NULL,
    651352160,
    'http://www.wikidata.org/entity/Q1766812',
    'https://www.wikidata.org/wiki/Q1766812#/media/File:Iglesiaelpoyo.JPG',
    449,
    -6.349371400000001,
    41.77733269906255
),

(
    'Alojam. Turismo Rural',
    'Casa Rural de Alquiler',
    '2 Estrellas',
    'EL CAPRICHO',
    'Villardeciervos',
    NULL,
    630023378,
    'http://www.wikidata.org/entity/Q1769086',
    'https://www.wikidata.org/wiki/Q1769086#/media/File:Villardeciervos_Casa_20100710_618.jpg',
    400,
    -6.285232499999999,
    41.94358119906196
);