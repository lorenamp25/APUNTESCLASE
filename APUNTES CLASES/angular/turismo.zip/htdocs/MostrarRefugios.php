<?php
    header('Access-Control-Allow-Origin: *'); 
    header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
    
    $conexion = mysqli_connect("localhost", "root", "", "turismo");

    if($conexion->connect_error){
        print "Fallo al conectar con la base de datos. ".$conexion->connect_error;
        echo 0;
    }else{
        $lat1=$_POST['lat1'];
        $lat2=$_POST['lat2'];
                
        $sql = "SELECT * FROM REFUGIOS where latitud>=$lat1 AND latitud<=$lat2";
        $resultados=mysqli_query($conexion,$sql) or die(mysqli_error($conexion));
        
        $datos=array();
        while ( $fila = mysqli_fetch_array($resultados, MYSQLI_ASSOC))
            {
            $datos[]=$fila;
            }
       
        echo(json_encode($datos));
        
        mysqli_close($conexion);
    
    }
  
?>

