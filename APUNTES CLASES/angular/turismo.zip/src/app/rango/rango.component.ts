import { Component,Output, EventEmitter  } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
    selector: 'app-rango',
    imports: [FormsModule],
    templateUrl: './rango.component.html',
    styleUrl: './rango.component.css'
})
export class RangoComponent {
  @Output() coordenadas = new EventEmitter<string>();
  lat1:number=30
  lat2:number=45
  rango!:any
  obtener() {
           this.rango={"lat1":this.lat1,"lat2":this.lat2}
           this.coordenadas.emit(this.rango);
 }
}
