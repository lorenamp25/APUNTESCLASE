import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, Router } from '@angular/router';
import { InicioComponent } from './inicio/inicio.component';

@Component({
    imports: [CommonModule, RouterOutlet, RouterLink, InicioComponent],
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  imagen: string = "assets/imagenes/f1.ico"
  intervalo!:any
  constructor(private ruta: Router) { }
  ngOnInit() {
    let num = 1
    this.intervalo=setInterval(() => {
      this.imagen = `assets/imagenes/f${num}.ico`
      if (num < 4) {
        num++
      } else {
        num = 1
      }
    }
      , 2000)
  }
  inicio() {
    
    this.ruta.navigate(["inicio"])
  }

}

