
import { Routes } from '@angular/router';
import { InicioComponent } from './inicio/inicio.component';
import { DormirComponent } from './dormir/dormir.component';
import { VisitarComponent } from './visitar/visitar.component';


export const routes: Routes = [

   {
    path: 'inicio',
    component: InicioComponent,
    children: [{
           path: 'dormir',
           component: DormirComponent
         },
        { path: 'visitar/:zona',
        component: VisitarComponent}]
  },
  
];


