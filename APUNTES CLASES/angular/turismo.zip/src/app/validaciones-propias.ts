import { AbstractControl, FormControl, ValidationErrors } from '@angular/forms';

export class ValidacionesPropias {
    static formatoId(control: AbstractControl): ValidationErrors| null {
        let id = control.value;
        let patron=/^[A-Z]{2}\-[0-9]{3}$/
        if (patron.test(id))
            return null;
        else
            return { formatoId: true }
    }
  
    static maximoPeso(control: AbstractControl): ValidationErrors| null {
        let peso = parseInt(control.value);
        
        if (peso<40)
            return null;
        else
            return { maximoPeso: true }
    }

}