import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';



@Component({
    selector: 'app-inicio',
    imports: [RouterOutlet, RouterLink, FormsModule],
    templateUrl: './inicio.component.html',
    styleUrl: './inicio.component.css'
})
export class InicioComponent {
  zona:string="Castilla y León"

}
