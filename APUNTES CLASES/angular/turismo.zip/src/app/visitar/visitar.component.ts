import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { ValidacionesPropias } from '../validaciones-propias';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
    selector: 'app-visitar',
    imports: [CommonModule, RouterOutlet, RouterLink, ReactiveFormsModule],
    templateUrl: './visitar.component.html',
    styleUrl: './visitar.component.css'
})
export class VisitarComponent {
  resultado = '';
  formularioVisita = new FormGroup({
    // id: new FormControl('', [Validators.required, ValidacionesPropias.formatoId]),
    nombre: new FormControl('', [Validators.required,Validators.pattern("[A-Z]*"), Validators.maxLength(50)]),
    mail: new FormControl('', [Validators.required, Validators.email]),
    telefono: new FormControl(),
    mascota: new FormControl('No'),

    mascotas: new FormGroup({
      animal: new FormControl('',[Validators.required]),
      peso: new FormControl('',[ValidacionesPropias.maximoPeso]),
      
    })
  });


  submit() {
    this.resultado = `
    
    ${this.formularioVisita.value.nombre}
   
    ${this.formularioVisita.value.mail}
    ${this.formularioVisita.value.telefono}
    ${this.formularioVisita.value.mascota}
  
    ${this.formularioVisita.value.mascotas?.animal}
    ${this.formularioVisita.value.mascotas?.peso}
    `

  }

  onReset() {
    this.formularioVisita.reset();
  }
}


