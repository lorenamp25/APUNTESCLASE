import { TestBed } from '@angular/core/testing';

import { DatosturismoService } from './datosturismo.service';

describe('DatosturismoService', () => {
  let service: DatosturismoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatosturismoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
