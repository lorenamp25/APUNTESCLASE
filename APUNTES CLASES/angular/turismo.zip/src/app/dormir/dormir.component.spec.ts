import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DormirComponent } from './dormir.component';

describe('DormirComponent', () => {
  let component: DormirComponent;
  let fixture: ComponentFixture<DormirComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DormirComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DormirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
