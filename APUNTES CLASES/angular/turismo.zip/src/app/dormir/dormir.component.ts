import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RangoComponent } from '../rango/rango.component';
import { DatosturismoService } from '../datosturismo.service';

@Component({
    selector: 'app-dormir',
    imports: [FormsModule, RangoComponent, CommonModule],
    templateUrl: './dormir.component.html',
    styleUrl: './dormir.component.css'
})
export class DormirComponent {

  casaSel!: string
  datos!: any
  casas!:any
  // casa={nombre:""}
  constructor(private ruta: Router, private datosturismo: DatosturismoService) { }
  ngOnChanges(): void {
    this.ruta.navigate(["rango"])
  }
  mostrar(rangoSel: any) {
    let dormir = {
      "casa": this.casaSel,
      rango: {
        "lat1": rangoSel.lat1,
        "lat2": rangoSel.lat2
      }
    }
    console.log(dormir)
    this.datosturismo.mostrarDormir(dormir).subscribe((datos:any) => this.casas = datos);
  }


}
