import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class DatosturismoService {

  data!: any
  url = 'http://localhost:80/dwec/turismo/'; // disponer url de su servidor que tiene las páginas PHP

  constructor(private http: HttpClient) { }

  mostrarDormir(datos:any) {
    let data=new FormData
    data.append("lat1",datos.rango.lat1)
    data.append("lat2",datos.rango.lat2)
    return this.http.post(`${this.url}mostrar${datos.casa}.php`,data)
  }
   
  mostrarVisista(datos: any) {
    return this.http.get(`${this.url}${datos.visita}.php?latitud=${datos.latitud}`);
  }

}
