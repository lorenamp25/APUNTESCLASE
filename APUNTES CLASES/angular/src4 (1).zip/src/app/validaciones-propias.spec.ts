import { ValidacionesPropias } from './validaciones-propias';

describe('ValidacionesPropias', () => {
  it('should create an instance', () => {
    expect(new ValidacionesPropias()).toBeTruthy();
  });
});
