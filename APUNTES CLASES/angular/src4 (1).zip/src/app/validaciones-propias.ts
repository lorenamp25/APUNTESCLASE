import { AbstractControl, ValidationErrors } from '@angular/forms';
export class ValidacionesPropias {
    static formatoEmail(control: AbstractControl): ValidationErrors | null {
        let email = control.value;
        let patron = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g
        if (patron.test(email))
            return null;
        else
            return { formatoEmail: true }
    }
}

