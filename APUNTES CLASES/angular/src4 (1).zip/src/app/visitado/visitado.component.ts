import { Component } from '@angular/core';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { ValidacionesPropias } from '../validaciones-propias';

@Component({
  selector: 'app-visitado',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './visitado.component.html',
  styleUrl: './visitado.component.css'
})
export class VisitadoComponent {
  generos = [
    "Acacia",
    "Acacia",
    "Adansonia",
    "Adansonia",
    "Adansonia",
    "Adansonia",
    "Arenga",
    "Arenga",
    "Attalea",
    "Attalea",
    "Brachychiton",
    "Brachychiton",
    "Caesalpinia",
    "Caesalpinia",
    "Casuarina",
    "Casuarina",
    "Cecropia",
    "Cecropia",
    "Ceiba",
    "Ceiba",
    "Ceiba",
    "Ceiba",
    "Ceiba",
    "Ceiba",
    "Chamaerops",
    "Chamaerops",
    "Coccothrinax",
    "Coccothrinax",
    "Coccothrinax",
    "Coccothrinax",
    "Dovyalis",
    "Dovyalis",
    "Dracaena",
    "Dracaena",
    "Dracaena",
    "Dracaena",
    "Dracaena",
    "Dracaena",
    "Eucalyptus",
    "Eucalyptus",
    "Euphorbia",
    "Euphorbia",
    "Euphorbia",
    "Euphorbia",
    "Euphorbia",
    "Euphorbia",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Ficus",
    "Harpephyllum",
    "Harpephyllum",
    "Harpullia",
    "Harpullia",
    "Hura",
    "Hura",
    "Jacaranda",
    "Jacaranda",
    "Kigelia",
    "Kigelia",
    "Lagunaria",
    "Lagunaria",
    "Parkia",
    "Parkia",
    "Phoenix",
    "Phoenix",
    "Phoenix",
    "Phoenix",
    "Phytolacca",
    "Phytolacca",
    "Pithecellobium",
    "Pithecellobium",
    "Podocarpus",
    "Podocarpus",
    "Rhizophora",
    "Rhizophora",
    "Spathodea",
    "Spathodea",
    "Spathodea",
    "Spathodea",
    "Swietenia",
    "Swietenia",
    "Swietenia",
    "Swietenia",
    "Tabebuia",
    "Tabebuia",
    "Tamarindus",
    "Tamarindus",
    "Tamarindus",
    "Tamarindus",
    "Tamarindus",
    "Tamarindus",
    "Terminalia",
    "Terminalia",
    "Terminalia",
    "Terminalia"
]

  familias =  [
    "Fabaceae",
    "Malvaceae",
    "Arecaceae",
    "Casuarinaceae",
    "Urticaceae",
    "Salicaceae",
    "Asparagaceae",
    "Myrtaceae",
    "Euphorbiaceae",
    "Moraceae",
    "Anacardiaceae",
    "Sapindaceae",
    "Bignoniaceae",
    "Phytolaccaceae",
    "Podocarpaceae",
    "Rhizophoraceae",
    "Meliaceae",
    "Combretaceae"
  ]

  familia!: string;
  valido!: boolean
  nombre!: string
  mail!: string
  tipo!: string
  
  formularioVisita = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.maxLength(50)]),
    mail: new FormControl('', [Validators.required, ValidacionesPropias.formatoEmail]),
    tipo: new FormControl('', [Validators.required]),
    opciones: new FormGroup({
      opcion: new FormControl(''),
    })
  });

  tipoElegido(tipo: any) {
    return tipo.value
  }

  submit() {
    this.valido = true
    this.nombre = `${this.formularioVisita.value.nombre}`
    this.mail = `${this.formularioVisita.value.mail}`
    this.tipo = `${this.formularioVisita.value.tipo}: ${this.formularioVisita.value.opciones?.opcion}`
  }
  onReset() {
    this.formularioVisita.reset();
  }


}



