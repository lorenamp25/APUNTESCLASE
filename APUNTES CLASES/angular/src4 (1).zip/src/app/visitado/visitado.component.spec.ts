import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisitadoComponent } from './visitado.component';

describe('VisitadoComponent', () => {
  let component: VisitadoComponent;
  let fixture: ComponentFixture<VisitadoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VisitadoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VisitadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
