<?php 
  header('Access-Control-Allow-Origin: *'); 
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
  
  require("conexion.php");
  $con=retornarConexion();

  $sql="SELECT nombre,geocodigo,fecha FROM agenda";

  $resultados=mysqli_query($con,$sql) or die(mysqli_error($con));
while ( $fila = mysqli_fetch_array($resultados, MYSQLI_ASSOC))
    {
    $datos[]=$fila;
    }
echo json_encode($datos);
mysqli_close($con);
?>

