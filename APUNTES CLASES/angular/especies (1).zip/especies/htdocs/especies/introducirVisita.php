<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

require("conexion.php");
$con = retornarConexion();

$nombre = $_POST["nombre"];
$geocodigo = $_POST["geocodigo"];
$fecha = $_POST["fecha"];
$sql = "INSERT INTO agenda(nombre,geocodigo,fecha) VALUES ('$nombre','$geocodigo','$fecha')";
mysqli_query($con, $sql);


class Result
{
}

$response = new Result();
$response->resultado = 'OK';
$response->mensaje = 'datos grabados';

header('Content-Type: application/json');
echo json_encode($response);

mysqli_close($con);
?>
