<?php
header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
function retornarConexion() {
  $con=mysqli_connect("localhost","root","","especies");
  return $con;
}
?>