import { Component } from '@angular/core';

@Component({
  selector: 'app-vacio',
  imports: [],
  templateUrl: './vacio.component.html',
  styleUrl: './vacio.component.css'
})
export class VacioComponent {

}
