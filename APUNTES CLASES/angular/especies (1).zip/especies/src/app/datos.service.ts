import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class DatosService {
  url: string = "http://localhost:80/dwec/especies/"

  constructor(private http: HttpClient) { }

  
  obtenerGenero(familia: string) {

    return this.http.get(`${this.url}obtenerGeneros.php?familia=${familia}`)
  }
  obtenerEspecies(genero: string) {
    let dato=new FormData()
    dato.append("genero",genero)

    return this.http.post(`${this.url}obtenerEspecies.php`,dato)
  }


}

