import { Component } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-mapa',
  standalone: true,
  imports: [],
  templateUrl: './mapa.component.html',
  styleUrl: './mapa.component.css'
})
export class MapaComponent{
  //@Input() src!: any
  src!: string

  constructor(private rutaActiva: ActivatedRoute) {
    this.rutaActiva.paramMap.subscribe((parametros: ParamMap) => {
      this.src = parametros.get("src")!;
    })

  }
  
}

