import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { RouterOutlet, RouterLink, Router } from '@angular/router';
import { DatosService } from '../datos.service';
import { MapaComponent } from './mapa/mapa.component';




@Component({
  selector: 'app-tabla',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterOutlet, MapaComponent],
  templateUrl: './tabla.component.html',
  styleUrl: './tabla.component.css'
})
export class TablaComponent implements OnInit {
  genero!: string;
  especies: any;
  especie!: string
  src!: string

  constructor(private activatedRoute: ActivatedRoute, private datosServicio: DatosService, private ruta: Router) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe((parametros: ParamMap) => {
      this.genero = (parametros.get("genero")!);
      this.datosServicio.obtenerEspecies(this.genero).subscribe((datos: any) => { this.especies = datos })
    })
  }
  elegirEspecie(especie: any) {
    let longitud=parseFloat(especie.grad_x)
    let latitud=parseFloat(especie.grad_y)
    this.src =`https://maps.google.com/?ll=${latitud},${longitud}&amp;z=20&amp;t=k&amp;output=embed`
     
  }
}




