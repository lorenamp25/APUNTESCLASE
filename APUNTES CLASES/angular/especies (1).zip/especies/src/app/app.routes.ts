import { Routes } from '@angular/router';
import { TablaComponent } from './tabla/tabla.component';
import { VisitadoComponent } from './visitado/visitado.component';
import { ErrorComponent } from './error/error.component';
import { VacioComponent } from './vacio/vacio.component';

export const routes: Routes = [
    {
        path: '',
        component: VacioComponent,
    },
    {
        path: 'tabla/:genero',
        component: TablaComponent,
    },
    {
        path: 'visitado',
        component: VisitadoComponent,
    },
    {
        path: 'error',
        component: ErrorComponent,
    },
    {
        path: '**',
        redirectTo: 'error'
    }];

