import { Component, Input, OnChanges,Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DatosService } from '../../datos.service';

@Component({
  selector: 'app-genero',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './genero.component.html',
  styleUrl: './genero.component.css'
})
export class GeneroComponent implements OnChanges{
  @Input() familia!:string
  @Output() cambiarGenero = new EventEmitter<string>();
  generos!: any
  genero!: string
  constructor(private datosServicio: DatosService) {}

  ngOnChanges(){
    console.log(this.familia)
    this.datosServicio.obtenerGenero(this.familia).subscribe((datos: any) => this.generos = datos)
  }
  enviarGenero(genero:string){
    this.cambiarGenero.emit(genero)
  }

 }
