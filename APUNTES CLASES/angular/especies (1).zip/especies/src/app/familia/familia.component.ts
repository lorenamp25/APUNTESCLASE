import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeneroComponent } from './genero/genero.component';
import * as especiesJson from '../../assets/familias.json'

@Component({
  selector: 'app-familia',
  standalone: true,
  imports: [CommonModule, FormsModule, GeneroComponent],
  templateUrl: './familia.component.html',
  styleUrls: ['./familia.component.css']
})

export class FamiliaComponent {
  familias = especiesJson.familias
  familia!: string;
  @Output() cambiarGenero = new EventEmitter<string>();
  
  enviarGenero(genero:string){
    this.cambiarGenero.emit(genero)
  }

 

}