import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet,RouterLink } from '@angular/router';
import { FamiliaComponent } from './familia/familia.component';
import { VacioComponent } from './vacio/vacio.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, FamiliaComponent, VacioComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  genero!:string
  cambiarGenero(genero:string){
     this.genero=genero
  }
   
}
