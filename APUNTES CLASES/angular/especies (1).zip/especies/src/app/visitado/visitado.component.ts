import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { ValidacionesPropias } from '../validaciones-propias';
import { DatosService } from '../datos.service';
import * as especiesJson from '../../assets/familias.json'


@Component({
  selector: 'app-visitado',
  standalone: true,
  imports: [CommonModule, RouterOutlet, ReactiveFormsModule],
  templateUrl: './visitado.component.html',
  styleUrl: './visitado.component.css'
})
export class VisitadoComponent {
  generos!: any
  familias = especiesJson.familias
  familia!: string;
  valido!: boolean
  nombre!: string
  mail!: string
  tipo!: string
  constructor(private datosServicio: DatosService) {
    this.datosServicio.obtenerGenero("").subscribe((datos: any) => this.generos = datos)
  }
  formularoVisita = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.maxLength(50)]),
    mail: new FormControl('', [Validators.required, ValidacionesPropias.formatoEmail]),
    tipo: new FormControl('', [Validators.required]),
    opciones: new FormGroup({
      opcion: new FormControl(''),
    })
  });

  tipoElegido(tipo: any) {
    return tipo.value
  }

  submit() {
    this.valido = true
    this.nombre = `${this.formularoVisita.value.nombre}`
    this.mail = `${this.formularoVisita.value.mail}`
    this.tipo = `${this.formularoVisita.value.tipo}: ${this.formularoVisita.value.opciones?.opcion}`
  }
  onReset() {
    this.formularoVisita.reset();
  }


}



