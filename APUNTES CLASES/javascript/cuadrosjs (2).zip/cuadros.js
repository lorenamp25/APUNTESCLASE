
window.onload = function () {

	obtenerAutores();

}

function obtenerAutores() {  //creamos el select con datos del JSON
	let peticionJSON = new XMLHttpRequest();

	if (peticionJSON) {

		/*
		peticionJSON.onreadystatechange = function () {
			if (this.readyState == 4 && this.status == 200) {
		*/

		peticionJSON.addEventListener('load', function () {
			if (peticionJSON.status === 200) {
				let cuadros = JSON.parse(this.responseText);
				let selectCuadros = document.createElement('select');
				selectCuadros.setAttribute("id", "cuadro")
				document.querySelector("#principal").append(selectCuadros);
				selectCuadros.addEventListener("change", mostrarCuadro);

				cuadros.cuadros.forEach(function (cuadro, i) {

					let opcion = document.createElement('option');
					opcion.id = "cuadro" + i  //añado identificador y valor para seleccionarlo y utilizarlo mas adelante
					opcion.value = i

					// Al final de este fichero escribo codigo comentado de como haceresto mismo con fetch

					//Vamos a asignar atributos nuevos al documento y asociarles a cada elemento opcion del select para guardar esos datos
					/*
					let atr1 = document.createAttribute("titulo");
					let atr2 = document.createAttribute("autor");
					let atr3 = document.createAttribute("siglo");

					atr1.value = cuadro.titulo
					atr2.value = cuadro.autor
					atr3.value = cuadro.siglo

					opcion.setAttributeNode(atr1);
					opcion.setAttributeNode(atr2);
					opcion.setAttributeNode(atr3);
					*/

                    /* esta opcion no lo admite
					opcion.titulo=cuadro.titulo
                    opcion.autor=cuadro.titulo
                    opcion.siglo=cuadro.siglo
                    */

					opcion.setAttribute("titulo",cuadro.titulo);
					opcion.setAttribute("autor",cuadro.autor);
					opcion.setAttribute("siglo",cuadro.siglo);
					

					opcion.textContent = cuadro.titulo
					selectCuadros.append(opcion);

				})

			} else {
				muestraError();
			}
		})

		peticionJSON.open('POST', 'cuadros.json', true);
		peticionJSON.send();

		peticionJSON.addEventListener('error', muestraError);
		peticionJSON.addEventListener('abort', muestraError);
		peticionJSON.addEventListener('timeout', muestraError);


	}
}

function mostrarCuadro(e) {  // e es el objeto evento el cual aprovecho su valor en target para saber que opcion ha sido seleccionada

	let num = e.target.value  //con esta variable busco el fichero mas abajo )p.e. 1.jpg)
	let id = "cuadro" + num  //Este id es el del cuadro que se corresponde
	// Creo 2 variables con los datos guardados anteriormente en cada opcion del select para enviarlos a los php y que estos realicen las busquedas
	let pintura = document.querySelector("#" + id).getAttribute("titulo")
	let siglo = document.querySelector("#" + id).getAttribute("siglo")

	if (!document.querySelector("#tapiz") == 0) document.querySelector("#tapiz").remove()
	let div = document.createElement("div")
	div.id = 'tapiz'
	document.querySelector("#principal").append(div)

	const data = new URLSearchParams("titulo=" + pintura); // data contine lo que envio con send() al php (p.e.: send("titulo="La Noche Estrellada")

	/* tambien puedo asignar el valor que envio en send de esta otra forma:
	const data = new FormData();
	data.append('titulo', pintura);

	o tambien puedo simplemente poner .send("titulo="+pintura)
	*/

	let peticionConsulta = new XMLHttpRequest();
	if (peticionConsulta) {
		/*
		peticionConsulta.onreadystatechange = function () {
			if (peticionConsulta.readyState == 4 && peticionConsulta.status == 200) {
		*/

		peticionConsulta.addEventListener('load', function () {
			if (peticionConsulta.status === 200) {

				let cuadro = JSON.parse(peticionConsulta.responseText)
				let parrafo = document.createElement("p")
				let fecha=(cuadro[0].Siglo!=null)?cuadro[0].Siglo:" Sin fecha"

				parrafo.textContent = "Titulo: " + cuadro[0].Titulo + " Autor: " + cuadro[0].Autor + " Pais: " + cuadro[0].Pais + " Siglo: " + 	fecha
				div.append(parrafo)

				let imagen = document.createElement("img")

				imagen.srcset = "./pinturas/" + (parseInt(num) + 1) + ".jpg"
				imagen.setAttribute("width", "250px");
				imagen.setAttribute("border", "6px solid lightgrey");

				div.append(imagen);

				let coordenadas = document.createElement("span")
				coordenadas.id = 'coordenadas';
				let posicion = document.createTextNode("X:  Y: ");
				posicion.id = "posicion"

				coordenadas.append(posicion)
				coordenadas.append(document.createElement("br"))

				imagen.before(coordenadas) //inserta las coordenadas delante (por encima) de la imagen

				imagen.addEventListener("mousemove", function (e) { //si muevo el raton dentro de la imagen se muestran las coordenadas

					coordenadas.style.display = 'inline'
					posicion.nodeValue = "X: " + e.screenX + " Y: " + e.screenY;

				});

				imagen.addEventListener("mouseout", function (e) {  // si el raton sale de la imagen se ocultan las coordenadas
					coordenadas.style.display = 'none'
				});

				//creo el boton para actualizar el siglo
				div.append(document.createElement("br"))
				let boton = document.createElement("button")
				let textoBoton = document.createTextNode("Actualizar siglo a " + cuadro[0].Titulo);
				boton.append(textoBoton)

				div.append(boton);

				boton.addEventListener("click", function () {

					const dataActualizar = new URLSearchParams("titulo=" + pintura + "&siglo=" + siglo)

					let peticionActualizar = new XMLHttpRequest();
					/*
					if (peticionActualizar) {
						peticionActualizar.onreadystatechange = function () {
							if (this.readyState == 4 && this.status == 200) {
					*/
					peticionActualizar.addEventListener('load', function () {
						if (peticionActualizar.status === 200) {
							alert("Insertado")
						}

						else {
							muestraError();
						}
					})

					peticionActualizar.open('POST', 'actualizar.php');
					peticionActualizar.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
					//peticionActualizar.setRequestHeader('Content-type', 'application/json');  
                    //peticionActualizar.send(JSON.stringify("titulo=" + pintura + "siglo=" + siglo))
					//peticionActualizar.send(dataActualizar);
					peticionActualizar.send("titulo=" + pintura + "&siglo=" + siglo)

					peticionActualizar.addEventListener('error', muestraError);
					peticionActualizar.addEventListener('abort', muestraError);
					peticionActualizar.addEventListener('timeout', muestraError);
				})

			} else {
				muestraError();
			}
		})

		peticionConsulta.open('POST', 'cuadros.php', true);
		peticionConsulta.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
		//peticionConsulta.setRequestHeader('Content-type', 'application/json'); 

		//peticionConsulta.send(data);
		 
        //peticionConsulta.send(JSON.stringify("titulo=" + pintura))
		peticionConsulta.send("titulo=" + pintura)

		peticionConsulta.addEventListener('error', muestraError);
		peticionConsulta.addEventListener('abort', muestraError);
		peticionConsulta.addEventListener('timeout', muestraError);

	}
}

/*	Otra manera, mas actualizada, de conectar con el fichero del servidor utlizando fecth, ademas utilizo FormData 
						const data = new FormData();
						data.append('titulo', opcion.getAttribute('titulo'));
						data.append('autor', opcion.getAttribute('autor'));
						data.append('siglo', opcion.getAttribute('siglo'));
						fetch('insertar.php', {
							method: 'POST',
							body: data
						})
						.then(function(response) {
							if(response.ok) {
								return response.text()
							} else {
								throw "Error en la llamada Ajax";
							}
						})
						.then(function(texto) {
							console.log(texto);
						})
						.catch(function(err) {
							console.log(err);
						});
*/

function muestraError() {
	if (this.status) {
		console.log("Error " + this.status + " (" + this.statusText + ") en la petición");
	} else {
		console.log("Ocurrió un error o se abortó la conexión");
	}
}