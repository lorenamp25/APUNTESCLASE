window.onload = inicio
function inicio() {
  function Disciplina(tipo, tipoRecord, nombre) {
    this.tipo = tipo
    this.tipoRecord = tipoRecord
    this.nombre = nombre
    //iniciamos record a un valor muy alto (99999) o a 0 dependiendo del tipo de record
    if (tipoRecord == "menor") {
      this.record = {
        masculino: 99999,
        femenino: 99999}
    } else {
      this.record = {
        masculino: 0,
        femenino: 0}
    }
    //método para cambiar el record de la disciplina según la marca enviada y el genero
    Disciplina.prototype.cambiarRecord = function (marca, genero) {
      //dependiendo del tipo de la disciplina el record se guarda si es menor o mayor del ya almacenado
      if (this.tipoRecord == "menor") {
        //dependiendo del genero enviado (del atleta) se modifica si la marca es menor
        if (genero == "Masculino") {
          if (marca < this.record.masculino) this.record.masculino = marca
        } else {
          if (marca < this.record.femenino) this.record.femenino = marca
        }
      } else {
        //dependiendo del genero enviado (del atleta) se modifica si la marca es mayor
        if (genero == "Masculino") {
          if (marca > this.record.masculino) this.record.masculino = marca
        } else {
          if (marca > this.record.femenino) this.record.femenino = marca
        }
      }
    }
  }
  //en listaDisciplinas guardamos los datos oibtenidos del xml
  let listaDisciplinas = []
  let xhr = new XMLHttpRequest()
  xhr.open("GET", "disciplinas.xml")
  xhr.addEventListener('load', function () {
    if (xhr.status === 200) {
      let textoXML = this.responseText;
      let xml = new DOMParser();
      let docXML = xml.parseFromString(textoXML, "text/xml");
      let tipos = docXML.querySelectorAll("tipo")
      //creamos array de objetos de disciplinas
      tipos.forEach((tipo) => {
        let tipoRecord = tipo.querySelector("tipoRecord")
        let disciplinas = tipo.querySelectorAll("nombre")
        disciplinas.forEach(disciplina => listaDisciplinas.push(new Disciplina(tipo.firstChild.textContent.trim(), tipoRecord.textContent.trim(), disciplina.textContent.trim())))
      })
      //creamos select tipo disciplina
      let selectDisciplina = document.createElement('select');
      selectDisciplina.id = "selectDisciplina"
      document.getElementById("divDisciplina").prepend(selectDisciplina);
      //por cada tipo del xml creamos una opcion
      tipos.forEach((tipo, i) => {
        selectDisciplina[i] = new Option(tipo.firstChild.textContent.trim())
      })
      //si selecciona un valor del select crea array de deportistas
      selectDisciplina.addEventListener("change", () => deportistas(listaDisciplinas))
    }
    //añadimos cabeceras del body y de los div estáticos del html
    let titulo = document.createElement("h1")
    titulo.append("DEPORTISTA")
    document.body.prepend(titulo)
    let tituloGenero = document.createElement("h2")
    tituloGenero.append("Genero")
    document.getElementById("formgenero").prepend(tituloGenero)
    let tituloDisciplina = document.createElement("h2")
    tituloDisciplina.append("Tipo disciplina")
    document.getElementById("divDisciplina").prepend(tituloDisciplina)
    //si cambia el genero creamos deportistas
    document.getElementById("formgenero").addEventListener("click", () => deportistas(listaDisciplinas))
    document.getElementById("imagen").addEventListener("click", (e) => cambiarGenero(e, listaDisciplinas))
  })
  xhr.send()
}
//cambiar de genero a traves de la imagen, cambiamos el valor seleccionado y creamos deportistas
function cambiarGenero(e, listaDisciplinas) {
  let x = e.offsetX
  //pulsamos la mitad de la imagen (eje x) cambiamos valor del select del genero
  if (x < +(document.getElementById("imagen").width) / 2) {
    document.getElementById("masculino").checked = true
  } else {
    document.getElementById("femenino").checked = true
  }
  deportistas(listaDisciplinas)
}

function deportistas(listaDisciplinas) {
  class Deportista {
    constructor(nombre, genero) {
      this.nombre = nombre;
      this.genero = genero
    }
  }
  class Atleta extends Deportista {
    constructor(nombre, genero) {
      super(nombre, genero);
      //la propiedad disciplinas se rellena con cada disciplina con método incluirdisciplina
      this.disciplinas = []
    }
    incluirDisciplina(tipo, nombre, marca, fecha) {
      let disciplina = {
        tipo: tipo,
        nombre: nombre,
        marca: marca,
        fechaMarca: new Date(`${fecha.slice(6, 10)}/${fecha.slice(3, 5)}/${fecha.slice(0, 2)}`)
      }
      this.disciplinas.push(disciplina);
      //comprobamos si la marca de este atleta en esta disciplina es mejor llamando al metodo cambiarRecord de la clase Disciplina
      listaDisciplinas.find(disciplina => disciplina.nombre == nombre).cambiarRecord(marca, this.genero)
    }
    // get para ver las disciplinas guardadas de un atleta
    get verdisciplinas() {
      //generaremos un texto con el nombre de las disciplinas, su marca y años y meses que han pasado desde que lo realizó
      let texto = `\n\nMarcas\n`
      this.disciplinas.forEach(disciplina => {
        let tiempo = new Date(Date.now() - disciplina.fechaMarca)
        //encuentra cada disciplina del atleta en el array de disciplinas (listaDisciplinas) 
        let disciplinaSel = listaDisciplinas.find((elemento) => elemento.nombre == disciplina.nombre)
        //en record guarda el record de la disciplina dependiendo del genero del atleta 
        let record = (this.genero == "Masculino") ? disciplinaSel.record.masculino : disciplinaSel.record.femenino
        //Si el atleta posee el record añade RECORD MUNDIAL antes del nombre de la disciplina
        if (record == disciplina.marca) {
          texto = texto + (`\n- RECORD MUNDIAL: ${disciplina.nombre}: ${disciplina.marca} Hace: ${tiempo.getFullYear() - new Date(0).getFullYear()} años ${tiempo.getMonth()} meses\n`)
        } else {
          texto = texto + (`\n- ${disciplina.nombre}: ${disciplina.marca} Hace: ${tiempo.getFullYear() - new Date(0).getFullYear()} años ${tiempo.getMonth()} meses\n`)
        }
      })
      //devuelve el texto con todas las disciplinas, marcas y años y meses que hace desde que lo realizó
      return texto
    }
  }
  //recuperamos la disciplina seleccionada
  let tipodisciplina = document.getElementById("selectDisciplina").value
  let disciplinas = []
  listaDisciplinas.forEach(disciplina => {
    //solamente añadimos las disciplinas del tipo seleccionado
    if (disciplina.tipo == tipodisciplina)
      disciplinas.push(disciplina.nombre)
  });
  let atletas = []
  document.getElementById("diviframe").innerHTML = ""
  // obtenemos el genero seleccionado
  let genero = document.querySelector('input[name="genero"]:checked').value
  fetch("deportistas.json")
    .then(response => response.json())
    .then(datos => {
      datos.deportistas.forEach(deportista => {
        //si el atleta ya ha sido añadido al array atletas recojemos su indice (-1 si no esta))
        let indice = atletas.findIndex(atleta => atleta.nombre == deportista.Nombre)
        if (disciplinas.includes(deportista.Disciplina) && deportista.Genero == genero) {
          //comprobamos si ese atleta ya esta añadido al array atletas
          if (indice >= 0) {
            //si ese atleta ya está, le añadimos otra disciplina
            atletas[indice].incluirDisciplina(tipodisciplina, deportista.Disciplina, deportista.Marca, deportista.Fecha)
          } else {
            // si no esta añadido ala array atletas, lo añadimos e incluimos esa disciplina
            let atleta = new Atleta(deportista.Nombre, deportista.Genero)
            atleta.incluirDisciplina(tipodisciplina, deportista.Disciplina, deportista.Marca, deportista.Fecha)
            atletas.push(atleta)
          }
        }
      })
      //una vez creado el array atletas creamos un array en un iframe
      gestion(atletas)
    })
}
function gestion(atletas) {
  let divIframe = document.getElementById("diviframe")
  divIframe.innerHTML = ""
  divIframe.hidden = false
  //añadimos la cabecera
  let tituloAtletas = document.createElement("h2")
  tituloAtletas.append("Atletas")
  divIframe.prepend(tituloAtletas)
  //creamos una iframe en blanco
  let iframe = document.createElement("iframe")
  divIframe.append(iframe)
  iframe.src = "about:blank"
  iframe.id = "iframe"
  iframe.setAttribute("style", "width:400px; height: 400px")
  //cuando se cargue el document del iframe creamos la tabla
  iframe.onload = () => {
    let tabla = iframe.contentDocument.createElement("table")
    tabla.id = "tabla"
    iframe.contentDocument.body.append(tabla)
    //eliminamos los atletas repetidos, se creo uno por cada disciplina y lo guardamos en otro array
    let listaAtletas = Array.from(new Set(atletas));
    listaAtletas.forEach(atleta => {
      //por cada atleta creamos una fila en la tabla con el nombre
      let fila = tabla.insertRow()
      let td1 = fila.insertCell()
      td1.append(atleta.nombre)
      fila.append(td1)
    })
    //si pulsa sobre un nombre abre una dialogo para mostrar las disciplinas
    tabla.addEventListener("click", (e) => mostrardisciplinas(e, listaAtletas))
  }
}
function mostrardisciplinas(e, listaAtletas) {
  let dialogo = document.getElementById("dialogo")
  dialogo.innerHTML = ""
  let atletaSel = e.target.textContent
  //encuentra en el array listaAtletas el atleta que coincide con el nombre
  let atleta = listaAtletas.find((atleta) => atleta.nombre == atletaSel)
  //añade el nombre en un elemento pre y las disciplinas a traves del get del objeto
  let pre = document.createElement("pre")
  pre.append(atleta.nombre)
  pre.append(atleta.verdisciplinas)
  dialogo.append(pre)
  //muestra el dialogo
  dialogo.showModal()
  // a los 3 segundos lo cierra y abre otra ventana
  setTimeout(() => {
    pre.innerHTML = ""
    dialogo.close()
    //guardamos en localStorage el objeto atleta 
    localStorage.setItem("atleta", JSON.stringify(atleta))
    //ponemos nombre a la ventana para abrir siempre la misma
    window.open("insertarDeportista.html", "insertar", "width=300px,height=400px");
  }, 3000)
}

