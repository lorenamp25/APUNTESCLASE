﻿DROP DATABASE IF EXISTS Atletas;

CREATE DATABASE Atletas CHARACTER SET utf8mb4;;
USE Atletas;

CREATE TABLE consultas (
  atleta VARCHAR(20) ,
  codigo VARCHAR(6) NOT NULL,
  fecha datetime NOT NULL,
  PRIMARY KEY (atleta)
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
COMMIT;
