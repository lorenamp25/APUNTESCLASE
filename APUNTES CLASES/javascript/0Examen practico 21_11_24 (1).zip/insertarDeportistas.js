window.onload = inicio
function inicio() {
    document.getElementById("codigo").addEventListener("blur", validar)
    document.getElementById("codigo").focus()
}
function validar(e) {
    let regExp = /^[A-D]\d{4,6}(-\d)?$/;
    if (regExp.test(e.target.value)) {
        insertar(e.target.value)
    }
}
function insertar(codigo) {
    document.getElementById("codigo").removeEventListener("blur", validar)
    let atleta = JSON.parse(localStorage.getItem("atleta"))
    let datos = new FormData()
    
    let fecha = new Date()
    let fechaS = fecha.getFullYear() + "-" + fecha.getMonth() + "-" + fecha.getDate() + " " + fecha.getHours() + ":" + fecha.getMinutes() + ":" + fecha.getSeconds()
    datos.append("atleta", atleta.nombre)
    datos.append("fecha", fechaS)
    datos.append("codigo", codigo)
    fetch("InsertarConsultas.php", { method: 'POST', body: datos })
        .then(response => response.text())
        .then(respuesta => {
            let mensaje = JSON.parse(respuesta).mensaje
            document.getElementById("cabecera").append(mensaje)
            setTimeout(() => { window.close() }, 4000)
        })
}