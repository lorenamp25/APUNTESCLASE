window.onload = inicio

function inicio() {
    //crear una funcion constructora de un objeto
    //propiedades: nombre en mayuscula y nota con 2 decimales
    //incluir una propiedad asociada a un metodo que nos devulva
    //el mensaje La nota de "nombre" es "nota"
    function CrearAlumno(nombre, curso, nota) {
        this.nombre = nombre.toUpperCase();
        this.curso = curso;
        this.nota = parseFloat(nota).toFixed(2);
        this.mensaje = () => `La nota de ${this.nombre} es ${this.nota}`
    };
    //rellenar un array con objetos pidiendo los datos de cada uno con prompt, cuando sea vacio no pide mas
    let arrayLista = []
    for (; ;) {
        let alumno = prompt("Introduce nombre, curso y nota, separado por -", "Alberto-1º-6")
        if (alumno) {
            let propiedades = alumno.split("-")
            arrayLista.push(new CrearAlumno(propiedades[0], propiedades[1], propiedades[2]))
        } else { break }
    }
    // ordena la lista por nota
    arrayLista.sort((a, b) => a.nota - b.nota);
    // funcion para crear tabla
    crearTabla(arrayLista)
    // crear un select que nos pida un curso
    // y con el seleccionado mostrar una lista 
    // con el mensaje de cada alumno de ese curso
    let seleccion = document.createElement("select")
    seleccion.id = "seleccion"
    document.getElementById("mitabla").after(seleccion)
    seleccion[0] = new Option("- Elige una opción -")
    let arrayCursos = arrayLista.map(item => item.curso)
    let arrayCurso = Array.from(new Set(arrayCursos))
    arrayCurso.forEach((curso, i) => seleccion[i + 1] = new Option(curso, curso))
    seleccion.addEventListener("change", () => mostrarNotas(arrayLista))
}

function crearTabla(arrayLista) {
    let tbody = document.getElementById("tbody")
    arrayLista.forEach(alumno => {
        let fila = document.createElement("tr")
        for (let key in alumno) {
            let celda = document.createElement("td")
            celda.append(alumno[key])
            fila.append(celda)
        }
        tbody.append(fila)
    })




}

function mostrarNotas(arrayLista) {
    let curso = document.getElementById("seleccion").value
    let lista = document.createElement("ul")
    document.getElementById("mitabla").before(lista)
    let arrayNotas = arrayLista.filter(elemento => elemento.curso === curso);
    arrayNotas.forEach(alumno => {
        let guion = document.createElement("li")
        guion.append(alumno.mensaje())
        lista.append(guion)
    })
    /* Lo mismo de arriba pero sin utilizar el filter, el filtro es manual
      arrayLista.forEach(alumno => {
        if (alumno.curso === curso) {
          let guion = document.createElement("li")
          guion.append(alumno.mensaje())
          lista.append(guion)
        }
      })
      */
    let sumaLista = arrayLista.reduce((suma, elemento) => suma + +elemento.nota, 0);
    let section = document.createElement("section")
    section.innerHTML = `<strong>La nota media es: ${sumaLista / arrayLista.length}</strong>`
    document.getElementById("mitabla").prepend(section)


}