<?php

    
    $cuenca = json_decode($_POST["cuenca"]);
    $servidor = "localhost";
    $basedatos = "rios";
    $usuario = "root";
    $password = "";
    $conexion=mysqli_connect($servidor, $usuario, $password, $basedatos) or die(mysqli_error($conexion));
    mysqli_query($conexion,"SET NAMES 'utf8'");
    mysqli_select_db($conexion,$basedatos) or die(mysqli_error($conexion));
    $sql="select id_rio,rio,longitud from rio where cuenca = $cuenca order by longitud desc";
    $resultados=mysqli_query($conexion,$sql) or die(mysqli_error($conexion));
    while ( $fila = mysqli_fetch_array($resultados, MYSQLI_ASSOC))
        {
        $datos[]=$fila;
        }
    echo json_encode($datos);
    mysqli_close($conexion);
?>