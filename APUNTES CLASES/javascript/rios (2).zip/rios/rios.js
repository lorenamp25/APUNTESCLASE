window.onload = iniciar

function iniciar() {
  let divTabla = document.getElementById("divRios")
  divTabla.style.opacity = 0.2
  divTabla.addEventListener("mouseenter", () => { divTabla.style.opacity = 1 })
  divTabla.addEventListener("mouseleave", () => { divTabla.style.opacity = 0.2 })

  cargaVertientes();
}

function cargaVertientes() {
  fetch("vertientes.json")
    .then(response => response.json())
    .then(vertientes => {
      crearSelectVertientes(vertientes)
    })
}

function crearSelectVertientes(vertientes) {
  let selectVertientes = document.getElementById("vertiente")
  selectVertientes[0]=new Option("- Selecciona una vertiente -")
  vertientes.Vertientes.forEach((vertiente,i) => {
    selectVertientes[i+1]=new Option(vertiente.Vertiente, vertiente.Id_vertiente)
  })
 cargaCuencas()
}

function cargaCuencas() {
  fetch("cuencas.xml")
    .then(response => response.text())
    .then(docCuencas => {
      let xml = new DOMParser();
      let docXML = xml.parseFromString(docCuencas, "text/xml");
      let cuencas = docXML.querySelectorAll("cuencas")
      document.getElementById("vertiente").addEventListener("change", () => crearSelectCuencas(cuencas))
      document.getElementById("cuenca").addEventListener("change", cargaRios);
      document.getElementById("rio").addEventListener("change", estiloRio);
    })
    
}

function crearSelectCuencas(cuencas) {
  document.getElementById("divRios").innerHTML = ""
  let vertiente = document.getElementById("vertiente").value;
  let selectCuenca = document.getElementById("cuenca");
  selectCuenca.innerHTML = ""
  document.getElementById("rio").innerHTML = ""
  selectCuenca[0]=new Option("- Selecciona una cuenca -")
  let contador=0
  cuencas.forEach((cuenca) => {
    if (cuenca.querySelector("Vertiente").textContent === vertiente) {
      let cue = cuenca.querySelector("cuenca").textContent
      let id = cuenca.querySelector("Id_cuenca").textContent
      selectCuenca[contador+1]=new Option(cue, id)
      contador++
    }
  })

}

function cargaRios() {
  document.getElementById("divRios").innerHTml = "";
  let cuenca = document.getElementById("cuenca").value;
  let datos = new FormData()
  datos.append("cuenca", cuenca)
  //let datos="cuenca="+$cuenca
  fetch("listadoRios.php", {
    method: 'POST', body: datos
    /*headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(datos)*/
  })
    .then(response => response.json())
    .then(rios => crearSelectRios(rios))
}

function crearSelectRios(rios) {
  let selectRios = document.getElementById("rio")
  selectRios.innerHTML = ""
  selectRios[0]=new Option(" - Selecciona un rio - ")
  rios.forEach((rio,i) => {
    selectRios[i+1]=new Option(rio.rio, rio.id_rio)
  });
  crearTabla(rios);
  estilosTabla()
}

function crearTabla(rios) {
  let tablarios = document.getElementById("divRios")
  tablarios.innerHTML = ""
  let tabla = document.createElement("table");
  tabla.id = "tabla";
  document.getElementById("divRios").append(tabla);

  let header = document.createElement("thead");

  let filah = document.createElement("tr");
  header.append(filah);
  let celdah1 = document.createElement("th");
  filah.append(celdah1)
  celdah1.textContent = "Rio"
  let celdah2 = document.createElement("th");
  celdah2.textContent = "Longitud"
  filah.append(celdah2)

  tabla.setAttribute("border", "2px solid white")
  filah.setAttribute("border", "2px solid white")
  celdah1.setAttribute("border", "2px solid white")
  celdah2.setAttribute("border", "2px solid white")
  tabla.append(filah)

  rios.forEach((rio) => {

    let fila = document.createElement("tr");
    tabla.append(fila);
    fila.id = "r" + rio.id_rio
    let celdaRio = document.createElement("td");
    celdaRio.textContent = rio.rio
    fila.append(celdaRio);
    let celdaLon = document.createElement("td");
    celdaLon.textContent = rio.longitud;
    fila.append(celdaLon);

  })

  //$tabla.tablesorter(2);

}

function estiloRio(e) {

  estilofilasTabla()

  let valor = e.target.value

  if (parseInt(valor)) {

    fila = document.querySelector("#r" + valor)

    fila.style.color = "#ff0000"
    fila.style.fontweight = "bold"
    fila.height = "20px"
    fila.padding = "10px"
    fila.textalign = "center"
    fila.style.background = "#ffff00"
  }

}

function estilosTabla() {

  let tabla = document.querySelector("table")
  tabla.style.border = "2px solid white"
  tabla.style.background = "#f2f2f2"
  tabla.style.bordercollapse = "collapse"
  tabla.style.margin = "0"
  tabla.style.width = "100%"


  let filaH = document.querySelectorAll('th')
  filaH.forEach((filaC) => {
    filaC.style.border = "2px solid white"
    filaC.style.background = "#222222"
    filaC.style.color = "#f2f2f2"
    filaC.style.fontweight = "bold"
    //filaC.style.height = "2px"
    filaC.style.padding = "10px"
  })


  let fila = document.querySelectorAll('tr:nth-child(even)')
  fila.forEach((filai) => {
    filai.style.border = "2px solid white"
    filai.style.color = "#666666"
    filai.style.height = "10px"
    filai.style.padding = "5px"
    filai.style.textalign = "center"
    filai.style.background = "#ffffff"
  })

  fila = document.querySelectorAll('tr:nth-child(odd)')
  fila.forEach((filad) => {
    filad.style.border = "2px solid white"
    filad.style.color = "#222222"
    filad.style.height = "10px"
    filad.style.padding = "5px"
    filad.style.textalign = "center"
    filad.style.background = "#dddddd"

  })
  estilofilasTabla()
}

function estilofilasTabla() {
  let fila = document.querySelectorAll('tr:nth-child(even)')
  fila.forEach((filai) => {
    filai.style.border = "2px solid white"
    filai.style.color = "#666666"
    filai.style.height = "10px"
    filai.style.padding = "5px"
    filai.style.textalign = "center"
    filai.style.background = "#ffffff"
  })

  fila = document.querySelectorAll('tr:nth-child(odd)')
  fila.forEach((filad) => {
    filad.style.border = "2px solid white"
    filad.style.color = "#222222"
    filad.style.height = "10px"
    filad.style.padding = "5px"
    filad.style.textalign = "center"
    filad.style.background = "#dddddd"
  })
}

