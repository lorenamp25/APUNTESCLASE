<?php
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, must-revalidate');

    $servidor = "localhost";
    $basedatos = "rios";
    $usuario = "root";
    $password ="";
    $conexion=mysqli_connect($servidor, $usuario, $password, $basedatos) or die(mysqli_error($conexion));
    mysqli_query($conexion,"SET NAMES 'utf8'");
    mysqli_select_db($conexion,$basedatos) or die(mysqli_error($conexion));
    $sql="select * from cuenca order by id_cuenca";
    $resultados=mysqli_query($conexion,$sql) or die(mysqli_error($conexion));
    while ( $fila = mysqli_fetch_array($resultados, MYSQLI_ASSOC))
        {
        $datos[]=$fila;
        }
    echo json_encode($datos);
    mysqli_close($conexion);
?>