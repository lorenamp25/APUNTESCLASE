window.onload = inicio

function inicio() {
  //crear una funcion que nos devuelva un objeto
  function crearAlumno(nombre, curso, nota) {
    return {
      nombre,
      curso,
      nota,

    };
  }
  //rellenar un array con objetos pidiendo los datos de cada uno con prompt, cuando sea vacio no pide mas
  let lista = []
  for (let i = 0; ; i++) {
    let alumno = prompt("Introduce nombre, curso y nota, separado por comas")
    if (alumno) {
      let propiedades = alumno.split(",")
      lista[i] = crearAlumno(propiedades[0], propiedades[1], propiedades[2])
    } else { break }
  }
  //Añadir a la tabla filas y columnas donde estas sean los objetos y el contenido de ese array
  let tbody = document.getElementById("tbody")
  lista.forEach(alumno => {
    let fila = document.createElement("tr")
    for (let key in alumno) {
      let celda = document.createElement("td")
      celda.append(alumno[key])
      fila.append(celda)
    }
    tbody.append(fila)
  })
}