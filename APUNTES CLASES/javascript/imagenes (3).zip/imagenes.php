<?php

if (isset($_POST['ancho'])) {
    $ancho = intval($_POST['ancho']);
    
    if ($ancho < 300) {
        echo "40";
    } else if ($ancho < 400) {
        echo "50";
    } else if ($ancho < 500) {
        echo "60";
    } else {
        echo "100";
    }

} else {
    echo "0";
}

?>