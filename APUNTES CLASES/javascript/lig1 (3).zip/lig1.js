
let arrayJugadores = [
	{ "Puesto": "1", "Nombre": "Andoni Zubizarreta Urreta", "Fecha de nacimiento": "10/23/1961", "Lugar de nacimiento": "Vitoria-Gasteiz", "Partidos": "622" },
	{ "Puesto": "2", "Nombre": "Joaquin Sanchez Rodriguez", "Fecha de nacimiento": "01/13/1958", "Lugar de nacimiento": "El Puerto de Santa Maria", "Partidos": "542" },
	{ "Puesto": "3", "Nombre": "Raul Garcia Escudero", "Fecha de nacimiento": "05/20/1981", "Lugar de nacimiento": "Zizur Nagusia", "Partidos": "508" },
	{ "Puesto": "4", "Nombre": "Raul Gonzalez Blanco", "Fecha de nacimiento": "03/30/1986", "Lugar de nacimiento": "Madrid", "Partidos": "502" },
	{ "Puesto": "5", "Nombre": "Eusebio Sacristan Mena", "Fecha de nacimiento": "06/27/1977", "Lugar de nacimiento": "La Seca", "Partidos": "499" },
	{ "Puesto": "6", "Nombre": "Francisco Buyo Sanchez", "Fecha de nacimiento": "03/23/1968", "Lugar de nacimiento": "Betanzos", "Partidos": "490" },
	{ "Puesto": "7", "Nombre": "Manuel Sanchis Hontiyuelo", "Fecha de nacimiento": "05/23/1965", "Lugar de nacimiento": "Madrid", "Partidos": "489" },
	{ "Puesto": "8", "Nombre": "Lionel Andres Messi Cuccittini", "Fecha de nacimiento": "07/21/1981", "Lugar de nacimiento": "Rosario", "Partidos": "471" },
	{ "Puesto": "9", "Nombre": "Iker Casillas Fernandez", "Fecha de nacimiento": "06/09/1956", "Lugar de nacimiento": "Mostoles", "Partidos": "470" },
	{ "Puesto": "10", "Nombre": "RamosSergio Ramos Garcia", "Fecha de nacimiento": "06/30/1946", "Lugar de nacimiento": "Camas", "Partidos": "467" },
	{ "Puesto": "11", "Nombre": "Xavier Hernandez Creus", "Fecha de nacimiento": "03/01/1943", "Lugar de nacimiento": "Terrassa", "Partidos": "465" },
	{ "Puesto": "12", "Nombre": "Miquel Soler Sarasols", "Fecha de nacimiento": "06/24/1987", "Lugar de nacimiento": "Hostalets d'en Bas", "Partidos": "464" },
	{ "Puesto": "13", "Nombre": "Fernando Ruiz Hierro", "Fecha de nacimiento": "10/27/1956", "Lugar de nacimiento": "Velez-Malaga", "Partidos": "455" },
	{ "Puesto": "14", "Nombre": "Jose Maria Bakero Escudero", "Fecha de nacimiento": "10/07/1966", "Lugar de nacimiento": "Goizueta", "Partidos": "447" },
	{ "Puesto": "15", "Nombre": "Lorenzo Juarros Garcia", "Fecha de nacimiento": "04/20/1960", "Lugar de nacimiento": "Mambrillas de Lara", "Partidos": "445" },
	{ "Puesto": "16", "Nombre": "Joaquin Alonso Gonzalez", "Fecha de nacimiento": "01/25/1980", "Lugar de nacimiento": "Oviedo", "Partidos": "443" },
	{ "Puesto": "17", "Nombre": "Jose Ramon Esnaola Larburu", "Fecha de nacimiento": "08/21/1967", "Lugar de nacimiento": "Andoain", "Partidos": "443" },
	{ "Puesto": "18", "Nombre": "Jose Angel Iribar Kortajarena", "Fecha de nacimiento": "01/01/1955", "Lugar de nacimiento": "Zarautz", "Partidos": "442" },
	{ "Puesto": "19", "Nombre": "Donato Gama da Silva", "Fecha de nacimiento": "02/16/1958", "Lugar de nacimiento": "Rio de Janeiro", "Partidos": "440" },
	{ "Puesto": "20", "Nombre": "Miquel Ángel Nadal Homar", "Fecha de nacimiento": "10/21/1933", "Lugar de nacimiento": "Manacor", "Partidos": "437" },
	{ "Puesto": "21", "Nombre": "Carlos Alonso Gonzalez", "Fecha de nacimiento": "02/11/1963", "Lugar de nacimiento": "Santillana del Mar", "Partidos": "431" },
	{ "Puesto": "22", "Nombre": "Alberto Gorriz Echarte", "Fecha de nacimiento": "07/03/1958", "Lugar de nacimiento": "Irun", "Partidos": "427" },
	{ "Puesto": "23", "Nombre": "Jon Andoni Larrañaga Gurrutxaga", "Fecha de nacimiento": "04/13/1964", "Lugar de nacimiento": "Azpeitia", "Partidos": "422" },
	{ "Puesto": "24", "Nombre": "Manuel Enrique Jimenez Abalo", "Fecha de nacimiento": "11/01/1962", "Lugar de nacimiento": "Vilagarcia de Arousa", "Partidos": "420" },
	{ "Puesto": "25", "Nombre": "Jesus Maria Zamora Ansorena", "Fecha de nacimiento": "03/16/1965", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "418" },
	{ "Puesto": "26", "Nombre": "Cristobal Parralo Aguilera", "Fecha de nacimiento": "12/18/1969", "Lugar de nacimiento": "Priego de Cordoba", "Partidos": "418" },
	{ "Puesto": "27", "Nombre": "Aitor Begiristain Mujika", "Fecha de nacimiento": "03/04/1944", "Lugar de nacimiento": "Olaberria", "Partidos": "417" },
	{ "Puesto": "28", "Nombre": "Joseba Andoni Etxeberria Lizardi", "Fecha de nacimiento": "08/08/1970", "Lugar de nacimiento": "Elgoibar", "Partidos": "415" },
	{ "Puesto": "29", "Nombre": "Diego Rodriguez Fernandez", "Fecha de nacimiento": "12/30/1962", "Lugar de nacimiento": "La Orotava", "Partidos": "415" },
	{ "Puesto": "30", "Nombre": "Sergio Busquets Burgos", "Fecha de nacimiento": "12/06/1930", "Lugar de nacimiento": "Sabadell", "Partidos": "415" },
	{ "Puesto": "31", "Nombre": "Enrique Castro Gonzalez", "Fecha de nacimiento": "06/26/1954", "Lugar de nacimiento": "Oviedo", "Partidos": "414" },
	{ "Puesto": "32", "Nombre": "Pedro Manuel Munitis Alvarez", "Fecha de nacimiento": "07/11/1986", "Lugar de nacimiento": "Santander", "Partidos": "414" },
	{ "Puesto": "33", "Nombre": "Ismael Urzaiz Aranda", "Fecha de nacimiento": "07/28/1966", "Lugar de nacimiento": "Tudela", "Partidos": "413" },
	{ "Puesto": "34", "Nombre": "Aritz Aduriz Zubeldia", "Fecha de nacimiento": "07/05/1962", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "412" },
	{ "Puesto": "35", "Nombre": "Andres Iniesta Lujan", "Fecha de nacimiento": "03/11/1945", "Lugar de nacimiento": "Fuentealbilla", "Partidos": "411" },
	{ "Puesto": "36", "Nombre": "Roberto Fernandez Bonillo", "Fecha de nacimiento": "02/24/1957", "Lugar de nacimiento": "Betxi", "Partidos": "407" },
	{ "Puesto": "37", "Nombre": "Miguel Angel Fuentes Azpiroz", "Fecha de nacimiento": "06/08/1955", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "407" },
	{ "Puesto": "38", "Nombre": "Francisco Gento Lopez", "Fecha de nacimiento": "01/28/1947", "Lugar de nacimiento": "Guarnizo", "Partidos": "402" },
	{ "Puesto": "39", "Nombre": "NavasJesus Navas Gonzalez", "Fecha de nacimiento": "11/21/1985", "Lugar de nacimiento": "Los Palacios y Villafranca", "Partidos": "400" },
	{ "Puesto": "40", "Nombre": "Francisco Javier Lopez Alfaro", "Fecha de nacimiento": "07/16/1988", "Lugar de nacimiento": "Osuna", "Partidos": "400" },
	{ "Puesto": "41", "Nombre": "Francisco Javier Gonzalez Perez", "Fecha de nacimiento": "04/24/1969", "Lugar de nacimiento": "Carreira", "Partidos": "399" },
	{ "Puesto": "42", "Nombre": "AlvesDaniel Alves da Silva", "Fecha de nacimiento": "11/17/1963", "Lugar de nacimiento": "Juazeiro", "Partidos": "398" },
	{ "Puesto": "43", "Nombre": "Francisco Fernandez Rodriguez", "Fecha de nacimiento": "09/02/1963", "Lugar de nacimiento": "Puerto Real", "Partidos": "398" },
	{ "Puesto": "44", "Nombre": "SalinasFrancisco Salinas Fernandez", "Fecha de nacimiento": "09/23/1949", "Lugar de nacimiento": "Bilbao", "Partidos": "397" },
	{ "Puesto": "45", "Nombre": "Eloy Jose Olaya Prendes", "Fecha de nacimiento": "08/23/1952", "Lugar de nacimiento": "Gijon", "Partidos": "397" },
	{ "Puesto": "46", "Nombre": "Gabriel Fernandez Arenas", "Fecha de nacimiento": "09/02/1971", "Lugar de nacimiento": "Madrid", "Partidos": "396" },
	{ "Puesto": "47", "Nombre": "Rafael Gordillo Vazquez", "Fecha de nacimiento": "09/26/1939", "Lugar de nacimiento": "Almendralejo", "Partidos": "396" },
	{ "Puesto": "48", "Nombre": "Juan Francisco Torres Belen", "Fecha de nacimiento": "02/02/1987", "Lugar de nacimiento": "Crevillent", "Partidos": "394" },
	{ "Puesto": "49", "Nombre": "Jose Maria Lumbreras Paños", "Fecha de nacimiento": "05/05/1980", "Lugar de nacimiento": "Tudela", "Partidos": "394" },
	{ "Puesto": "50", "Nombre": "Jose Santiago Cañizares Ruiz", "Fecha de nacimiento": "05/06/1983", "Lugar de nacimiento": "Madrid", "Partidos": "393" },
	{ "Puesto": "51", "Nombre": "Francisco Puñal Martinez", "Fecha de nacimiento": "03/17/1931", "Lugar de nacimiento": "Huarte", "Partidos": "391" },
	{ "Puesto": "52", "Nombre": "Fernando Gomez Colomer", "Fecha de nacimiento": "04/19/1958", "Lugar de nacimiento": "Valencia", "Partidos": "391" },
	{ "Puesto": "53", "Nombre": "AlfaroPablo Alfaro Armengot", "Fecha de nacimiento": "01/14/1982", "Lugar de nacimiento": "Zaragoza", "Partidos": "387" },
	{ "Puesto": "54", "Nombre": "Sergio Gonzalez Soriano", "Fecha de nacimiento": "01/06/1961", "Lugar de nacimiento": "Barcelona", "Partidos": "387" },
	{ "Puesto": "55", "Nombre": "Antoine Griezmann", "Fecha de nacimiento": "12/19/1951", "Lugar de nacimiento": "Macon", "Partidos": "386" },
	{ "Puesto": "56", "Nombre": "UfarteRoberto Lopez Ufarte", "Fecha de nacimiento": "06/25/1982", "Lugar de nacimiento": "Fez", "Partidos": "386" },
	{ "Puesto": "57", "Nombre": "Bittor Alkiza Fernandez", "Fecha de nacimiento": "11/03/1981", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "383" },
	{ "Puesto": "58", "Nombre": "Jose Martinez Sanchez", "Fecha de nacimiento": "06/05/1968", "Lugar de nacimiento": "Ceuta", "Partidos": "382" },
	{ "Puesto": "59", "Nombre": "Daniel Parejo Muñoz", "Fecha de nacimiento": "09/06/1975", "Lugar de nacimiento": "Coslada", "Partidos": "381" },
	{ "Puesto": "60", "Nombre": "SalinasJulio Salinas Fernandez", "Fecha de nacimiento": "05/28/1922", "Lugar de nacimiento": "Bilbao", "Partidos": "380" },
	{ "Puesto": "61", "Nombre": "CedrunCarmelo Cedrun Ochandategui", "Fecha de nacimiento": "03/17/1930", "Lugar de nacimiento": "Amorebieta-Etxano", "Partidos": "380" },
	{ "Puesto": "62", "Nombre": "Jose Francisco Molina Jimenez", "Fecha de nacimiento": "11/07/1920", "Lugar de nacimiento": "Valencia", "Partidos": "378" },
	{ "Puesto": "63", "Nombre": "Jose Antonio Camacho Alfaro", "Fecha de nacimiento": "07/10/1964", "Lugar de nacimiento": "Cieza", "Partidos": "378" },
	{ "Puesto": "64", "Nombre": "Luis Miguel Arconada Echarri", "Fecha de nacimiento": "03/23/1963", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "377" },
	{ "Puesto": "65", "Nombre": "RojoJose Francisco Rojo Arroita", "Fecha de nacimiento": "03/21/1991", "Lugar de nacimiento": "Bilbao", "Partidos": "377" },
	{ "Puesto": "66", "Nombre": "Karim Mostafa Benzema", "Fecha de nacimiento": "05/23/1942", "Lugar de nacimiento": "Lyon", "Partidos": "376" },
	{ "Puesto": "67", "Nombre": "Gerard Pique Bernabeu", "Fecha de nacimiento": "06/22/1982", "Lugar de nacimiento": "Barcelona", "Partidos": "376" },
	{ "Puesto": "68", "Nombre": "NavarroFernando Navarro Corbacho", "Fecha de nacimiento": "02/03/1978", "Lugar de nacimiento": "Barcelona", "Partidos": "375" },
	{ "Puesto": "69", "Nombre": "Joan Capdevila Mendez", "Fecha de nacimiento": "07/14/1969", "Lugar de nacimiento": "Tárrega", "Partidos": "375" },
	{ "Puesto": "70", "Nombre": "Alberto Lopo Garcia", "Fecha de nacimiento": "09/23/1949", "Lugar de nacimiento": "Barcelona", "Partidos": "374" },
	{ "Puesto": "71", "Nombre": "Jose Luis Perez Caminero", "Fecha de nacimiento": "01/09/1985", "Lugar de nacimiento": "Madrid", "Partidos": "374" },
	{ "Puesto": "72", "Nombre": "Raul Tamudo Montero", "Fecha de nacimiento": "04/13/1978", "Lugar de nacimiento": "Santa Coloma de Gramenet", "Partidos": "374" },
	{ "Puesto": "73", "Nombre": "Andoni Iraola Sagarna", "Fecha de nacimiento": "06/23/1971", "Lugar de nacimiento": "Usurbil", "Partidos": "373" },
	{ "Puesto": "74", "Nombre": "Jose Miguel Gonzalez Martin del Campo", "Fecha de nacimiento": "04/16/1989", "Lugar de nacimiento": "Madrid", "Partidos": "371" },
	{ "Puesto": "75", "Nombre": "Juan Carlos Valeron Santana", "Fecha de nacimiento": "05/10/1965", "Lugar de nacimiento": "Arguineguin", "Partidos": "371" },
	{ "Puesto": "76", "Nombre": "Marcos Martin de la Fuente Martin-Frances", "Fecha de nacimiento": "09/05/1977", "Lugar de nacimiento": "Valencia", "Partidos": "371" },
	{ "Puesto": "77", "Nombre": "Adelardo Rodriguez Sanchez", "Fecha de nacimiento": "09/04/1975", "Lugar de nacimiento": "Badajoz", "Partidos": "371" },
	{ "Puesto": "78", "Nombre": "Cesar Sanchez Dominguez", "Fecha de nacimiento": "02/02/1969", "Lugar de nacimiento": "Coria", "Partidos": "370" },
	{ "Puesto": "79", "Nombre": "EnriqueLuis Enrique Martinez Garcia", "Fecha de nacimiento": "07/10/1983", "Lugar de nacimiento": "Gijon", "Partidos": "370" },
	{ "Puesto": "80", "Nombre": "IIJuan Carlos Ablanedo Iglesias", "Fecha de nacimiento": "09/11/1965", "Lugar de nacimiento": "Mieres", "Partidos": "369" },
	{ "Puesto": "81", "Nombre": "Juan Vizcaino Morcillo", "Fecha de nacimiento": "04/10/1973", "Lugar de nacimiento": "La Pobla de Mafumet", "Partidos": "368" },
	{ "Puesto": "82", "Nombre": "Enrique Fernandez Romero", "Fecha de nacimiento": "11/17/1944", "Lugar de nacimiento": "Jerez de la Frontera", "Partidos": "368" },
	{ "Puesto": "83", "Nombre": "Carles Puyol Saforcada", "Fecha de nacimiento": "04/19/1970", "Lugar de nacimiento": "La Pobla de Segur", "Partidos": "368" },
	{ "Puesto": "84", "Nombre": "Jose Maria Orue Aranguren", "Fecha de nacimiento": "08/06/1964", "Lugar de nacimiento": "Bilbao", "Partidos": "367" },
	{ "Puesto": "85", "Nombre": "Miguel Bernardo Bianquetti", "Fecha de nacimiento": "02/13/1932", "Lugar de nacimiento": "Ceuta", "Partidos": "365" },
	{ "Puesto": "86", "Nombre": "Aitor Larrazabal Bilbao", "Fecha de nacimiento": "02/15/1974", "Lugar de nacimiento": "Loiu", "Partidos": "364" },
	{ "Puesto": "87", "Nombre": "Sergio Martinez Ballesteros", "Fecha de nacimiento": "11/10/1976", "Lugar de nacimiento": "Burjassot", "Partidos": "362" },
	{ "Puesto": "88", "Nombre": "ValdesVictor Valdes Arribas", "Fecha de nacimiento": "02/16/1986", "Lugar de nacimiento": "L'Hospitalet de Llobregat", "Partidos": "360" },
	{ "Puesto": "89", "Nombre": "Jose Maria Gutierrez Hernandez", "Fecha de nacimiento": "03/23/1958", "Lugar de nacimiento": "Torrejon de Ardoz", "Partidos": "360" },
	{ "Puesto": "90", "Nombre": "Ivan Rakiti?", "Fecha de nacimiento": "09/16/1968", "Lugar de nacimiento": "Rheinfelden", "Partidos": "360" },
	{ "Puesto": "91", "Nombre": "David Albelda Aliques", "Fecha de nacimiento": "08/23/1946", "Lugar de nacimiento": "La Pobla Llarga", "Partidos": "359" },
	{ "Puesto": "92", "Nombre": "Jon Andoni Goikoetxea Lasa", "Fecha de nacimiento": "02/25/1957", "Lugar de nacimiento": "Pamplona", "Partidos": "358" },
	{ "Puesto": "93", "Nombre": "Sebastian Cruzado Fernandez", "Fecha de nacimiento": "07/31/1939", "Lugar de nacimiento": "Huelva", "Partidos": "357" },
	{ "Puesto": "94", "Nombre": "Marcelo Vieira da Silva Junior", "Fecha de nacimiento": "08/06/1966", "Lugar de nacimiento": "Rio de Janeiro", "Partidos": "357" },
	{ "Puesto": "95", "Nombre": "Abelardo Fernandez Antuña", "Fecha de nacimiento": "01/12/1968", "Lugar de nacimiento": "Gijon", "Partidos": "356" },
	{ "Puesto": "96", "Nombre": "LopezDiego Lopez Rodriguez", "Fecha de nacimiento": "06/21/1971", "Lugar de nacimiento": "Paradela", "Partidos": "356" },
	{ "Puesto": "97", "Nombre": "Juan Francisco Rodriguez Herrera", "Fecha de nacimiento": "09/17/1968", "Lugar de nacimiento": "Santa Cruz de Tenerife", "Partidos": "355" },
	{ "Puesto": "98", "Nombre": "Valeri Georgievich Karpin", "Fecha de nacimiento": "02/19/1966", "Lugar de nacimiento": "Narva", "Partidos": "355" },
	{ "Puesto": "99", "Nombre": "Xavier Aguado Companys", "Fecha de nacimiento": "11/08/1967", "Lugar de nacimiento": "Badalona", "Partidos": "354" },
	{ "Puesto": "100", "Nombre": "Manuel Pazos Gonzalez", "Fecha de nacimiento": "03/18/1931", "Lugar de nacimiento": "Cambados", "Partidos": "354" },
	{ "Puesto": "101", "Nombre": "Juan Francisco Garcia Garcia", "Fecha de nacimiento": "11/02/1934", "Lugar de nacimiento": "Rafelbunyol", "Partidos": "353" },
	{ "Puesto": "102", "Nombre": "Jorge Resurreccion Merodio", "Fecha de nacimiento": "07/06/1920", "Lugar de nacimiento": "Madrid", "Partidos": "353" },
	{ "Puesto": "103", "Nombre": "Jose Angel Ziganda Lakunza", "Fecha de nacimiento": "02/01/1961", "Lugar de nacimiento": "Larrainzar", "Partidos": "353" },
	{ "Puesto": "104", "Nombre": "Ignacio Eizaguirre Arregui", "Fecha de nacimiento": "03/06/1981", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "351" },
	{ "Puesto": "105", "Nombre": "Ander Garitano Urkizu", "Fecha de nacimiento": "06/05/1960", "Lugar de nacimiento": "Derio", "Partidos": "350" },
	{ "Puesto": "106", "Nombre": "Iker Muniain Goñi", "Fecha de nacimiento": "01/18/1952", "Lugar de nacimiento": "Pamplona", "Partidos": "350" },
	{ "Puesto": "107", "Nombre": "Agustin Gainza Vicandi", "Fecha de nacimiento": "11/15/1952", "Lugar de nacimiento": "Basauri", "Partidos": "350" },
	{ "Puesto": "108", "Nombre": "Juan Manuel Asensi Ripoll", "Fecha de nacimiento": "05/20/1969", "Lugar de nacimiento": "Alicante", "Partidos": "349" },
	{ "Puesto": "109", "Nombre": "Marcial Manuel Pina Morales", "Fecha de nacimiento": "06/18/1923", "Lugar de nacimiento": "Barzana de Quiros", "Partidos": "349" },
	{ "Puesto": "110", "Nombre": "Markel Susaeta Laskurain", "Fecha de nacimiento": "07/31/1950", "Lugar de nacimiento": "Eibar", "Partidos": "349" },
	{ "Puesto": "111", "Nombre": "MariaJose Maria Garcia La Villa", "Fecha de nacimiento": "07/28/1938", "Lugar de nacimiento": "Pola de Siero", "Partidos": "349" },
	{ "Puesto": "112", "Nombre": "Ricardo Penella Arias", "Fecha de nacimiento": "04/11/1957", "Lugar de nacimiento": "Catarroja", "Partidos": "349" },
	{ "Puesto": "113", "Nombre": "Castellanos Cespedes", "Fecha de nacimiento": "04/04/1955", "Lugar de nacimiento": "Miguelturra", "Partidos": "349" },
	{ "Puesto": "114", "Nombre": "PrietoXabier Prieto Argarate", "Fecha de nacimiento": "12/19/1987", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "349" },
	{ "Puesto": "115", "Nombre": "Carlos Aguilera Martin", "Fecha de nacimiento": "08/09/1960", "Lugar de nacimiento": "Madrid", "Partidos": "349" },
	{ "Puesto": "116", "Nombre": "SetienEnrique Setien Solar", "Fecha de nacimiento": "05/12/1988", "Lugar de nacimiento": "Santander", "Partidos": "348" },
	{ "Puesto": "117", "Nombre": "Guillermo Amor Martinez", "Fecha de nacimiento": "10/12/1961", "Lugar de nacimiento": "Benidorm", "Partidos": "348" },
	{ "Puesto": "118", "Nombre": "Gabriel Moya Sanz", "Fecha de nacimiento": "02/16/1932", "Lugar de nacimiento": "Alcala de Henares", "Partidos": "347" },
	{ "Puesto": "119", "Nombre": "Daniel Solsona Puig", "Fecha de nacimiento": "06/19/1975", "Lugar de nacimiento": "Cornell� de Llobregat", "Partidos": "347" },
	{ "Puesto": "120", "Nombre": "GuerreroJulen Guerrero Lopez", "Fecha de nacimiento": "08/12/1964", "Lugar de nacimiento": "Portugalete", "Partidos": "346" },
	{ "Puesto": "121", "Nombre": "Francisco Castellano Rodriguez", "Fecha de nacimiento": "07/11/1958", "Lugar de nacimiento": "Arucas", "Partidos": "346" },
	{ "Puesto": "122", "Nombre": "Alberto Marcos Rey", "Fecha de nacimiento": "06/05/1971", "Lugar de nacimiento": "Camarma de Esteruelas", "Partidos": "345" },
	{ "Puesto": "123", "Nombre": "Rafael Alkorta Martinez", "Fecha de nacimiento": "01/26/1964", "Lugar de nacimiento": "Bilbao", "Partidos": "345" },
	{ "Puesto": "124", "Nombre": "Miguel Tendillo Belenguer", "Fecha de nacimiento": "07/15/1976", "Lugar de nacimiento": "Moncada", "Partidos": "344" },
	{ "Puesto": "125", "Nombre": "CarlosRoberto Carlos da Silva Rocha", "Fecha de nacimiento": "10/16/1939", "Lugar de nacimiento": "Gar�a", "Partidos": "343" },
	{ "Puesto": "126", "Nombre": "SilvaMauro da Silva Gomes", "Fecha de nacimiento": "11/16/1943", "Lugar de nacimiento": "S�o Bernardo do Campo", "Partidos": "343" },
	{ "Puesto": "127", "Nombre": "Diego Roberto Godin Leal", "Fecha de nacimiento": "10/26/1970", "Lugar de nacimiento": "Rosario", "Partidos": "342" },
	{ "Puesto": "128", "Nombre": "Miroslav Djukic Mici?", "Fecha de nacimiento": "10/05/1955", "Lugar de nacimiento": "�abac", "Partidos": "341" },
	{ "Puesto": "129", "Nombre": "Pedro Tomas Reñones Crego", "Fecha de nacimiento": "09/13/1947", "Lugar de nacimiento": "Santiago de Compostela", "Partidos": "341" },
	{ "Puesto": "130", "Nombre": "Jose Ramon Alexanko Ventosa", "Fecha de nacimiento": "09/10/1930", "Lugar de nacimiento": "Barakaldo", "Partidos": "341" },
	{ "Puesto": "131", "Nombre": "Francisco Higuera Fernandez", "Fecha de nacimiento": "09/01/1977", "Lugar de nacimiento": "Escurial", "Partidos": "340" },
	{ "Puesto": "132", "Nombre": "Iñigo Larrainzar Santamaria", "Fecha de nacimiento": "12/28/1971", "Lugar de nacimiento": "Pamplona", "Partidos": "338" },
	{ "Puesto": "133", "Nombre": "IIMarcelino Vaquero Gonzalez del Rio", "Fecha de nacimiento": "02/07/1969", "Lugar de nacimiento": "Gijon", "Partidos": "338" },
	{ "Puesto": "134", "Nombre": "Agustin Gajate Vidriales", "Fecha de nacimiento": "05/08/1970", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "338" },
	{ "Puesto": "135", "Nombre": "Miguel Porlan Noguera", "Fecha de nacimiento": "11/12/1923", "Lugar de nacimiento": "Totana", "Partidos": "338" },
	{ "Puesto": "136", "Nombre": "Manuel Sarabia Lopez", "Fecha de nacimiento": "10/19/1977", "Lugar de nacimiento": "Gallarta", "Partidos": "337" },
	{ "Puesto": "137", "Nombre": "Antonio Alvarez Giraldez", "Fecha de nacimiento": "05/17/1991", "Lugar de nacimiento": "Marchena", "Partidos": "337" },
	{ "Puesto": "138", "Nombre": "Jesus Angel Solana Bermejo", "Fecha de nacimiento": "02/28/1965", "Lugar de nacimiento": "Arnedo", "Partidos": "336" },
	{ "Puesto": "139", "Nombre": "AlbaJordi Alba Ramos", "Fecha de nacimiento": "01/02/1942", "Lugar de nacimiento": "L'Hospitalet de Llobregat", "Partidos": "336" },
	{ "Puesto": "140", "Nombre": "GarciaSergio Garcia de la Fuente", "Fecha de nacimiento": "01/08/1992", "Lugar de nacimiento": "Barcelona", "Partidos": "336" },
	{ "Puesto": "141", "Nombre": "AragonesLuis Aragones Suarez", "Fecha de nacimiento": "09/09/1971", "Lugar de nacimiento": "Hortaleza", "Partidos": "336" },
	{ "Puesto": "142", "Nombre": "Ignacio Zoco Esparza", "Fecha de nacimiento": "05/12/1954", "Lugar de nacimiento": "Garde", "Partidos": "335" },
	{ "Puesto": "143", "Nombre": "Francisco Ferreira Colmenero", "Fecha de nacimiento": "03/15/1973", "Lugar de nacimiento": "Saucelle", "Partidos": "335" },
	{ "Puesto": "144", "Nombre": "CarlosJuan Carlos Alvarez Vega", "Fecha de nacimiento": "02/11/1981", "Lugar de nacimiento": "El Entrego", "Partidos": "334" },
	{ "Puesto": "145", "Nombre": "Juan Carlos Arteche Gomez", "Fecha de nacimiento": "04/23/1919", "Lugar de nacimiento": "Malia�o", "Partidos": "334" },
	{ "Puesto": "146", "Nombre": "Ignacio Kortabarria Abarrategi", "Fecha de nacimiento": "02/18/1984", "Lugar de nacimiento": "Arrasate", "Partidos": "333" },
	{ "Puesto": "147", "Nombre": "Enrique Collar Monterrubio", "Fecha de nacimiento": "08/09/1985", "Lugar de nacimiento": "San Juan de Aznalfarache", "Partidos": "332" },
	{ "Puesto": "148", "Nombre": "Nicanor Sagarduy Gonzalo", "Fecha de nacimiento": "10/07/1971", "Lugar de nacimiento": "Barakaldo", "Partidos": "332" },
	{ "Puesto": "149", "Nombre": "Gorka Iraizoz Moreno", "Fecha de nacimiento": "05/19/1956", "Lugar de nacimiento": "Antsoain", "Partidos": "331" },
	{ "Puesto": "150", "Nombre": "Manuel Jimenez Jimenez", "Fecha de nacimiento": "09/27/1958", "Lugar de nacimiento": "Arahal", "Partidos": "329" },
	{ "Puesto": "151", "Nombre": "Cesar Rodriguez Alvarez", "Fecha de nacimiento": "07/04/1926", "Lugar de nacimiento": "Leon", "Partidos": "329" },
	{ "Puesto": "152", "Nombre": "Sergi Barjuan Esclusa", "Fecha de nacimiento": "05/09/1964", "Lugar de nacimiento": "Les Franqueses del Vallés", "Partidos": "328" },
	{ "Puesto": "153", "Nombre": "Agustin Aranzabal Alkorta", "Fecha de nacimiento": "01/25/1976", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "328" },
	{ "Puesto": "154", "Nombre": "Alberto Lopez Fernandez", "Fecha de nacimiento": "03/15/1957", "Lugar de nacimiento": "Irun", "Partidos": "327" },
	{ "Puesto": "155", "Nombre": "David Villa Sanchez", "Fecha de nacimiento": "10/09/1963", "Lugar de nacimiento": "Tuilla", "Partidos": "326" },
	{ "Puesto": "156", "Nombre": "Andoni Cedrun Ibarra", "Fecha de nacimiento": "01/12/1922", "Lugar de nacimiento": "Durango", "Partidos": "326" },
	{ "Puesto": "157", "Nombre": "LuisFilipe Luis Kasmirski", "Fecha de nacimiento": "02/25/1941", "Lugar de nacimiento": "Jaragua do Sul", "Partidos": "325" },
	{ "Puesto": "158", "Nombre": "Sergio Canales Madrazo", "Fecha de nacimiento": "04/01/1948", "Lugar de nacimiento": "Santander", "Partidos": "325" },
	{ "Puesto": "159", "Nombre": "Juan Gomez Gonzalez", "Fecha de nacimiento": "09/26/1955", "Lugar de nacimiento": "Fuengirola", "Partidos": "324" },
	{ "Puesto": "160", "Nombre": "PabloManuel Pablo Garcia Diaz", "Fecha de nacimiento": "05/20/1977", "Lugar de nacimiento": "Bañaderos", "Partidos": "323" },
	{ "Puesto": "161", "Nombre": "German Devora Ceballos", "Fecha de nacimiento": "01/07/1935", "Lugar de nacimiento": "Las Palmas de Gran Canaria", "Partidos": "323" },
	{ "Puesto": "162", "Nombre": "Javier Castañeda Lopez", "Fecha de nacimiento": "12/28/1963", "Lugar de nacimiento": "Madrid", "Partidos": "323" },
	{ "Puesto": "163", "Nombre": "Juan Arza Iñigo", "Fecha de nacimiento": "02/14/1938", "Lugar de nacimiento": "Estella", "Partidos": "322" },
	{ "Puesto": "164", "Nombre": "Jose Antonio Reyes Calderon", "Fecha de nacimiento": "03/20/1966", "Lugar de nacimiento": "Utrera", "Partidos": "321" },
	{ "Puesto": "165", "Nombre": "Josu Urrutia Telleria", "Fecha de nacimiento": "11/04/1972", "Lugar de nacimiento": "Lekeitio", "Partidos": "321" },
	{ "Puesto": "166", "Nombre": "Juan Cruz Sol Oria", "Fecha de nacimiento": "05/11/1984", "Lugar de nacimiento": "Elgoibar", "Partidos": "320" },
	{ "Puesto": "167", "Nombre": "Felipe Miñambres Fernandez", "Fecha de nacimiento": "04/22/1969", "Lugar de nacimiento": "Astorga", "Partidos": "319" },
	{ "Puesto": "168", "Nombre": "Hugo Sanchez Marquez", "Fecha de nacimiento": "03/21/1989", "Lugar de nacimiento": "Ciudad de Mexico", "Partidos": "319" },
	{ "Puesto": "169", "Nombre": "Vicente Iborra Richart", "Fecha de nacimiento": "12/03/1981", "Lugar de nacimiento": "Xátiva", "Partidos": "319" },
	{ "Puesto": "170", "Nombre": "LeonPedro Leon Sanchez Gil", "Fecha de nacimiento": "12/25/1964", "Lugar de nacimiento": "Mula", "Partidos": "318" },
	{ "Puesto": "171", "Nombre": "Juan Castaño Quiros", "Fecha de nacimiento": "01/28/1949", "Lugar de nacimiento": "Gijon", "Partidos": "317" },
	{ "Puesto": "172", "Nombre": "Javier Iruretagoyena Amiano", "Fecha de nacimiento": "01/27/1940", "Lugar de nacimiento": "Irun", "Partidos": "317" },
	{ "Puesto": "173", "Nombre": "Amancio Amaro Varela", "Fecha de nacimiento": "04/22/1967", "Lugar de nacimiento": "A Coruña", "Partidos": "317" },
	{ "Puesto": "174", "Nombre": "Delfi Geli Roura", "Fecha de nacimiento": "12/22/1959", "Lugar de nacimiento": "Salt", "Partidos": "316" },
	{ "Puesto": "175", "Nombre": "Eugenio Bustingorri Oiz", "Fecha de nacimiento": "07/22/1963", "Lugar de nacimiento": "Zulueta", "Partidos": "316" },
	{ "Puesto": "176", "Nombre": "Sergio Paulo Barbosa Valente", "Fecha de nacimiento": "05/22/1967", "Lugar de nacimiento": "Porto", "Partidos": "315" },
	{ "Puesto": "177", "Nombre": "Ariel Miguel Santiago Ibagaza Fernandez", "Fecha de nacimiento": "02/28/1969", "Lugar de nacimiento": "Buenos Aires", "Partidos": "315" },
	{ "Puesto": "178", "Nombre": "SalgadoMiguel Angel Salgado Fernandez", "Fecha de nacimiento": "01/23/1951", "Lugar de nacimiento": "As Neves", "Partidos": "315" },
	{ "Puesto": "179", "Nombre": "Fernando Martinez Perales", "Fecha de nacimiento": "11/10/1954", "Lugar de nacimiento": "Valencia", "Partidos": "313" },
	{ "Puesto": "180", "Nombre": "Ruben Gracia Calmache", "Fecha de nacimiento": "10/20/1965", "Lugar de nacimiento": "Zaragoza", "Partidos": "313" },
	{ "Puesto": "181", "Nombre": "Victor Manuel Fernandez Gutierrez", "Fecha de nacimiento": "08/25/1943", "Lugar de nacimiento": "Merida", "Partidos": "313" },
	{ "Puesto": "182", "Nombre": "MarcosOscar de Marcos Arana", "Fecha de nacimiento": "01/30/1965", "Lugar de nacimiento": "Laguardia", "Partidos": "312" },
	{ "Puesto": "183", "Nombre": "Jesus Garay Vecino", "Fecha de nacimiento": "10/21/1965", "Lugar de nacimiento": "Bilbao", "Partidos": "312" },
	{ "Puesto": "184", "Nombre": "Emilio Butragueño Santos", "Fecha de nacimiento": "10/01/1966", "Lugar de nacimiento": "Madrid", "Partidos": "311" },
	{ "Puesto": "185", "Nombre": "Luis Mariano Minguela Muñoz", "Fecha de nacimiento": "08/05/1971", "Lugar de nacimiento": "Frumales", "Partidos": "311" },
	{ "Puesto": "186", "Nombre": "PazRafael Paz Marin", "Fecha de nacimiento": "01/24/1946", "Lugar de nacimiento": "Puebla de Don Fadrique", "Partidos": "309" },
	{ "Puesto": "187", "Nombre": "Gonzalo Colsa Albendea", "Fecha de nacimiento": "10/22/1975", "Lugar de nacimiento": "Santander", "Partidos": "309" },
	{ "Puesto": "188", "Nombre": "Salvador Gonzalez Marco", "Fecha de nacimiento": "01/28/1969", "Lugar de nacimiento": "L'Alcudia", "Partidos": "308" },
	{ "Puesto": "189", "Nombre": "Fernando Gabriel Caceres Zaya", "Fecha de nacimiento": "10/27/1962", "Lugar de nacimiento": "Buenos Aires", "Partidos": "308" },
	{ "Puesto": "190", "Nombre": "Jose Maria Busto Llano", "Fecha de nacimiento": "08/29/1983", "Lugar de nacimiento": "Portugalete", "Partidos": "307" },
	{ "Puesto": "191", "Nombre": "Enrique Montero Rodriguez", "Fecha de nacimiento": "10/21/1946", "Lugar de nacimiento": "El Puerto de Santa Maria", "Partidos": "306" },
	{ "Puesto": "192", "Nombre": "Santiago Aragon Martinez", "Fecha de nacimiento": "04/14/1968", "Lugar de nacimiento": "Malaga", "Partidos": "306" },
	{ "Puesto": "193", "Nombre": "Iñigo Martinez Berridi", "Fecha de nacimiento": "02/17/1952", "Lugar de nacimiento": "Ondarroa", "Partidos": "305" },
	{ "Puesto": "194", "Nombre": "Antonio Prats Cervera", "Fecha de nacimiento": "03/01/1945", "Lugar de nacimiento": "Capdepera", "Partidos": "305" },
	{ "Puesto": "195", "Nombre": "Ruben Baraja Vegas", "Fecha de nacimiento": "04/27/1927", "Lugar de nacimiento": "Valladolid", "Partidos": "305" },
	{ "Puesto": "196", "Nombre": "Jesus Glaria Jordan", "Fecha de nacimiento": "09/11/1962", "Lugar de nacimiento": "Villafranca", "Partidos": "305" },
	{ "Puesto": "197", "Nombre": "Genar Andrinua Kortabarria", "Fecha de nacimiento": "08/23/1956", "Lugar de nacimiento": "Getxo", "Partidos": "304" },
	{ "Puesto": "198", "Nombre": "Pedro Uralde Hernaez", "Fecha de nacimiento": "08/02/1965", "Lugar de nacimiento": "Vitoria-Gasteiz", "Partidos": "304" },
	{ "Puesto": "199", "Nombre": "Fernando Morientes Sanchez", "Fecha de nacimiento": "09/04/1985", "Lugar de nacimiento": "Cilleros", "Partidos": "303" },
	{ "Puesto": "200", "Nombre": "Jose Ignacio Churruca Sistiaga", "Fecha de nacimiento": "02/06/1981", "Lugar de nacimiento": "Zarautz", "Partidos": "303" },
	{ "Puesto": "201", "Nombre": "Luis Filipe Madeira Caeiro Figo", "Fecha de nacimiento": "08/26/1958", "Lugar de nacimiento": "Almada", "Partidos": "303" },
	{ "Puesto": "202", "Nombre": "Josep Lluis Marti Soler", "Fecha de nacimiento": "10/17/1977", "Lugar de nacimiento": "Palma", "Partidos": "303" },
	{ "Puesto": "203", "Nombre": "Idriss Carlos Kameni", "Fecha de nacimiento": "12/19/1992", "Lugar de nacimiento": "Douala", "Partidos": "302" },
	{ "Puesto": "204", "Nombre": "Epifanio Fernandez Berridi", "Fecha de nacimiento": "09/04/1945", "Lugar de nacimiento": "Donostia/San Sebastian", "Partidos": "302" },
	{ "Puesto": "205", "Nombre": "Victor Muñoz Manrique", "Fecha de nacimiento": "01/18/1958", "Lugar de nacimiento": "Zaragoza", "Partidos": "302" },
	{ "Puesto": "206", "Nombre": "Estanislao Argote Salaberria", "Fecha de nacimiento": "09/18/1979", "Lugar de nacimiento": "Zarautz", "Partidos": "302" },
	{ "Puesto": "207", "Nombre": "Jesus Landaburu Sag�illo", "Fecha de nacimiento": "01/13/1947", "Lugar de nacimiento": "Guardo", "Partidos": "302" },
	{ "Puesto": "208", "Nombre": "Pablo Javier Diaz Stalla", "Fecha de nacimiento": "12/31/1931", "Lugar de nacimiento": "Buenos Aires", "Partidos": "301" },
	{ "Puesto": "209", "Nombre": "Negredo Sanchez", "Fecha de nacimiento": "01/24/1955", "Lugar de nacimiento": "Madrid", "Partidos": "300" },
	{ "Puesto": "210", "Nombre": "Carlos Marchena Lopez", "Fecha de nacimiento": "10/15/1948", "Lugar de nacimiento": "Las Cabezas de San Juan", "Partidos": "300" },
	{ "Puesto": "211", "Nombre": "Moises Garcia Fernandez", "Fecha de nacimiento": "01/07/1974", "Lugar de nacimiento": "Cadiz", "Partidos": "300" },
	{ "Puesto": "212", "Nombre": "StefanoAlfredo Stefano Di Stefano Laulhe", "Fecha de nacimiento": "04/17/1974", "Lugar de nacimiento": "Buenos Aires", "Partidos": "300" },
	{ "Puesto": "213", "Nombre": "GarciaLuis Garcia Fernandez", "Fecha de nacimiento": "12/06/1936", "Lugar de nacimiento": "Oviedo", "Partidos": "300" },
	{ "Puesto": "214", "Nombre": "Javier Manjarin Pereda", "Fecha de nacimiento": "01/05/1960", "Lugar de nacimiento": "Gijon", "Partidos": "300" },
	{ "Puesto": "215", "Nombre": "Alberto Martinez Diaz", "Fecha de nacimiento": "10/27/1949", "Lugar de nacimiento": "Reiriz", "Partidos": "300" },
	{ "Puesto": "216", "Nombre": "Carles Rexach Cerda", "Fecha de nacimiento": "03/02/1968", "Lugar de nacimiento": "Barcelona", "Partidos": "299" },
	{ "Puesto": "217", "Nombre": "FrancoLeonardo Neoren Franco Ansio", "Fecha de nacimiento": "06/13/1956", "Lugar de nacimiento": "Buenos Aires", "Partidos": "299" },
	{ "Puesto": "218", "Nombre": "Francisco Garcia Gomez", "Fecha de nacimiento": "03/10/1988", "Lugar de nacimiento": "Oviedo", "Partidos": "299" },
	{ "Puesto": "219", "Nombre": "Vicente Engonga Mate", "Fecha de nacimiento": "08/04/1985", "Lugar de nacimiento": "Barcelona", "Partidos": "299" },
	{ "Puesto": "220", "Nombre": "Jose Luis Violeta Lajusticia", "Fecha de nacimiento": "04/03/1968", "Lugar de nacimiento": "Zaragoza", "Partidos": "298" },
	{ "Puesto": "221", "Nombre": "RekarteAitor Lopez Rekarte", "Fecha de nacimiento": "08/18/1975", "Lugar de nacimiento": "Arrasate", "Partidos": "298" },
	{ "Puesto": "222", "Nombre": "Jose Luis Lopez Panizo", "Fecha de nacimiento": "12/10/1945", "Lugar de nacimiento": "Sestao", "Partidos": "298" },
	{ "Puesto": "223", "Nombre": "Miguel Pardeza Pichardo", "Fecha de nacimiento": "11/15/1927", "Lugar de nacimiento": "La Palma del Condado", "Partidos": "297" },
	{ "Puesto": "224", "Nombre": "Jose Maria Quevedo Garcia", "Fecha de nacimiento": "06/28/1989", "Lugar de nacimiento": "Cadiz", "Partidos": "297" },
	{ "Puesto": "225", "Nombre": "Raul Albiol Tortajada", "Fecha de nacimiento": "01/05/1955", "Lugar de nacimiento": "Valencia", "Partidos": "296" },
	{ "Puesto": "226", "Nombre": "RodriguezJuan Antonio Rodriguez Villamuela", "Fecha de nacimiento": "01/06/1946", "Lugar de nacimiento": "Malaga", "Partidos": "295" },
	{ "Puesto": "227", "Nombre": "Roberto Soldado Rillo", "Fecha de nacimiento": "09/01/1959", "Lugar de nacimiento": "Valencia", "Partidos": "295" },
	{ "Puesto": "228", "Nombre": "Juan Manuel Martinez Martinez", "Fecha de nacimiento": "06/17/1975", "Lugar de nacimiento": "Lorca", "Partidos": "294" },
	{ "Puesto": "229", "Nombre": "Fernando Ansola San Martin", "Fecha de nacimiento": "04/13/1955", "Lugar de nacimiento": "Elgoibar", "Partidos": "293" },
	{ "Puesto": "230", "Nombre": "Manuel Zuñiga Fernandez", "Fecha de nacimiento": "04/02/1979", "Lugar de nacimiento": "Luciana", "Partidos": "293" },
	{ "Puesto": "231", "Nombre": "Manuel Mestre Torres", "Fecha de nacimiento": "02/02/1965", "Lugar de nacimiento": "Oliva", "Partidos": "293" },
	{ "Puesto": "232", "Nombre": "Santiago Cazorla Gonzalez", "Fecha de nacimiento": "12/31/1964", "Lugar de nacimiento": "Lugo de Llanera", "Partidos": "292" },
	{ "Puesto": "233", "Nombre": "Francisco Javier Casquero Paredes", "Fecha de nacimiento": "07/31/1979", "Lugar de nacimiento": "Talavera de la Reina", "Partidos": "291" },
	{ "Puesto": "234", "Nombre": "Alexis Ruano Delgado", "Fecha de nacimiento": "08/02/1921", "Lugar de nacimiento": "Malaga", "Partidos": "291" },
	{ "Puesto": "235", "Nombre": "Ricardo Gonzalez Bango", "Fecha de nacimiento": "07/16/1946", "Lugar de nacimiento": "Gijon", "Partidos": "291" },
	{ "Puesto": "236", "Nombre": "Papakouly Diop", "Fecha de nacimiento": "01/17/1973", "Lugar de nacimiento": "Kaolack", "Partidos": "291" },
	{ "Puesto": "237", "Nombre": "Alberto Belsue Arias", "Fecha de nacimiento": "10/20/1960", "Lugar de nacimiento": "Zaragoza", "Partidos": "290" },
	{ "Puesto": "238", "Nombre": "Francisco Roman Alarcon Suarez", "Fecha de nacimiento": "08/23/1912", "Lugar de nacimiento": "Arroyo de la Miel", "Partidos": "290" },
	{ "Puesto": "239", "Nombre": "Juan Carlos Unzue Labiano", "Fecha de nacimiento": "10/22/1973", "Lugar de nacimiento": "Orkoien", "Partidos": "290" },
	{ "Puesto": "240", "Nombre": "Jorge Otero Bouzas", "Fecha de nacimiento": "06/01/1969", "Lugar de nacimiento": "Nigran", "Partidos": "290" },
	{ "Puesto": "241", "Nombre": "Miguel Angel Ruiz Garcia", "Fecha de nacimiento": "01/09/1970", "Lugar de nacimiento": "Toledo", "Partidos": "290" },
	{ "Puesto": "242", "Nombre": "IgnacioJose Ignacio Saenz Marin", "Fecha de nacimiento": "12/04/1925", "Lugar de nacimiento": "Logroño", "Partidos": "289" },
	{ "Puesto": "243", "Nombre": "Gregorio Benito Rubio", "Fecha de nacimiento": "08/01/1950", "Lugar de nacimiento": "Puente del Arzobispo", "Partidos": "289" },
	{ "Puesto": "244", "Nombre": "Miguel Angel Sola Elizalde", "Fecha de nacimiento": "04/05/1951", "Lugar de nacimiento": "Pamplona", "Partidos": "288" },
	{ "Puesto": "245", "Nombre": "Bernhard Schuster", "Fecha de nacimiento": "05/31/1967", "Lugar de nacimiento": "Augsburg", "Partidos": "288" },
	{ "Puesto": "246", "Nombre": "Jesus Antonio Castro Gonzalez", "Fecha de nacimiento": "08/02/1954", "Lugar de nacimiento": "Oviedo", "Partidos": "287" },
	{ "Puesto": "247", "Nombre": "Maximiliano David Banega Hernandez", "Fecha de nacimiento": "05/26/1943", "Lugar de nacimiento": "Rosario", "Partidos": "287" },
	{ "Puesto": "248", "Nombre": "Carlos Antonio Muñoz Cobo", "Fecha de nacimiento": "10/24/1927", "Lugar de nacimiento": "Ubeda", "Partidos": "287" },
	{ "Puesto": "249", "Nombre": "Adrian Lopez Alvarez", "Fecha de nacimiento": "04/18/1958", "Lugar de nacimiento": "Teverga", "Partidos": "287" },
	{ "Puesto": "250", "Nombre": "Miguel Angel Angulo Valderrey", "Fecha de nacimiento": "08/31/1966", "Lugar de nacimiento": "Oviedo", "Partidos": "286" }
]


window.onload = function () {
	let dialogo=document.createElement("dialog")
	dialogo.id="dialogo"
	let mapa=document.createElement("a")
	mapa.id="mapa"
	mapa.target="_blank"
	mapa.append("Mapa del lugar de nacimiento")
	dialogo.append(mapa)
	dialogo.append(document.createElement("br"))
	let boton=document.createElement("button")
	boton.append("salir")
	dialogo.append(boton)
	document.body.prepend(dialogo)
	boton.addEventListener("click",()=> dialogo.close())

	obtenerDatos();

}

function obtenerDatos() {

	function mostrarDatos(e) {  // e es el objeto evento el cual aprovecho su valor en target para saber que opcion ha sido seleccionada

		let num = e.target.value
		let id = "jugador" + num  //Este id es el del jugador que se corresponde
        let jugador=document.getElementById(id)
		let nombre = jugador.textContent
		let edad = jugador.getAttribute("edad")
		let numPartidos = parseInt(jugador.getAttribute("numPartidos"))
		let fila = document.createElement("tr")
		fila.id = "fila" + num
		let celda1 = document.createElement("td")
		celda1.setAttribute("lugar", jugador.getAttribute("lugar"))
		let celda2 = document.createElement("td")
		let celda3 = document.createElement("td")
		celda1.textContent = nombre
		celda2.textContent = edad
		celda3.textContent = numPartidos
		if (numPartidos > maxPartidos) {
			filaMax.setAttribute("style", "background-color:#FFFFFF")
			filaMax = fila
			maxPartidos = numPartidos
			fila.setAttribute("style", "background-color:#999999")
		}
		fila.append(celda1)
		fila.append(celda2)
		fila.append(celda3)
		document.getElementById("tabla").append(fila)
		document.getElementById(id).remove()
	}

	class Persona {
		constructor(nombre, fechaNacimiento,lugarNacimiento) {
			this.nombre = nombre
			this.fechaNacimiento = fechaNacimiento
			this.lugarNacimiento=lugarNacimiento
		}
		edad = () => {
			let fecha = new Date(this.fechaNacimiento)
			return (new Date(Date.now() - fecha)).getFullYear() - 1970
		}
	}

	class Jugador extends Persona {
		constructor(nombre, fechaNacimiento, lugarNacimiento, posicion, partidos) {
			super(nombre, fechaNacimiento, lugarNacimiento)
			this.posicion = posicion
			this.partidos = partidos
		}
	}

	let datos = []
	arrayJugadores.map((jugador) => datos.push(new Jugador(jugador.Nombre, jugador["Fecha de nacimiento"],  jugador["Lugar de nacimiento"], null, jugador.Partidos)))

	let cabecera = document.createElement("h1")
	cabecera.id = "cabecera"
	cabecera.textContent = "LISTADO DE JUGADORES"
	document.getElementById("tabla").before(cabecera);

	let selectDatos = document.createElement('select');
	selectDatos.id = "opciones"
	document.getElementById("cabecera").before(selectDatos);

	let opcion = document.createElement('option');
	opcion.id = "0"  //añado identifcador y valor para seleccionarloy utilizarlo mas adelante
	opcion.textContent = "-- Selecciona un jugador --"
	selectDatos.append(opcion);
	datos.forEach(function (dato, i) {
		opcion = document.createElement('option');
		opcion.id = "jugador" + i
		opcion.value = i
		opcion.setAttribute("edad", dato.edad())
		opcion.setAttribute("numPartidos", dato.partidos)
		opcion.setAttribute("lugar", dato.lugarNacimiento)
		opcion.textContent = dato.nombre
		selectDatos.append(opcion);
	})
	let filaMax=document.createElement("tr")
	let maxPartidos = 0
	selectDatos.addEventListener("change", mostrarDatos);
	document.getElementById("tabla").addEventListener("click", mostrarOpciones);
}

function mostrarOpciones(e){
	let lugar=e.target.getAttribute("lugar")
	let a=document.getElementById("mapa")
	a.href = `https://www.google.es/maps/search/${lugar}`;
	document.getElementById("dialogo").showModal()
}

