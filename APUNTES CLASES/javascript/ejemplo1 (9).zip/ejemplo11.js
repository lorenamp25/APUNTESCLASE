window.onload = inicio
function inicio(){
    let seleccion=document.getElementById("seleccion")
    let select=document.createElement("select")
    seleccion.after(select)
    select[0]=new Option("- Elige una opción -")
    let indice=1
    while(true){
        let opcion=prompt("Introduce una opción:")
        if (opcion=="") break
        select[indice]=new Option(`${indice}.- opcion: ${opcion}`,opcion)
        indice++
    }
    document.querySelector("h1").hidden=false
    let valorSel=document.createElement("h2")
    seleccion.before(valorSel)

    select.addEventListener("change", ()=>{
        // if (document.getElementById("valor")) document.getElementById("valor").remove()
        // let valorSel=document.createElement("h2")
        // valorSel.id="valor"
        // seleccion.before(valorSel)
        // valorSel.append(select.value)
        valorSel.textContent=select.value

    }


    )
    
    


}