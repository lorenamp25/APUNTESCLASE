<?php
    $conexion = mysqli_connect("localhost", "root", "", "pinturas");

    if($conexion->connect_error){
        print "Fallo al conectar con la base de datos. ".$conexion->connect_error;
        echo 0;
    }else{
        $titulo = $_POST["titulo"];
        $sql = "SELECT Titulo,Autor,Pais,Siglo FROM cuadros WHERE Titulo='".$titulo."'";
        $resultados=mysqli_query($conexion,$sql) or die(mysqli_error($conexion));
        while ( $fila = mysqli_fetch_array($resultados, MYSQLI_ASSOC))
            {
            $datos[]=$fila;
            }
           
        echo(json_encode($datos));
        
        mysqli_close($conexion);
    }

?>