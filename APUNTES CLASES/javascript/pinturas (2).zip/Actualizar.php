<?php

$conexion = new mysqli('localhost', 'root', '', 'pinturas');

if($conexion->connect_error){
    print "Error al conectar con la base de datos";
}else{
    if ($_SERVER["REQUEST_METHOD"] == "POST") { 
        $titulo = $_POST['titulo'];
        $siglo = $_POST['siglo'];
        
        $consulta = ("UPDATE cuadros SET Siglo='".$siglo."' WHERE Titulo='".$titulo."'");
        echo $consulta;
        $resultado = mysqli_query($conexion, $consulta);
    }
}

?>