﻿CREATE DATABASE pinturas;
USE pinturas;

CREATE TABLE cuadros (
  
  Titulo varchar(30),
  Autor varchar(40) DEFAULT NULL,
  Pais varchar(30) DEFAULT NULL,
  Siglo varchar(6) DEFAULT NULL,
 
  PRIMARY KEY (Titulo))
  ENGINE=InnoDB;

INSERT INTO cuadros (Titulo,Autor,Pais)
VALUES
("Guernica","Pablo Picasso","España"),
("La Mona Lisa  La Gioconda","Leonardo da Vinci","Italia"),
("El Beso","Gustav Klimt","Austria"),
("El Nacimiento de Venus","Sandro Botticelli","Italia"),
("La Noche Estrellada","Vincent van Gogh","Paises Bajos"),
("La Última Cena","Leonardo Da Vinci","Italia"),
("La Creación de Adán"," Miguel Ángel","Italia"),
("Las Meninas","Diego Velázquez","España"),
("El Grito","Edvard Munch","Noruega"),
("La Joven de la Perla","Johannes Vermeer","Paises Bajos")
