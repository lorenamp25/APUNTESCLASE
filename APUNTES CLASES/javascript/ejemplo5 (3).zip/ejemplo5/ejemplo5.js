window.onload = inicio

function inicio() {

    // Crea un parrafo arriba del todo que muestre los segundos
    let fecha = new Date()
    let parrafo = document.createElement("p")
    document.body.prepend(parrafo)
    let comienzo = `Llevas conectado desde ${('0' + fecha.getHours()).slice(-2)}:${('0' + fecha.getMinutes()).slice(-2)}:${('0' + fecha.getSeconds()).slice(-2)}`
    setInterval(() => {
        parrafo.textContent = comienzo + ` y han pasado ${((Date.now() - fecha) / 1000).toFixed(0)} segundos conectado`
    }, 1000);

    //crear una funcion constructora de un objeto
    //propiedades: nombre en mayuscula y nota con 2 decimales
    //incluir una propiedad asociada a un metodo que nos devulva
    //el mensaje La nota de "nombre" es "nota"

    // añade fecha de nacimiento y un metodo que devuelva su edad

    function CrearAlumno(nombre, curso, nota, fechaN) {
        this.nombre = nombre.toUpperCase();
        this.curso = curso;
        this.nota = parseFloat(nota).toFixed(2);
        this.fechaN = fechaN
        this.mensaje = () => `La nota de ${this.nombre} es ${this.nota}`
        this.edad = () => {
            let fecha=new Date(formatoFecha(this.fechaN))
            return (new Date(Date.now() - fecha)).getFullYear() - 1970
        }
    };
    //rellenar un array con objetos pidiendo los datos de cada uno con prompt, cuando sea vacio no pide mas
    let arrayLista = []
    for (; ;) {
        let alumno = prompt("Introduce nombre, curso y nota, y dia de nacimiento (dd/mm/aaaa) separado todo por -", "Alberto-1º-6-05/08/1996")
        if (alumno) {
            let propiedades = alumno.split("-")
            //modifico parametros al crear el objeto y el mensaje de arriba
            arrayLista.push(new CrearAlumno(propiedades[0], propiedades[1], propiedades[2], propiedades[3]))
        } else { break }
    }
    // ordena la lista por nota
    arrayLista.sort((a, b) => a.nota - b.nota);
    // funcion para crear tabla

    crearTabla(arrayLista)
    // crear un select que nos pida un curso
    // y con el seleccionado mostrar una lista 
    // con el mensaje de cada alumno de ese curso
    let seleccion = document.createElement("select")
    seleccion.id = "seleccion"
    document.getElementById("mitabla").after(seleccion)
    seleccion[0] = new Option("- Elige una opción -")
    let arrayCursos = arrayLista.map(item => item.curso)
    let arrayCurso = Array.from(new Set(arrayCursos))
    arrayCurso.forEach((curso, i) => seleccion[i + 1] = new Option(curso, curso))
    seleccion.addEventListener("change", () => mostrarNotas(arrayLista))
}

function crearTabla(arrayLista) {
    let tbody = document.getElementById("tbody")
    arrayLista.forEach(alumno => {
        let fila = document.createElement("tr")
        for (let key in alumno) {
            let celda = document.createElement("td")
            celda.append(alumno[key])
            fila.append(celda)
        }

        //añado la edad
        let celda = document.createElement("td")
        celda.append(alumno.edad())
        fila.append(celda)
        tbody.append(fila)
    })

}

function mostrarNotas(arrayLista) {
    let curso = document.getElementById("seleccion").value
    if (document.getElementById("lista")) document.getElementById("lista").remove()
    let lista = document.createElement("ul")
    lista.id = "lista"
    document.getElementById("mitabla").before(lista)
    let arrayNotas = arrayLista.filter(elemento => elemento.curso === curso);
    arrayNotas.forEach(alumno => {
        let guion = document.createElement("li")
        guion.append(alumno.mensaje())
        lista.append(guion)
    })
    /* Lo mismo de arriba pero sin utilizar el filter, el filtro es manual
      arrayLista.forEach(alumno => {
        if (alumno.curso === curso) {
          let guion = document.createElement("li")
          guion.append(alumno.mensaje())
          lista.append(guion)
        }
      })
      */
    let sumaLista = arrayLista.reduce((suma, elemento) => suma + +elemento.nota, 0);
    if (document.getElementById("section")) document.getElementById("section").remove()
    let section = document.createElement("section")
    section.id = "section"
    section.innerHTML = `<strong>La nota media es: ${sumaLista / arrayLista.length}</strong>`
    document.getElementById("mitabla").prepend(section)
}
function formatoFecha(fecha) {
    let arrayFecha = fecha.split("/");
    return `${arrayFecha[2]}/${(arrayFecha[1])}/${arrayFecha[0]}`

}