window.onload = inicio

function inicio() {

    function Persona(nombrePila, apellido, edad, genero, intereses) {
        this.nombre = { nombrePila, apellido };
        this.edad = edad;
        this.genero = genero;
        this.intereses = intereses;
    };

    // Todos los métodos están definidos en el prototipo del constructor. Por ejemplo:
    Persona.prototype.saludo = function () {
        alert('¡Hola! soy ' + this.nombre.nombrePila + '.');
    };

    // crear una clase de Profesor, como la que describimos en nuestra definición inicial orientada a objetos,
    // que hereda todos los miembros de Persona, pero también incluye:
    // 1. Una nueva propiedad, materia: contendrá la materia que el profesor enseña.
    // 2. Un método actualizado de saludo(), que suena un poco más formal que el método estándar de saludo(),
    //    más adecuado para un profesor que se dirige a algunos estudiantes en la escuela.

    function Profesor(nombrePila, apellido, edad, genero, intereses, materia) {
        // utilizamos call para indicar que el this de persona es el objeto profesor
        Persona.call(this, nombrePila, apellido, edad, genero, intereses);
        this.materia = materia;
    }

    // esto solo seria crear objeto, no hererar
    // function Profesor(nombrePila, apellido, edad, genero, intereses, materia) { ç
    //         this.nombre = { nombrePila, apellido }; 
    //         this.edad = edad; 
    //         this.genero = genero; 
    //         this.intereses = intereses; 
    //         this.materia = materia; }

    // Definimos un nuevo constructor, y tiene una propiedad prototype, 
    // la cual por defecto solo contiene una referencia a la función constructor en sí misma. 
    // No contiene los métodos de la propiedad prototype del constructor Persona. Para ver esto,
    // introduzca Object.getOwnPropertyNames(Profesor.prototype) que devuelve un
    // array con todas las propiedades (numerables o no) encontradas en un objeto dado.
    console.log(Object.getOwnPropertyNames(Profesor.prototype))
    debugger
    // Introdúzcalo nuevamente, reemplazando Profesor con Persona. 
    // El nuevo constructor tampoco hereda esos métodos. 
    // Para ver esto, compara los resultados de Persona.prototype.saludo and Profesor.prototype.saludo. 
    // Necesitamos obtener Profesor() para obtener los métodos definidos en el prototipo de Persona(). 
    // Para ello:

    Profesor.prototype = Object.create(Persona.prototype);

    console.log(Persona.prototype.saludo)
    console.log(Profesor.prototype.saludo)

    debugger

    // Después de agregar la última línea, la propiedad del constructor Profesor.prototype ahora 
    // es igual a Persona (), porque acabamos de configurar Profesor.prototype para hacer referencia a un objeto 
    // que hereda sus propiedades de Persona.prototype. Guarda el código, cargar la página en un navegador 
    // e ingresar Profesor.prototype.constructor en la consola para comprobarlo.

    console.log(Profesor.prototype.constructor)
    debugger
    // Esto puede convertirse en un problema, por lo que debemos corregirlo.

    Profesor.prototype.constructor = Profesor;

    // Ahora, si guarda y actualiza, al ingresar Profesor.prototype.constructor debería devolver Profesor (),
    // según lo desee, ¡además ahora estamos heredando de Persona ()

    let profesor= new Profesor("Jose","García",40,"Masculino","Natación","DWEC")
    console.log(profesor)
    debugger
}