<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
error_reporting(0);
mysqli_report(MYSQLI_REPORT_OFF); //Turn off irritating default messages
$conexion = mysqli_connect("localhost", "root", "", "Atletas");

if (!mysqli_connect_errno()) {    
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $atleta = $_POST["atleta"];
    //$fecha=date('Y-m-d H:i:s');
    $fecha = $_POST["fecha"];
    $codigo = $_POST["codigo"];
    $sql= "INSERT INTO consultas SET atleta='".$atleta."', codigo = '".$codigo."', fecha='".$fecha."' ON DUPLICATE KEY UPDATE codigo = '".$codigo."', fecha='".$fecha."'";
    $resultados = mysqli_query($conexion, $sql) or die(mysqli_error($conexion));
    mysqli_close($conexion);
  }
}
class Result{}
$response = new Result();
if ($resultados != null) {
  $response->mensaje = 'Base de datos modificada';
} else {
  $response->mensaje = '¡Error, datos no introducidos!';
}
header('Content-Type: application/json');
echo json_encode($response);
?>