window.onload = inicio

function inicio() {
  let input = document.createElement("input")
  input.id = "input"
  document.getElementById("pregunta").append(input)
  input.addEventListener("blur", validar)
}

function validar(e) {
  let pasaporte = e.target.value
  if (/^[a-z]{3}[0-9]{6}[a-z]?$/i.test(pasaporte)) {
    continuar(pasaporte)
  } else {
    e.target.value = "codigo no Valido"
    e.target.focus()
  }
}

function continuar(pasaporte) {
  //alert(`El ${pasaporte} es correcto`)
  document.getElementById("pre").textContent=`El ${pasaporte} es correcto`
  document.getElementById("dialogo").showModal()
  setTimeout(()=>document.getElementById("dialogo").close(),2000)
}



