window.addEventListener("DOMContentLoaded", function () {  // se puede emplear tambien document.addEventListener("DOMContentLoaded", ()={})
    cargarFotos()
})

function cargarFotos() {

    let xhr = fetch("imagenes.xml")
        .then(response => response.text())
        .then(textoXML => {
            let xml = new DOMParser();
            let docXML = xml.parseFromString(textoXML, "text/xml");
            let fotos = docXML.querySelectorAll("foto");

            let tabla = document.getElementById("tabla")

            tabla.addEventListener("click", elegirFoto)

            fotos.forEach((foto, i) => {
                if (foto.querySelector("activa").textContent == "Si") {
                    let fila = tabla.insertRow()
                    let td1 = fila.insertCell()
                    let td2 = fila.insertCell()
                    td2.hidden = true
                    td1.append(foto.querySelector("imagen").textContent)
                    td2.append(foto.querySelector("ancho").textContent)
                    fila.append(td1)
                    fila.append(td2)

                }
            })

        })


}

function elegirFoto(e) {
    let div1 = document.getElementById("divFoto1")
    let div2 = document.getElementById("divFoto2")
    if (document.getElementById("boton")) document.getElementById("boton").remove()
    div1.innerHTML = ""
    div2.innerHTML = ""
    let foto = e.target.textContent
    let ancho = e.target.nextElementSibling.textContent
    pintar(foto, ancho)
}

function mover(e, div) {
    div.style.top = e.clientY + "px"
    div.style.left = (e.clientX + 690) + "px"
}

function pintar(foto, ancho) {

    let divPuntero = document.getElementById("divPuntero")
    divPuntero.addEventListener("mousemove", (e) => mover(e, divPuntero))

    let div1 = document.getElementById("divFoto1")
    let div2 = document.getElementById("divFoto2")

    let imgFoto1 = document.createElement("img")
    imgFoto1.id = 'foto1'
    imgFoto1.style.width = ancho
    imgFoto1.src = "./imagenes/" + foto + ".jpg"
    div1.append(imgFoto1)

    let imgFoto2 = document.createElement("img")
    imgFoto2.id = 'foto2'
    imgFoto2.style.width = ancho
    imgFoto2.src = "./imagenes/" + foto + "ex.jpg"
    div2.append(imgFoto2)

    imgFoto1.addEventListener("mouseout", () => divPuntero.hidden = true)
    imgFoto1.addEventListener("mouseenter", () => divPuntero.hidden = false)

    imgFoto1.addEventListener("mousemove", (e) => mover(e, divPuntero))

    let boton = document.createElement("button")
    boton.id = "boton"
    boton.append(`Comprar ${foto}`)
    document.getElementById("cab_total").before(boton)
    boton.addEventListener("click", (e) => comprar(e, ancho))

}

function comprar(e, ancho) {

    e.target.remove()
    let xhr = new XMLHttpRequest();
    xhr.open('POST', "imagenes.php");
    let dato = new FormData()
    dato.append("ancho", parseInt(ancho))

    xhr.onload = function () {
        let resultado = xhr.responseText
        let total = document.getElementById("total")
        total.textContent = parseInt(total.textContent) + parseInt(resultado)
    }
    xhr.send(dato);

}