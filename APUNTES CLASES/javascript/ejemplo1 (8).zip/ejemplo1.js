window.onload = inicio

function inicio() {
    let tabla = document.getElementById("mitabla")
    tabla.border = "1"
    tabla.style.borderColor = "red"
    tabla.querySelector("thead").style.backgroundColor = "yellow"

    let tbody = document.querySelector("tbody")
    let numFilas = prompt("¿Cuantas filas?", 3)
    let numColumnas = prompt("¿Cuantas columnas?", 3)
    let filaCabecera = document.createElement("tr")
    document.querySelector("thead").append(filaCabecera)
    for (let i = 1; i <= parseInt(numColumnas); i++) {
        let celda = document.createElement("th")
        celda.append(i)
        filaCabecera.append(celda)
    }
    for (let i = 1; i <= parseInt(numFilas); i++) {
        let fila = document.createElement("tr")
        for (let j = 1; j <= parseInt(numColumnas); j++) {
            let celda = document.createElement("td")
            celda.append("celda " + j + "-" + i)
            fila.append(celda)
        }
        tbody.append(fila)
    }
    cambiarFormato("odd",tbody)
    cambiarFormato("even",tbody)

}

function cambiarFormato(secuencia,tbody) {
    let color = (secuencia == "odd") ? "#ff0000" : "#00ff00"
    color = prompt("¿Color?", color)
    let filas = tbody.querySelectorAll(`tr:nth-child(${secuencia})`)
    filas.forEach(fila => {
        fila.style.backgroundColor = color
    })
}